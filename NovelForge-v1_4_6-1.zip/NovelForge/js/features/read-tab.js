/* ═══════════════════════════════════════════════════════
   read-tab.js — Reader mode with images
   Supports [IMG: url-or-dataurl] tags from webnovel imports
   ═══════════════════════════════════════════════════════ */

NF.readTab = (function() {

  const $ = NF.$;
  let _currentId = null;
  let _fontSize = 'md';

  function init() {
    $('#readChapterSelect').onchange = (e) => {
      _currentId = e.target.value;
      renderChapter();
    };
    $('#readMode').onchange = renderChapter;
    $('#btnReadFontUp').onclick = () => bumpFont(+1);
    $('#btnReadFontDn').onclick = () => bumpFont(-1);
    $('#btnReadPrev').onclick = () => nav(-1);
    $('#btnReadNext').onclick = () => nav(+1);

    NF.on('ws:selected', refreshChapterList);
  }

  function refreshChapterList() {
    const ws = NF.state.currentWs;
    const sel = $('#readChapterSelect');
    sel.innerHTML = '<option value="">— เลือกตอน —</option>';
    if (!ws) return;
    (ws.chapters || []).forEach(c => {
      const opt = NF.el('option', { value: c.id },
        `#${c.num || '?'} · ${c.title || '(ไม่มีชื่อ)'}${c.translated ? ' ✓' : ''}`);
      sel.appendChild(opt);
    });
  }

  function bumpFont(d) {
    const sizes = ['sm', 'md', 'lg', 'xl'];
    let i = sizes.indexOf(_fontSize);
    i = Math.max(0, Math.min(sizes.length - 1, i + d));
    _fontSize = sizes[i];
    $('#readerBody').dataset.size = _fontSize;
  }

  function nav(delta) {
    const ws = NF.state.currentWs;
    if (!ws || !_currentId) return;
    const list = ws.chapters || [];
    const i = list.findIndex(c => c.id === _currentId);
    if (i < 0) return;
    const ni = i + delta;
    if (ni < 0 || ni >= list.length) return;
    _currentId = list[ni].id;
    $('#readChapterSelect').value = _currentId;
    renderChapter();
  }

  function renderChapter() {
    const ws = NF.state.currentWs;
    if (!ws || !_currentId) {
      $('#readerEmpty').hidden = false;
      $('#readerBody').hidden = true;
      return;
    }
    const ch = ws.chapters.find(c => c.id === _currentId);
    if (!ch) return;
    $('#readerEmpty').hidden = true;
    $('#readerBody').hidden = false;
    $('#readerBody').dataset.size = _fontSize;
    $('#readerTitle').textContent = ch.title || 'ไม่มีชื่อ';
    $('#readerMeta').textContent = `ตอนที่ ${ch.num || '?'} · ${NF.fmt.chars(ch.sourceText || '')} · อัพเดต ${NF.fmt.timeAgo(ch.updatedAt)}`;

    const mode = $('#readMode').value;
    const content = $('#readerContent');
    content.innerHTML = '';

    if (mode === 'both') {
      const grid = NF.el('div', { class: 'reader-both-grid' },
        NF.el('div', {}, NF.el('h4', { text: 'RAW' }),  NF.el('div', { class: 'col-source', html: renderText(ch.sourceText || '') })),
        NF.el('div', {}, NF.el('h4', { text: 'คำแปล' }), NF.el('div', { html: renderText(ch.translated || '(ยังไม่แปล)') })),
      );
      content.appendChild(grid);
    } else if (mode === 'source') {
      content.innerHTML = renderText(ch.sourceText || '');
    } else {
      content.innerHTML = renderText(ch.translated || '(ยังไม่แปล)');
    }

    // scroll to top
    $('#reader').scrollTop = 0;
  }

  // render plain text into html: handle [IMG:], scene breaks, paragraphs
  function renderText(text) {
    if (!text) return '<p class="dim">—</p>';
    const parts = text.split(/\n\n+/);
    const out = [];
    for (const p of parts) {
      const trimmed = p.trim();
      if (!trimmed) continue;
      if (/^\s*[-=─★*✦※]{3,}\s*$/.test(trimmed)) {
        out.push('<div class="scene-break">· · ·</div>');
        continue;
      }
      // check if paragraph is an image tag
      const imgM = trimmed.match(/^\[IMG:\s*([^\]]+)\]$/);
      if (imgM) {
        const url = imgM[1].trim();
        out.push(`<img src="${escAttr(url)}" alt="" loading="lazy"/>`);
        continue;
      }
      // replace inline [IMG:xxx] in paragraph
      let html = escHtml(trimmed);
      html = html.replace(/\[IMG:\s*([^\]]+)\]/g, (_, u) => `</p><img src="${escAttr(u)}" alt="" loading="lazy"/><p>`);
      out.push('<p>' + html.replace(/\n/g, '<br/>') + '</p>');
    }
    return out.join('\n');
  }

  function escHtml(s) {
    return String(s).replace(/[<>&]/g, c => ({'<':'&lt;','>':'&gt;','&':'&amp;'}[c]));
  }
  function escAttr(s) {
    return escHtml(s).replace(/"/g, '&quot;');
  }

  return { init, refreshChapterList };
})();

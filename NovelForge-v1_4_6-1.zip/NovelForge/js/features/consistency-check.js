/* ═══════════════════════════════════════════════════════
   consistency-check.js — ตรวจความสอดคล้องของคำแปล
   ───────────────────────────────────────────────────────
   Client-side (ไม่เปลือง token):
   1. ชื่อ source ยังหลงเหลือในคำแปล
   2. สรรพนามผิดเพศ (เขา/เธอ/ผม/ฉัน ตาม glossary)
   ═══════════════════════════════════════════════════════ */

NF.consistencyCheck = (function() {

  const MALE_WRONG   = ['เธอ', 'ของเธอ', 'นาง', 'หนู', 'อิฉัน'];
  const FEMALE_WRONG = ['เขา', 'ของเขา', 'ผม', 'กู'];

  // ─── Run check on a single translated text ───
  function checkText(translatedText, glossary = []) {
    if (!translatedText?.trim()) return { issues: [], score: 100 };
    const issues = [];

    // 1. Source terms leaking into translation
    glossary.forEach(g => {
      if (!g.source || !translatedText) return;
      if (['character', 'title'].includes(g.type) && translatedText.includes(g.source)) {
        issues.push({
          type: '⚠ คำต้นฉบับหลงเหลือ',
          found: g.source,
          expected: `ควรเป็น: ${g.thai}`,
          severity: 'medium',
        });
      }
    });

    // 2. Gender pronoun mismatch
    const sentences = translatedText.split(/[.!?।\n]/).filter(s => s.length > 3);
    glossary.forEach(g => {
      if (g.type !== 'character' || !g.gender || g.gender === 'neutral') return;
      const wrongPronouns = g.gender === 'male' ? MALE_WRONG : FEMALE_WRONG;
      const thaiName = g.thai;
      if (!thaiName) return;
      sentences.forEach(sent => {
        if (!sent.includes(thaiName)) return;
        wrongPronouns.forEach(pronoun => {
          if (sent.includes(pronoun)) {
            issues.push({
              type: '🚨 สรรพนามผิดเพศ',
              found: `"${thaiName}" (${g.gender}) + "${pronoun}"`,
              expected: g.gender === 'male' ? 'ควรใช้: เขา/ผม/กู/ข้า' : 'ควรใช้: เธอ/นาง/ฉัน/หนู',
              severity: 'high',
            });
          }
        });
      });
    });

    const highCount = issues.filter(i => i.severity === 'high').length;
    const medCount  = issues.filter(i => i.severity === 'medium').length;
    const score = Math.max(0, 100 - highCount * 15 - medCount * 5);
    return { issues, score };
  }

  // ─── Open modal for current translation in translate tab ───
  function openForCurrentTranslation() {
    const ws = NF.state.currentWs;
    const outputEl = document.getElementById('translationOutput');
    const text = outputEl?.innerText?.trim() || '';
    if (!text) { NF.toast.warn('ยังไม่มีคำแปล'); return; }

    const { issues, score } = checkText(text, ws?.glossary || []);
    _showModal({ issues, score, title: 'Consistency Check — ผลการแปลปัจจุบัน' });
  }

  // ─── Open modal for entire workspace ───
  function openForWorkspace() {
    const ws = NF.state.currentWs;
    if (!ws?.chapters?.length) { NF.toast.warn('ไม่มีตอนใน Workspace'); return; }

    const allIssues = [];
    let totalScore = 0, count = 0;

    (ws.chapters || [])
      .filter(c => c.translated)
      .sort((a, b) => (a.num||0) - (b.num||0))
      .forEach(ch => {
        const { issues, score } = checkText(ch.translated, ws.glossary || []);
        issues.forEach(iss => allIssues.push({ ...iss, chNum: ch.num, chTitle: ch.title }));
        totalScore += score;
        count++;
      });

    const avgScore = count ? Math.round(totalScore / count) : 100;
    _showModal({ issues: allIssues, score: avgScore, title: `Consistency Check — ${ws.title || 'Workspace'} (${count} ตอน)` });
  }

  function _showModal({ issues, score, title }) {
    const body = NF.el('div', {});

    // Score badge
    const scoreClass = score >= 80 ? 'ok' : score >= 60 ? 'warn' : 'err';
    const scoreLabel = score >= 80 ? 'สอดคล้องดี' : score >= 60 ? 'มีปัญหาบ้าง' : 'ต้องแก้ไข';
    const scoreWrap = NF.el('div', {
      style: { display:'flex', alignItems:'center', gap:'16px', padding:'12px 16px',
               background:'var(--bg-sunken)', borderRadius:'var(--r-sm)', marginBottom:'16px',
               border:'1px solid var(--line)' }
    });
    scoreWrap.appendChild(NF.el('span', {
      style: { fontSize:'40px', fontWeight:'700', color:`var(--${scoreClass})`, fontFamily:'var(--ff-mono)` },
      text: String(score),
    }));
    const scoreRight = NF.el('div', {});
    scoreRight.appendChild(NF.el('div', { style:{fontWeight:'600', fontSize:'14px'}, text: scoreLabel }));
    scoreRight.appendChild(NF.el('div', { class:'dim', style:{fontSize:'12px'}, text:'คะแนนความสอดคล้อง / 100' }));
    scoreWrap.appendChild(scoreRight);
    body.appendChild(scoreWrap);

    if (!issues.length) {
      body.appendChild(NF.el('div', {
        style:{ color:'var(--ok)', textAlign:'center', padding:'20px', fontSize:'14px' },
        text:'✓ ไม่พบปัญหาความสอดคล้อง',
      }));
    } else {
      const issueList = NF.el('div', { style:{ display:'flex', flexDirection:'column', gap:'8px', maxHeight:'360px', overflowY:'auto' } });
      issues.slice(0, 60).forEach(iss => {
        const row = NF.el('div', {
          style: { padding:'10px 12px', background:'var(--bg-raise)', borderRadius:'var(--r-sm)',
                   border:`1px solid var(--${iss.severity==='high'?'err':'accent'})30` }
        });
        const head = NF.el('div', { style:{display:'flex', gap:'8px', alignItems:'center', marginBottom:'4px'} });
        head.appendChild(NF.el('span', { style:{fontSize:'13px', fontWeight:'600'}, text:iss.type }));
        if (iss.chNum) {
          head.appendChild(NF.el('span', { class:'pill', style:{fontSize:'11px'}, text:`#${iss.chNum} ${(iss.chTitle||'').slice(0,20)}` }));
        }
        row.appendChild(head);
        row.appendChild(NF.el('div', { style:{fontSize:'13px', color:'var(--ink-dim)'}, text:`พบ: ${iss.found}` }));
        if (iss.expected) {
          row.appendChild(NF.el('div', { style:{fontSize:'12px', color:'var(--ok)', marginTop:'2px'}, text:`→ ${iss.expected}` }));
        }
        issueList.appendChild(row);
      });
      if (issues.length > 60) {
        issueList.appendChild(NF.el('div', { class:'dim', style:{fontSize:'12px', textAlign:'center', padding:'8px'}, text:`...และอีก ${issues.length - 60} ปัญหา` }));
      }
      body.appendChild(issueList);
    }

    const closeBtn = NF.el('button', { class:'btn btn-primary', text:'ปิด' });
    const foot = NF.el('div', {}, closeBtn);
    const inst = NF.modal.open({ title, body, footer: foot, size:'lg' });
    closeBtn.onclick = () => inst.close();
  }

  return { checkText, openForCurrentTranslation, openForWorkspace };
})();

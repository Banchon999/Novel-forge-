/* ═══════════════════════════════════════════════════════
   translate-tab.js — manual translation tab
   ═══════════════════════════════════════════════════════ */

NF.translateTab = (function() {

  const $ = NF.$;

  let _currentChapterId = null;
  let _abort = null;
  let _editing = false;

  function init() {
    $('#translateChapterSelect').onchange = (e) => {
      const id = e.target.value;
      loadChapter(id);
    };
    $('#btnLoadChapter').onclick = () => loadChapter($('#translateChapterSelect').value);
    $('#btnClearRaw').onclick = () => {
      $('#sourceText').value = '';
      updateStats();
    };
    $('#sourceText').oninput = updateStats;

    $('#btnStartTranslate').onclick = start;
    $('#btnStopTranslate').onclick = stop;

    $('#btnEditOutput').onclick = toggleEdit;
    $('#btnCopyOut').onclick = copyOutput;
    $('#btnSaveToCh').onclick = saveToChapter;

    $('#btnNovelInstruction').onclick = openInstructionModal;
    $('#btnFindReplace').onclick = () => NF.findReplace?.open();

    // ─── New tools ───
    $('#btnReviewSearch').onclick = () => NF.reviewSearch?.open();

    $('#btnHonorifixCheck').onclick = async () => {
      const ws = NF.state.currentWs;
      const outputEl = $('#translationOutput');
      const text = outputEl?.innerText?.trim() || '';
      if (!text) { NF.toast.warn('ยังไม่มีคำแปล'); return; }
      if (!NF.store.getApiKey()) { NF.toast.error('ยังไม่ได้ตั้ง API Key'); return; }
      NF.toast.info('🗣 กำลังตรวจหางเสียง...');
      try {
        const result = await NF.translator.runHonorifixCheck({ ws, text });
        if (!result) { NF.toast.info('ไม่มีหางเสียงให้ตรวจ'); return; }
        if (!result.changed) { NF.toast.success('✓ หางเสียงถูกต้องแล้ว'); return; }
        _showHonorifixDiff(text, result.text, result.diffCount);
      } catch (e) {
        NF.toast.error('ตรวจหางเสียงล้มเหลว: ' + e.message);
      }
    };

    $('#btnConsistencyCheck').onclick = () => NF.consistencyCheck?.openForCurrentTranslation();

    $('#btnLineBreakOut').onclick = () => NF.chapterTools?.addLineBreaksOutput('double');
  }

  // ─── Honorific diff modal ───
  function _showHonorifixDiff(original, fixed, diffCount) {
    const origLines  = original.split('\n');
    const fixedLines = fixed.split('\n');
    const len = Math.max(origLines.length, fixedLines.length);

    const diffBody = NF.el('div', {});
    diffBody.appendChild(NF.el('p', { class:'modal-help', text:`พบ ${diffCount} บรรทัดที่ต้องแก้ไข — ตรวจก่อนยืนยัน` }));

    const diffList = NF.el('div', { style:{ maxHeight:'320px', overflowY:'auto', display:'flex', flexDirection:'column', gap:'6px' } });
    for (let i = 0; i < len; i++) {
      const o = origLines[i] || '';
      const f = fixedLines[i] || '';
      if (o !== f) {
        const row = NF.el('div', { style:{ background:'var(--bg-sunken)', borderRadius:'var(--r-sm)', padding:'6px 10px' } });
        row.appendChild(NF.el('div', { style:{ color:'var(--err)', fontSize:'13px', textDecoration:'line-through', opacity:'0.8' }, text: o || '(ว่าง)' }));
        row.appendChild(NF.el('div', { style:{ color:'var(--ok)', fontSize:'13px', marginTop:'2px' }, text: '→ ' + (f || '(ว่าง)') }));
        diffList.appendChild(row);
      }
    }
    diffBody.appendChild(diffList);

    const applyBtn  = NF.el('button', { class:'btn btn-primary', text:'✓ ใช้การแก้ไข' });
    const cancelBtn = NF.el('button', { class:'btn btn-ghost',   text:'ยกเลิก' });
    const foot = NF.el('div', {}, cancelBtn, applyBtn);
    const inst = NF.modal.open({ title:`🗣 ตรวจหางเสียง — พบ ${diffCount} จุด`, body: diffBody, footer: foot, size:'lg' });

    cancelBtn.onclick = () => inst.close();
    applyBtn.onclick  = async () => {
      const outputEl = $('#translationOutput');
      if (outputEl) outputEl.innerText = fixed;
      // Sync to chapter if loaded
      if (_currentChapterId && NF.state.currentWs) {
        const ch = NF.state.currentWs.chapters?.find(c => c.id === _currentChapterId);
        if (ch) {
          ch.translated = fixed;
          ch.updatedAt  = Date.now();
          await NF.store.saveWorkspace(NF.state.currentWs);
        }
      }
      inst.close();
      NF.toast.success('✓ แก้หางเสียงแล้ว');
    };
  }

  function refreshChapterList() {
    const ws = NF.state.currentWs;
    const sel = $('#translateChapterSelect');
    sel.innerHTML = '<option value="">— เลือกตอน —</option>';
    if (!ws) return;
    (ws.chapters || []).forEach(c => {
      const o = NF.el('option', { value: c.id }, `#${c.num || '?'} · ${c.title || '(ไม่มีชื่อ)'}${c.status === 'translated' ? ' ✓' : ''}`);
      if (c.id === _currentChapterId) o.selected = true;
      sel.appendChild(o);
    });
  }

  function loadChapter(id) {
    const ws = NF.state.currentWs;
    if (!ws || !id) return;
    const ch = ws.chapters.find(c => c.id === id);
    if (!ch) return;
    _currentChapterId = id;
    $('#sourceText').value = ch.sourceText || '';
    $('#translationOutput').innerHTML = '';
    if (ch.translated) {
      $('#translationOutput').textContent = ch.translated;
    }
    updateStats();
  }

  function updateStats() {
    const src = $('#sourceText').value || '';
    $('#rawStat').textContent = NF.fmt.chars(src);
    const out = $('#translationOutput').textContent || '';
    $('#outStat').textContent = NF.fmt.chars(out);
  }

  async function start() {
    const ws = NF.state.currentWs;
    if (!ws) { NF.toast.warn('กรุณาเลือก/สร้าง Workspace ก่อน'); return; }
    if (!NF.store.getApiKey()) {
      NF.toast.error('ยังไม่ได้ตั้ง API Key (ไปที่ Settings)');
      NF.tabs.activate('settings');
      return;
    }
    const src = $('#sourceText').value.trim();
    if (!src) { NF.toast.warn('กรุณาวาง Raw Text'); return; }

    // If no chapter selected, create ad-hoc
    let chapter = ws.chapters.find(c => c.id === _currentChapterId);
    if (!chapter) {
      const nextNum = (ws.chapters.reduce((m, c) => Math.max(m, c.num || 0), 0)) + 1;
      chapter = {
        id: NF.genId(),
        num: nextNum,
        title: 'ตอนที่ ' + nextNum,
        sourceText: src,
        translated: '',
        status: 'translating',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
      ws.chapters.push(chapter);
      _currentChapterId = chapter.id;
      refreshChapterList();
    } else {
      chapter.sourceText = src;
      chapter.status = 'translating';
    }
    chapter.updatedAt = Date.now();
    await NF.store.saveWorkspace(ws);

    $('#btnStartTranslate').hidden = true;
    $('#btnStopTranslate').hidden = false;
    $('#translateProgress').hidden = false;
    $('#translationOutput').innerHTML = '';
    _abort = new AbortController();

    try {
      await NF.translator.translateChapter({
        ws, chapter, signal: _abort.signal,
        onProgress: (p) => {
          if (p.stage === 'chunk-start') {
            $('#progressLabel').textContent = `กำลังแปล chunk ${p.chunkIdx + 1}/${p.total} (${NF.fmt.num(p.chunkSize)} ตัวอักษร)`;
            $('#progressFill').style.width = `${(p.chunkIdx / p.total) * 100}%`;
            ensureSegment(p.chunkIdx);
          } else if (p.stage === 'chunk-done') {
            $('#progressFill').style.width = `${(p.done / p.total) * 100}%`;
            const seg = segmentEl(p.chunkIdx);
            if (seg) seg.querySelector('.seg-status').className = 'seg-status done';
            seg?.querySelector('.seg-status')?.replaceChildren(document.createTextNode('เสร็จ'));
          } else if (p.stage === 'done') {
            $('#progressLabel').textContent = `เสร็จสิ้น (${p.total} chunks)`;
            $('#progressFill').style.width = '100%';
          }
        },
        onChunkStream: (idx, delta, full) => {
          const seg = ensureSegment(idx);
          const txtEl = seg.querySelector('.segment-text');
          txtEl.textContent = full;
          // put cursor at end
          updateStats();
        },
      });
      NF.toast.success('แปลเสร็จสิ้น');
      NF.chapters.render();
    } catch (err) {
      if (err.name === 'AbortError') {
        NF.toast.warn('หยุดแล้ว');
      } else {
        NF.toast.error('แปลผิดพลาด: ' + err.message);
      }
    } finally {
      $('#btnStartTranslate').hidden = false;
      $('#btnStopTranslate').hidden = true;
      $('#translateProgress').hidden = true;
      _abort = null;
    }
  }

  function ensureSegment(idx) {
    const box = $('#translationOutput');
    let seg = segmentEl(idx);
    if (!seg) {
      seg = NF.el('div', { class: 'translation-segment', dataset: { idx: String(idx) } },
        NF.el('div', { class: 'segment-index' },
          NF.el('span', { text: `Chunk ${idx + 1}` }),
          NF.el('span', { class: 'seg-status active', text: 'กำลังแปล' }),
        ),
        NF.el('div', { class: 'segment-text' }),
      );
      box.appendChild(seg);
    }
    return seg;
  }
  function segmentEl(idx) {
    return $(`[data-idx="${idx}"]`, $('#translationOutput'));
  }

  function stop() {
    _abort?.abort();
  }

  function toggleEdit() {
    const out = $('#translationOutput');
    _editing = !_editing;
    out.contentEditable = _editing ? 'true' : 'false';
    out.classList.toggle('editing', _editing);
    $('#btnEditOutput').textContent = _editing ? '✓ เสร็จแก้ไข' : '✎ แก้ไข';
    if (_editing) out.focus();
    else {
      // save edits to chapter on exit
      saveToChapter(true);
    }
  }

  async function copyOutput() {
    const text = $('#translationOutput').innerText;
    try {
      await navigator.clipboard.writeText(text);
      NF.toast.success('คัดลอกแล้ว');
    } catch {
      NF.toast.error('คัดลอกไม่สำเร็จ');
    }
  }

  async function saveToChapter(silent = false) {
    const ws = NF.state.currentWs;
    if (!ws || !_currentChapterId) { if (!silent) NF.toast.warn('ยังไม่ได้เลือกตอน'); return; }
    const ch = ws.chapters.find(c => c.id === _currentChapterId);
    if (!ch) return;
    const text = $('#translationOutput').innerText.trim();
    ch.translated = text;
    ch.status = text ? (ch.status === 'translated' ? 'edited' : ch.status || 'edited') : 'pending';
    if (text && ch.status === 'pending') ch.status = 'translated';
    ch.updatedAt = Date.now();
    await NF.store.saveWorkspace(ws);
    if (!silent) NF.toast.success('บันทึกลงตอนแล้ว');
    NF.chapters.render();
  }

  function openInstructionModal() {
    const ws = NF.state.currentWs;
    if (!ws) return;
    const body = NF.el('div', {});
    body.appendChild(NF.el('p', { class: 'modal-help',
      text: 'Novel Instructions จะถูกส่งไปใน prompt ทุกครั้งที่แปล — ใช้เพื่อกำหนดโทน, คำศัพท์เฉพาะ, ข้อห้ามเฉพาะเรื่อง' }));
    const ta = NF.el('textarea', {
      class: 'input textarea', rows: 12, text: ws.instruction || '',
      placeholder: 'ตัวอย่าง:\n- โทนมืด ลึก จริงจัง\n- ตัวเอกใช้คำว่า "ข้า" เสมอ\n- หลีกเลี่ยงคำทับศัพท์ภาษาอังกฤษ\n- ชื่อเทพใช้คำโบราณ',
    });
    body.appendChild(ta);

    const ok = NF.el('button', { class: 'btn btn-primary', text: 'บันทึก' });
    const cancel = NF.el('button', { class: 'btn btn-ghost', text: 'ยกเลิก' });
    const foot = NF.el('div', {}, cancel, ok);
    const inst = NF.modal.open({ title: 'Novel Instructions', body, footer: foot, size: 'lg' });
    cancel.onclick = () => inst.close();
    ok.onclick = async () => {
      ws.instruction = ta.value;
      await NF.store.saveWorkspace(ws);
      inst.close();
      NF.toast.success('บันทึกแล้ว');
    };
  }

  return { init, refreshChapterList, loadChapter };
})();

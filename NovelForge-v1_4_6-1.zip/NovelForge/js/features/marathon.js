/* ═══════════════════════════════════════════════════════
   marathon.js — concurrent chapter translation worker pool
   - Configurable concurrency (3-5 typical)
   - Daily limit
   - Retry
   - Live log + per-worker status
   ═══════════════════════════════════════════════════════ */

NF.marathon = (function() {

  let _paused = false;

  async function run({ ws, chapterIds, signal, onStart, onProgress, onDone }) {
    const settings = ws.marathon || {};
    let concurrency = Math.max(1, Math.min(10, settings.concurrency || 3));
    const retry = settings.retry !== false;
    const warmup = settings.warmupFirst !== false;   // แปลตอนแรกก่อนเดี่ยวๆ
    const sortByNum = settings.sortByNum !== false;  // เรียงตอนตาม num

    // daily limit
    const today = new Date().toISOString().slice(0, 10);
    if (!ws.marathon.stats || ws.marathon.stats.date !== today) {
      ws.marathon.stats = { date: today, done: 0 };
    }
    const dailyLimit = settings.dailyLimit || 0;
    const remaining = dailyLimit > 0 ? Math.max(0, dailyLimit - ws.marathon.stats.done) : Infinity;

    // queue — เรียงตาม num ก่อน เพื่อให้ context summary มาตามลำดับ
    let queue = chapterIds
      .map(id => ws.chapters.find(c => c.id === id))
      .filter(Boolean);
    if (sortByNum) {
      queue.sort((a, b) => (a.num || 0) - (b.num || 0));
    }
    queue = queue.slice(0, remaining === Infinity ? queue.length : remaining);

    if (!queue.length) {
      NF.toast.warn(dailyLimit > 0
        ? `ถึง daily limit ของวันนี้แล้ว (${dailyLimit})`
        : 'ไม่มีตอนให้แปล');
      onDone && onDone({ done: 0, fail: 0, elapsedSec: 0 });
      return;
    }

    const stats = { total: queue.length, done: 0, fail: 0, queue: queue.length, workers: 0 };
    const startTs = Date.now();

    // ═══ Warm-up phase ═══
    // แปลตอนแรกแบบ sequential ก่อน — เพื่อให้:
    //  1. context summary พร้อมก่อนตอนถัดไป (ปรับโทน)
    //  2. glossary ใหม่ที่ extract จากตอน 1 ใช้กับตอน 2-N ได้
    //  3. AI ได้ "calibrate" สำนวนกับเรื่องนี้
    if (warmup && queue.length > 1 && concurrency > 1) {
      const firstChapter = queue.shift();
      stats.queue = queue.length;
      onProgress({
        stats: { ...stats },
        workers: [],
        log: { msg: `🔥 Warm-up: แปลตอนแรกเดี่ยวก่อน (${firstChapter.num} · ${firstChapter.title || ''})`, cls: 'success' },
      });
      firstChapter.status = 'translating';
      try {
        await NF.translator.translateChapter({
          ws, chapter: firstChapter, signal,
          onProgress: () => {},
        });
        stats.done++;
        ws.marathon.stats.done++;
        onProgress({
          stats: { ...stats },
          workers: [],
          log: { msg: `🔥 Warm-up เสร็จ → เริ่ม parallel ${concurrency} workers`, cls: 'success' },
        });
      } catch (err) {
        if (err.name === 'AbortError') {
          onDone && onDone({ done: stats.done, fail: stats.fail, elapsedSec: Math.floor((Date.now() - startTs) / 1000) });
          return;
        }
        // warm-up fail → ไปต่อแต่เตือน
        if (retry) {
          try {
            await sleep(1500);
            await NF.translator.translateChapter({ ws, chapter: firstChapter, signal });
            stats.done++;
            ws.marathon.stats.done++;
          } catch (e2) {
            if (e2.name === 'AbortError') {
              onDone && onDone({ done: stats.done, fail: stats.fail, elapsedSec: Math.floor((Date.now() - startTs) / 1000) });
              return;
            }
            stats.fail++;
            firstChapter.status = 'error';
            firstChapter.error = e2.message;
            await NF.store.saveWorkspace(ws);
          }
        } else {
          stats.fail++;
          firstChapter.status = 'error';
          firstChapter.error = err.message;
          await NF.store.saveWorkspace(ws);
        }
      }
    }

    if (!queue.length) {
      const elapsedSec = Math.floor((Date.now() - startTs) / 1000);
      onProgress({
        stats: { ...stats },
        workers: [],
        log: { msg: `= สิ้นสุด: done ${stats.done} · fail ${stats.fail} · ${elapsedSec}s =`, cls: 'success' },
      });
      onDone && onDone({ done: stats.done, fail: stats.fail, elapsedSec });
      return;
    }

    const workers = new Array(concurrency).fill(0).map((_, i) => ({ id: i + 1, idle: true }));

    onStart && onStart(stats);

    onProgress({
      stats: { ...stats },
      workers: workers.map(w => ({ ...w })),
      log: { msg: `เริ่ม Marathon — ${queue.length} ตอน · ${concurrency} workers`, cls: 'success' },
    });

    _paused = false;

    async function workerLoop(worker) {
      while (queue.length) {
        if (signal?.aborted) break;
        while (_paused && !signal?.aborted) {
          await sleep(300);
        }
        if (signal?.aborted) break;

        const ch = queue.shift();
        if (!ch) break;
        stats.queue = queue.length;
        worker.idle = false;
        worker.chapterTitle = `#${ch.num || '?'} ${ch.title || ''}`.slice(0, 40);
        worker.startTs = Date.now();
        stats.workers = workers.filter(w => !w.idle).length;

        onProgress({
          stats: { ...stats },
          workers: workers.map(w => ({ ...w })),
          log: { msg: `[W${worker.id}] เริ่ม → ${worker.chapterTitle}` },
        });

        ch.status = 'translating';
        ch.updatedAt = Date.now();

        try {
          await NF.translator.translateChapter({
            ws, chapter: ch, signal,
            onProgress: () => {},
          });
          stats.done++;
          ws.marathon.stats.done++;
          const elapsed = Math.floor((Date.now() - worker.startTs) / 1000);
          onProgress({
            stats: { ...stats },
            workers: workers.map(w => ({ ...w })),
            log: { msg: `[W${worker.id}] ✓ ${worker.chapterTitle} (${elapsed}s)`, cls: 'success' },
          });
        } catch (err) {
          if (err.name === 'AbortError') { break; }
          if (retry) {
            onProgress({
              stats: { ...stats },
              workers: workers.map(w => ({ ...w })),
              log: { msg: `[W${worker.id}] ⟲ retry: ${worker.chapterTitle}`, cls: 'warn' },
            });
            try {
              await sleep(1500);
              await NF.translator.translateChapter({ ws, chapter: ch, signal });
              stats.done++;
              ws.marathon.stats.done++;
              onProgress({
                stats: { ...stats },
                workers: workers.map(w => ({ ...w })),
                log: { msg: `[W${worker.id}] ✓ ${worker.chapterTitle} (retry)`, cls: 'success' },
              });
            } catch (err2) {
              if (err2.name === 'AbortError') break;
              stats.fail++;
              ch.status = 'error';
              ch.error = err2.message;
              ch.updatedAt = Date.now();
              await NF.store.saveWorkspace(ws);
              onProgress({
                stats: { ...stats },
                workers: workers.map(w => ({ ...w })),
                log: { msg: `[W${worker.id}] ✗ ${worker.chapterTitle}: ${err2.message}`, cls: 'error' },
              });
            }
          } else {
            stats.fail++;
            ch.status = 'error';
            ch.error = err.message;
            ch.updatedAt = Date.now();
            await NF.store.saveWorkspace(ws);
            onProgress({
              stats: { ...stats },
              workers: workers.map(w => ({ ...w })),
              log: { msg: `[W${worker.id}] ✗ ${worker.chapterTitle}: ${err.message}`, cls: 'error' },
            });
          }
        } finally {
          worker.idle = true;
          worker.chapterTitle = null;
          worker.startTs = null;
          stats.workers = workers.filter(w => !w.idle).length;
        }
      }
    }

    await Promise.all(workers.map(w => workerLoop(w)));

    // ═══ Auto-apply credit ถ้าเปิดใช้ ═══
    try {
      const creditCfg = NF.credit?.load();
      if (creditCfg?.enabled && creditCfg?.autoApplyOnTranslate && creditCfg?.translatorName) {
        const doneList = chapterIds
          .map(id => ws.chapters.find(c => c.id === id))
          .filter(c => c && c.translated && c.status !== 'error');
        const n = await NF.credit.applyToChapters(ws, doneList);
        if (n > 0) {
          onProgress({
            stats: { ...stats },
            workers: workers.map(w => ({ ...w, idle: true })),
            log: { msg: `✒ ใส่ Credit ${n} ตอน`, cls: 'success' },
          });
        }
      }
    } catch (e) {
      NF.log?.warn('marathon', 'credit apply failed', e);
    }

    const elapsedSec = Math.floor((Date.now() - startTs) / 1000);
    onProgress({
      stats: { ...stats },
      workers: workers.map(w => ({ ...w, idle: true })),
      log: { msg: `= สิ้นสุด Marathon: done ${stats.done} · fail ${stats.fail} · ${elapsedSec}s =`, cls: 'success' },
    });
    onDone && onDone({ done: stats.done, fail: stats.fail, elapsedSec });
  }

  function pause() {
    _paused = !_paused;
    NF.toast.info(_paused ? 'หยุดพักแล้ว' : 'ทำงานต่อ');
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  return { run, pause };
})();

/* ═══════════════════════════════════════════════════════
   import-export.js — all import/export paths
   Import: EPUB (v2/v3), TXT single, TXT/ZIP bundle, paste
   Export: TXT, ZIP of TXTs, EPUB v2, EPUB v3, DOCX (for Drive)
   ═══════════════════════════════════════════════════════ */

NF.importExport = (function() {

  const $ = NF.$;

  // ═══════════════════════════════════════════
  // IMPORT
  // ═══════════════════════════════════════════

  async function importEpub(file) {
    const ws = ensureWs();
    if (!ws) return;
    try {
      NF.toast.info('กำลังอ่าน EPUB...');
      const parsed = await NF.epub.parse(file);
      if (!parsed.chapters.length) { NF.toast.warn('EPUB ว่าง'); return; }

      // preview modal with opt-in chapters
      await previewAndAddChapters(parsed.chapters, {
        titleHint: parsed.meta?.title,
        authorHint: parsed.meta?.author,
        sourceName: file.name,
      });
    } catch (err) {
      console.error(err);
      NF.toast.error('EPUB parse ผิดพลาด: ' + err.message);
    }
  }

  async function importTxtOrZip(files) {
    const ws = ensureWs();
    if (!ws) return;
    try {
      const chapters = [];
      for (const f of files) {
        if (/\.zip$/i.test(f.name)) {
          // read zip, extract all .txt as chapters
          const buf = await NF.readBuf(f);
          const zip = await NF.zip.read(buf);
          const names = zip.entries
            .filter(n => /\.txt$/i.test(n) && !n.startsWith('__MACOSX'))
            .sort();
          for (const n of names) {
            const text = await zip.readText(n);
            if (!text) continue;
            chapters.push({
              title: n.split('/').pop().replace(/\.txt$/i, ''),
              text: normalizeImageMarkup(text),
            });
          }
        } else if (/\.txt$/i.test(f.name)) {
          const text = await NF.readText(f);
          chapters.push({ title: f.name.replace(/\.txt$/i, ''), text: normalizeImageMarkup(text) });
        }
      }
      if (!chapters.length) { NF.toast.warn('ไม่พบไฟล์ .txt'); return; }
      await previewAndAddChapters(chapters);
    } catch (err) {
      NF.toast.error('Import ผิดพลาด: ' + err.message);
    }
  }

  // ═══════════════════════════════════════════
  // Normalize image markup so translator sees [IMG: url] tokens
  // regardless of how the source text presented images.
  // Delegates to NF.imageGuard.normalizeMarkup so logic lives in one place.
  // ═══════════════════════════════════════════
  function normalizeImageMarkup(text) {
    const r = NF.imageGuard.normalizeMarkup(text);
    if (r.count > 0) NF.log?.info('import', `normalized ${r.count} image references to [IMG:]`);
    return r.text;
  }

  function openPasteModal() {
    const ws = ensureWs();
    if (!ws) return;

    const body = NF.el('div', {});
    body.appendChild(NF.el('p', { class: 'modal-help', text: 'วางข้อความจะถือเป็นตอนเดียว หรือใช้ตัวคั่น "---" (สาม dashes) เพื่อแบ่งหลายตอน บรรทัดแรกของแต่ละตอนจะกลายเป็นชื่อตอน' }));
    body.appendChild(NF.el('div', { class: 'field' },
      NF.el('span', { text: 'ข้อความ' }),
      NF.el('textarea', { id: 'pasteText', class: 'input textarea', rows: 12 }),
    ));
    body.appendChild(NF.el('div', { class: 'field' },
      NF.el('span', { text: 'เริ่มลำดับที่ (อัตโนมัติถ้าเว้น)' }),
      NF.el('input', { id: 'pasteStartNum', type: 'number', class: 'input', placeholder: '' }),
    ));

    const ok = NF.el('button', { class: 'btn btn-primary', text: 'นำเข้า' });
    const cancel = NF.el('button', { class: 'btn btn-ghost', text: 'ยกเลิก' });
    const foot = NF.el('div', {}, cancel, ok);
    const inst = NF.modal.open({ title: 'วางเนื้อหา', body, footer: foot, size: 'lg' });
    cancel.onclick = () => inst.close();
    ok.onclick = async () => {
      const text = $('#pasteText').value;
      if (!text.trim()) { NF.toast.warn('ไม่มีข้อความ'); return; }
      // split by ---
      const parts = text.split(/\n\s*-{3,}\s*\n/);
      const chapters = parts.filter(Boolean).map((p, i) => {
        const lines = p.split('\n');
        const title = (lines[0] || '').trim() || `ตอนที่ ${i + 1}`;
        const body = lines.slice(1).join('\n').trim() || p.trim();
        return { title: title.slice(0, 120), text: body };
      });
      inst.close();
      await previewAndAddChapters(chapters);
    };
  }

  async function previewAndAddChapters(chapters, opts = {}) {
    const ws = NF.state.currentWs;
    if (!ws) return;

    const body = NF.el('div', {});
    const help = NF.el('p', { class: 'modal-help', text: `พบ ${chapters.length} ตอน — ตรวจก่อน import` });
    body.appendChild(help);

    // chapter list with checkboxes
    const list = NF.el('div', { class: 'modal-ch-list' });
    const rows = [];
    chapters.forEach((c, i) => {
      const row = NF.el('div', { class: 'auto-ch-item' },
        NF.el('input', { type: 'checkbox', checked: true }),
        NF.el('span', { class: 'num', text: '#' + (i + 1) }),
        NF.el('span', { class: 'title', text: c.title || '(no title)' }),
      );
      row.onclick = (e) => {
        if (e.target.tagName === 'INPUT') return;
        const cb = row.querySelector('input');
        cb.checked = !cb.checked;
      };
      rows.push({ c, el: row });
      list.appendChild(row);
    });
    body.appendChild(list);

    // options
    body.appendChild(NF.el('div', { style: { marginTop: '12px', display: 'flex', gap: '12px', flexWrap: 'wrap' } },
      NF.el('label', { class: 'chk-wrap' },
        NF.el('input', { type: 'checkbox', id: 'impSkipDup', checked: true }),
        NF.el('span', { text: 'ข้ามตอนที่ชื่อซ้ำ' }),
      ),
      NF.el('label', { class: 'chk-wrap' },
        NF.el('input', { type: 'checkbox', id: 'impStripTitle', checked: true }),
        NF.el('span', { text: 'ตัดบรรทัดชื่อตอนซ้ำในข้อความ' }),
      ),
    ));

    const ok = NF.el('button', { class: 'btn btn-primary', text: 'นำเข้า' });
    const cancel = NF.el('button', { class: 'btn btn-ghost', text: 'ยกเลิก' });
    const foot = NF.el('div', {}, cancel, ok);

    const inst = NF.modal.open({ title: 'ตัวอย่างก่อน Import', body, footer: foot, size: 'lg' });
    cancel.onclick = () => inst.close();
    ok.onclick = async () => {
      const skipDup = $('#impSkipDup').checked;
      const stripTitle = $('#impStripTitle').checked;
      const existingTitles = new Set((ws.chapters || []).map(c => (c.title || '').trim()));
      let added = 0, skipped = 0;
      const startNum = (ws.chapters || []).reduce((m, c) => Math.max(m, c.num || 0), 0) + 1;

      for (const r of rows) {
        const cb = r.el.querySelector('input');
        if (!cb.checked) continue;
        let title = (r.c.title || '').trim();
        let text = r.c.text || '';
        if (skipDup && title && existingTitles.has(title)) { skipped++; continue; }

        // strip title from first line
        if (stripTitle && title && text.split('\n')[0]?.trim() === title) {
          text = text.split('\n').slice(1).join('\n').replace(/^\s+/, '');
        }

        const ch = {
          id: NF.genId(),
          num: startNum + added,
          title: title || `ตอนที่ ${startNum + added}`,
          sourceText: normalizeImageMarkup(text),
          translated: '',
          status: 'pending',
          createdAt: Date.now(),
          updatedAt: Date.now(),
        };
        ws.chapters.push(ch);
        existingTitles.add(ch.title);
        added++;
      }

      // set workspace metadata if empty
      if (!ws.author && opts.authorHint) ws.author = opts.authorHint;
      if ((!ws.title || ws.title === 'Untitled') && opts.titleHint) ws.title = opts.titleHint;

      await NF.store.saveWorkspace(ws);
      inst.close();
      NF.chapters.render();
      NF.translateTab.refreshChapterList();
      NF.readTab.refreshChapterList();
      NF.emit('ws:listChanged');
      NF.toast.success(`นำเข้า ${added} ตอน${skipped ? ` · ข้าม ${skipped} ซ้ำ` : ''}`);
    };
  }

  // ═══════════════════════════════════════════
  // EXPORT
  // ═══════════════════════════════════════════

  function openExportModal(preselectIds) {
    const ws = NF.state.currentWs;
    if (!ws?.chapters?.length) { NF.toast.warn('ไม่มีตอน'); return; }

    const body = NF.el('div', {});
    body.appendChild(NF.el('p', { class: 'modal-help', text: 'เลือกรูปแบบไฟล์ที่ต้องการ export' }));

    const options = [
      { v: 'txt-each', icon: '📄', label: 'TXT แยกไฟล์', desc: 'แต่ละตอน = .txt — ดาวน์โหลดเป็น ZIP' },
      { v: 'txt-one',  icon: '📜', label: 'TXT รวม 1 ไฟล์', desc: 'ทุกตอนรวมในไฟล์เดียว' },
      { v: 'epub3',    icon: '📘', label: 'EPUB 3 (แนะนำ)', desc: 'รองรับ ereader ใหม่ + รูปภาพ' },
      { v: 'epub2',    icon: '📗', label: 'EPUB 2', desc: 'รองรับ ereader เก่า' },
      { v: 'docx',     icon: '📝', label: 'DOCX (Google Drive)', desc: 'เปิดเป็น Google Doc ได้' },
      { v: 'json',     icon: '💾', label: 'JSON Backup', desc: 'ใช้กับ NovelForge เท่านั้น' },
    ];

    const grid = NF.el('div', { class: 'export-options', style: { marginBottom: '16px' } });
    let selectedFormat = 'epub3';
    const optEls = {};
    for (const o of options) {
      const el = NF.el('div', { class: 'export-option' + (o.v === selectedFormat ? ' selected' : ''), onclick: () => {
        selectedFormat = o.v;
        for (const k of Object.keys(optEls)) optEls[k].classList.toggle('selected', k === o.v);
      }},
        NF.el('div', { class: 'export-option-icon', text: o.icon }),
        NF.el('div', { class: 'export-option-label', text: o.label }),
        NF.el('div', { class: 'export-option-desc', text: o.desc }),
      );
      optEls[o.v] = el;
      grid.appendChild(el);
    }
    body.appendChild(grid);

    // chapter select
    const preSet = new Set(preselectIds || []);
    const chList = NF.el('div', { class: 'modal-ch-list' });
    const chRows = [];
    body.appendChild(NF.el('div', { style: { display: 'flex', gap: '8px', marginBottom: '8px' } },
      NF.el('button', { class: 'btn-chip', onclick: () => { chRows.forEach(r => r.chk.checked = true); } }, 'เลือกทั้งหมด'),
      NF.el('button', { class: 'btn-chip', onclick: () => { chRows.forEach(r => r.chk.checked = false); } }, 'ล้าง'),
      NF.el('button', { class: 'btn-chip', onclick: () => {
        chRows.forEach(r => r.chk.checked = r.ch.status === 'translated' || r.ch.status === 'edited');
      }}, 'เฉพาะที่แปลแล้ว'),
      NF.el('label', { class: 'chk-wrap', style: { marginLeft: 'auto' } },
        NF.el('input', { type: 'checkbox', id: 'expUseTr', checked: true }),
        NF.el('span', { text: 'ใช้คำแปล (ไม่ใช่ raw)' }),
      ),
    ));
    for (const ch of ws.chapters) {
      const chk = NF.el('input', { type: 'checkbox', checked: preSet.size ? preSet.has(ch.id) : true });
      const row = NF.el('div', { class: 'auto-ch-item' },
        chk,
        NF.el('span', { class: 'num', text: '#' + (ch.num || '?') }),
        NF.el('span', { class: 'title', text: ch.title || '(no title)' }),
        NF.el('span', { class: 'ch-status ' + (ch.status || 'pending'), text: ch.status === 'translated' || ch.status === 'edited' ? '✓' : '○' }),
      );
      row.onclick = (e) => {
        if (e.target.tagName === 'INPUT') return;
        chk.checked = !chk.checked;
      };
      chRows.push({ ch, chk });
      chList.appendChild(row);
    }
    body.appendChild(chList);

    const ok = NF.el('button', { class: 'btn btn-primary', text: 'Export' });
    const cancel = NF.el('button', { class: 'btn btn-ghost', text: 'ยกเลิก' });
    const foot = NF.el('div', {}, cancel, ok);

    const inst = NF.modal.open({ title: 'Export', body, footer: foot, size: 'lg' });
    cancel.onclick = () => inst.close();
    ok.onclick = async () => {
      const selected = chRows.filter(r => r.chk.checked).map(r => r.ch);
      if (!selected.length) { NF.toast.warn('ยังไม่ได้เลือกตอน'); return; }
      const useTr = $('#expUseTr').checked;
      inst.close();
      try {
        NF.toast.info('กำลังสร้างไฟล์...');
        await doExport(selectedFormat, selected, { useTr });
      } catch (err) {
        NF.toast.error('Export ผิดพลาด: ' + err.message);
      }
    };
  }

  async function doExport(format, chapters, opts = {}) {
    const ws = NF.state.currentWs;
    const base = NF.slug(ws.title || 'novelforge');
    const useTr = opts.useTr !== false;
    const stamp = new Date().toISOString().slice(0, 10);

    const getContent = (ch) => useTr && (ch.translated) ? ch.translated : (ch.sourceText || '');

    if (format === 'txt-each') {
      const files = {};
      for (const ch of chapters) {
        const name = `${String(ch.num || 0).padStart(4, '0')}-${NF.slug(ch.title || 'chapter')}.txt`;
        files[name] = '\ufeff' + (ch.title ? ch.title + '\n\n' : '') + getContent(ch);
      }
      // compress
      for (const k of Object.keys(files)) files[k] = { data: files[k], compress: true };
      const bytes = await NF.zip.write(files);
      NF.download(bytes, `${base}-${stamp}.zip`, 'application/zip');
      NF.toast.success(`Export ${chapters.length} ไฟล์ใน ZIP`);
    }
    else if (format === 'txt-one') {
      const out = chapters.map(ch => {
        const head = ch.title ? `\n\n===== ${ch.title} =====\n\n` : '\n\n';
        return head + getContent(ch);
      }).join('\n\n');
      NF.download('\ufeff' + out, `${base}-${stamp}.txt`, 'text/plain;charset=utf-8');
      NF.toast.success('Export TXT แล้ว');
    }
    else if (format === 'epub3' || format === 'epub2') {
      const bytes = await NF.epub.build({
        title: ws.title || 'NovelForge',
        author: ws.author || '',
        language: 'th',
        version: format === 'epub3' ? '3' : '2',
        chapters: chapters.map(ch => ({ title: ch.title, text: getContent(ch) })),
      });
      NF.download(bytes, `${base}-${stamp}.epub`, 'application/epub+zip');
      NF.toast.success('Export EPUB แล้ว');
    }
    else if (format === 'docx') {
      const bytes = await NF.docx.build({
        title: ws.title || 'NovelForge',
        sections: chapters.map(ch => ({
          heading: ch.title || '',
          paragraphs: getContent(ch).split(/\n\n+/).filter(Boolean),
        })),
      });
      NF.download(bytes, `${base}-${stamp}.docx`, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
      NF.toast.success('Export DOCX แล้ว — อัพโหลด Google Drive เพื่อเปิดเป็น Google Doc');
    }
    else if (format === 'json') {
      const data = { ...ws, chapters };
      NF.download(JSON.stringify(data, null, 2), `${base}-${stamp}.json`, 'application/json');
      NF.toast.success('Export JSON แล้ว');
    }
    NF.store.markBackup();
  }

  // ── helpers ──
  function ensureWs() {
    const ws = NF.state.currentWs;
    if (!ws) { NF.toast.warn('กรุณาเลือก Workspace ก่อน'); return null; }
    return ws;
  }

  return { importEpub, importTxtOrZip, openPasteModal, openExportModal, doExport };
})();

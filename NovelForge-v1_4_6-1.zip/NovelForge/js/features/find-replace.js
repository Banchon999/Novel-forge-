/* ═══════════════════════════════════════════════════════
   find-replace.js — search/replace in translation output
   ═══════════════════════════════════════════════════════ */

NF.findReplace = (function() {

  function open() {
    const body = NF.el('div', {});
    body.appendChild(NF.el('p', { class: 'modal-help', text: 'ค้นหา/แทนที่ในคำแปลของตอนปัจจุบัน หรือทุกตอนใน workspace' }));

    body.appendChild(NF.el('div', { class: 'field' },
      NF.el('span', { text: 'ค้นหา' }),
      NF.el('input', { id: 'frFind', class: 'input', placeholder: 'คำที่ต้องการค้นหา' }),
    ));
    body.appendChild(NF.el('div', { class: 'field' },
      NF.el('span', { text: 'แทนที่ด้วย' }),
      NF.el('input', { id: 'frReplace', class: 'input', placeholder: 'คำใหม่ (เว้นว่างเพื่อลบ)' }),
    ));
    body.appendChild(NF.el('div', { style: { display: 'flex', gap: '12px', flexWrap: 'wrap' } },
      NF.el('label', { class: 'chk-wrap' },
        NF.el('input', { id: 'frCase', type: 'checkbox' }),
        NF.el('span', { text: 'Case-sensitive' }),
      ),
      NF.el('label', { class: 'chk-wrap' },
        NF.el('input', { id: 'frRegex', type: 'checkbox' }),
        NF.el('span', { text: 'Regex' }),
      ),
      NF.el('label', { class: 'chk-wrap' },
        NF.el('input', { id: 'frAll', type: 'checkbox' }),
        NF.el('span', { text: 'ทุกตอนใน workspace (ไม่ใช่แค่ตอนที่แสดง)' }),
      ),
    ));

    const preview = NF.el('div', { class: 'modal-help', style: { marginTop: '12px', maxHeight: '200px', overflow: 'auto', display: 'none' } });
    body.appendChild(preview);

    const btnPreview = NF.el('button', { class: 'btn btn-ghost', text: 'ดูตัวอย่าง' });
    const btnReplace = NF.el('button', { class: 'btn btn-primary', text: 'แทนที่ทั้งหมด' });
    const cancel = NF.el('button', { class: 'btn btn-ghost', text: 'ปิด' });
    const foot = NF.el('div', {}, cancel, btnPreview, btnReplace);
    const inst = NF.modal.open({ title: 'ค้นหา / แทนที่', body, footer: foot, size: 'lg' });
    cancel.onclick = () => inst.close();

    btnPreview.onclick = () => {
      const result = runReplace({ dry: true });
      if (result.error) { NF.toast.error(result.error); return; }
      preview.style.display = 'block';
      preview.innerHTML = `พบ ${result.count} จุดใน ${result.chapters} ตอน${result.examples.length ? '<br>ตัวอย่าง:<br>' : ''}` +
        result.examples.slice(0, 5).map(e => `• ${escHtml(e)}`).join('<br>');
    };

    btnReplace.onclick = async () => {
      const result = runReplace({ dry: false });
      if (result.error) { NF.toast.error(result.error); return; }
      NF.toast.success(`แทนที่ ${result.count} จุด ใน ${result.chapters} ตอน`);
      preview.style.display = 'block';
      preview.innerHTML = `เสร็จ: ${result.count} จุด · ${result.chapters} ตอน`;
      inst.close();
      NF.chapters.render();
      NF.translateTab.loadChapter?.(NF.$('#translateChapterSelect').value);
    };
  }

  function runReplace({ dry }) {
    const ws = NF.state.currentWs;
    if (!ws) return { error: 'กรุณาเลือก workspace' };
    const find = NF.$('#frFind').value;
    if (!find) return { error: 'ใส่คำค้นหา' };
    const replace = NF.$('#frReplace').value;
    const useRegex = NF.$('#frRegex').checked;
    const caseSens = NF.$('#frCase').checked;
    const scopeAll = NF.$('#frAll').checked;

    let re;
    try {
      if (useRegex) {
        re = new RegExp(find, caseSens ? 'g' : 'gi');
      } else {
        const escaped = find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        re = new RegExp(escaped, caseSens ? 'g' : 'gi');
      }
    } catch (e) {
      return { error: 'Regex ผิด: ' + e.message };
    }

    let count = 0;
    let chapterCount = 0;
    const examples = [];

    let target = scopeAll ? (ws.chapters || []) : [];
    if (!scopeAll) {
      const curId = NF.$('#translateChapterSelect').value;
      const ch = (ws.chapters || []).find(c => c.id === curId);
      if (ch) target = [ch];
    }

    for (const ch of target) {
      const t = ch.translated || '';
      if (!t) continue;
      const matches = t.match(re);
      if (!matches) continue;
      count += matches.length;
      chapterCount++;
      if (examples.length < 5) examples.push(`[${ch.title || '#'+ch.num}] ...${snippet(t, matches[0])}...`);
      if (!dry) {
        ch.translated = t.replace(re, replace);
        ch.status = (ch.status === 'translated') ? 'edited' : ch.status;
        ch.updatedAt = Date.now();
      }
    }

    if (!dry && count > 0) {
      NF.store.saveWorkspace(ws);
    }

    return { count, chapters: chapterCount, examples };
  }

  function snippet(text, match) {
    const i = text.indexOf(match);
    if (i < 0) return match;
    return text.slice(Math.max(0, i - 20), i + match.length + 20);
  }

  function escHtml(s) {
    return String(s).replace(/[<>&]/g, c => ({'<':'&lt;','>':'&gt;','&':'&amp;'}[c]));
  }

  return { open };
})();

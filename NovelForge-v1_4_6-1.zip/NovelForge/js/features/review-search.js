/* ═══════════════════════════════════════════════════════
   review-search.js — ค้นหาทีละรายการในทุกตอน
   ───────────────────────────────────────────────────────
   ต่างจาก Find&Replace ปกติ:
   - เห็น context รอบๆ คำที่เจอ
   - Replace / Skip ทีละจุด
   - แก้ไขตรงๆ ในบริบทนั้น (free-edit mode)
   - บันทึกรวดเดียวตอนปิด
   ═══════════════════════════════════════════════════════ */

NF.reviewSearch = (function() {

  let _matches = [];
  let _matchIdx = -1;
  let _currentTexts = {};    // { chId: liveText }
  let _pendingChanges = {};  // { chId: newText }
  let _bStartFull = 0;
  let _aEndFull   = 0;
  let _editMode   = false;
  const CONTEXT_LEN = 180;

  // ─── Open modal ───
  function open(prefill = '') {
    _matches = [];
    _matchIdx = -1;
    _currentTexts = {};
    _pendingChanges = {};
    _editMode = false;

    const modal = _buildModal();
    const inst = NF.modal.open({
      title: '🔍 Review Search',
      body: modal.body,
      footer: modal.footer,
      size: 'lg',
      onClose: _saveAndApply,
    });
    modal._inst = inst;

    if (prefill) {
      modal.findInput.value = prefill;
      _search(modal);
    }

    modal.findInput.focus();
    return inst;
  }

  function _buildModal() {
    const body = NF.el('div', {});

    // ─── Search bar ───
    const findRow = NF.el('div', { style: { display:'flex', gap:'8px', marginBottom:'8px', flexWrap:'wrap' } });
    const findInput = NF.el('input', { class:'input', placeholder:'ค้นหาใน translated ทุกตอน', style:{ flex:'1', minWidth:'160px' } });
    const csChk = NF.el('input', { type:'checkbox', id:'rs-case' });
    const reChk = NF.el('input', { type:'checkbox', id:'rs-regex' });
    const searchBtn = NF.el('button', { class:'btn btn-primary' }, '🔍 ค้นหา');
    findRow.append(
      findInput,
      NF.el('label', { class:'chk-wrap', style:{alignSelf:'center'} }, csChk, NF.el('span',{text:'Case'})),
      NF.el('label', { class:'chk-wrap', style:{alignSelf:'center'} }, reChk, NF.el('span',{text:'Regex'})),
      searchBtn,
    );
    body.appendChild(findRow);

    // ─── Replace input ───
    const replaceRow = NF.el('div', { style:{display:'flex', gap:'8px', marginBottom:'8px'} });
    const replaceInput = NF.el('input', { class:'input', placeholder:'แทนที่ด้วย...', style:{flex:'1'} });
    replaceRow.appendChild(replaceInput);
    body.appendChild(replaceRow);

    // ─── Progress bar ───
    const progressWrap = NF.el('div', { id:'rs-progress', hidden:true, style:{marginBottom:'8px'} });
    const progressBar = NF.el('div', { class:'progress-bar' });
    const progressFill = NF.el('div', { class:'progress-fill', id:'rs-fill', style:{width:'0%'} });
    progressBar.appendChild(progressFill);
    const countInfo = NF.el('div', { style:{display:'flex', justifyContent:'space-between', fontSize:'12px', marginTop:'4px'} });
    const countLabel = NF.el('span', { id:'rs-count', class:'dim' });
    const chapterLabel = NF.el('span', { id:'rs-chapter', class:'dim' });
    countInfo.append(countLabel, chapterLabel);
    progressWrap.append(progressBar, countInfo);
    body.appendChild(progressWrap);

    // ─── Context display ───
    const contextWrap = NF.el('div', { id:'rs-context-wrap', hidden:true });
    const contextDisplay = NF.el('div', {
      id: 'rs-context-display',
      style: {
        background:'var(--bg-sunken)',
        border:'1px solid var(--line)',
        borderRadius:'var(--r-sm)',
        padding:'12px',
        lineHeight:'1.9',
        maxHeight:'220px',
        overflowY:'auto',
        fontSize:'14px',
        fontFamily:'var(--ff-serif)',
        whiteSpace:'pre-wrap',
        wordBreak:'break-all',
      }
    });
    const contextEdit = NF.el('textarea', {
      id: 'rs-context-edit',
      class: 'input textarea',
      rows: 7,
      style: { display:'none', fontFamily:'var(--ff-serif)', fontSize:'14px', lineHeight:'1.9' },
    });
    const editHint = NF.el('p', {
      class:'dim',
      text:'แก้ไขข้อความโดยตรง — กด "บันทึก & ถัดไป" เมื่อเสร็จ',
      style:{fontSize:'12px', margin:'4px 0 0', display:'none'},
    });
    contextWrap.append(contextDisplay, contextEdit, editHint);
    body.appendChild(contextWrap);

    // End message
    const endMsg = NF.el('div', {
      id: 'rs-end',
      hidden: true,
      style: { textAlign:'center', padding:'20px', color:'var(--ok)', fontSize:'14px' },
      text: '✓ ตรวจครบทุกรายการแล้ว',
    });
    body.appendChild(endMsg);

    // ─── Footer buttons ───
    const replaceBtn   = NF.el('button', { class:'btn btn-primary', text:'แทนที่ & ถัดไป', hidden:true });
    const skipBtn      = NF.el('button', { class:'btn btn-ghost',   text:'ข้าม', hidden:true });
    const editToggleBtn= NF.el('button', { class:'btn btn-ghost',   text:'✏ แก้ไขตรงๆ', hidden:true });
    const saveCtxBtn   = NF.el('button', { class:'btn btn-primary', text:'💾 บันทึก & ถัดไป', hidden:true });
    const prevBtn      = NF.el('button', { class:'btn btn-ghost',   text:'← ก่อนหน้า', hidden:true });
    const footer = NF.el('div', { style:{display:'flex', gap:'8px', flexWrap:'wrap'} },
      prevBtn, NF.el('span',{class:'spacer'}), editToggleBtn, skipBtn, replaceBtn, saveCtxBtn
    );

    // ─── Wire events ───
    const state = { findInput, replaceInput, csChk, reChk, progressWrap, progressFill,
                    countLabel, chapterLabel, contextWrap, contextDisplay, contextEdit,
                    editHint, endMsg, replaceBtn, skipBtn, editToggleBtn, saveCtxBtn,
                    prevBtn, _inst: null };

    searchBtn.onclick = () => _search(state);
    findInput.onkeydown = (e) => { if (e.key === 'Enter') _search(state); };

    replaceBtn.onclick = () => _replaceAndNext(state);
    skipBtn.onclick    = () => _goNext(state);
    prevBtn.onclick    = () => _goPrev(state);

    editToggleBtn.onclick = () => {
      if (_editMode) _exitEditMode(state); else _enterEditMode(state);
    };
    saveCtxBtn.onclick = () => _saveContextAndNext(state);

    return { body, footer, findInput, ...state };
  }

  // ─── Search ───
  function _search(state) {
    const term = state.findInput.value.trim();
    if (!term) { NF.toast.warn('ใส่คำค้นหาก่อน'); return; }
    const ws = NF.state.currentWs;
    if (!ws) return;

    const opts = { cs: state.csChk.checked, regex: state.reChk.checked };
    _matches = [];
    _matchIdx = -1;
    _currentTexts = {};
    _pendingChanges = {};

    (ws.chapters || []).forEach(ch => {
      if (ch.translated) _currentTexts[ch.id] = ch.translated;
    });

    try {
      const re = _buildRe(term, opts, 'g');
      (ws.chapters || [])
        .filter(c => c.translated)
        .sort((a, b) => (a.num||0) - (b.num||0))
        .forEach(ch => {
          const hits = [...ch.translated.matchAll(re)];
          hits.forEach((m, occIdx) => {
            _matches.push({ chId:ch.id, chNum:ch.num, chTitle:ch.title||'', occIdx, match:m[0], replaced:false });
          });
        });
    } catch(e) {
      NF.toast.error('Regex ไม่ถูกต้อง: ' + e.message);
      return;
    }

    state.endMsg.hidden = true;
    if (!_matches.length) {
      NF.toast.info(`ไม่พบ "${term}" ในทุกตอน`);
      [state.progressWrap, state.contextWrap, state.replaceBtn, state.skipBtn,
       state.editToggleBtn, state.prevBtn].forEach(el => el.hidden = true);
      return;
    }

    _matchIdx = 0;
    _renderCurrent(state);
  }

  function _buildRe(term, opts, flags = '') {
    let p = opts.regex ? term : term.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const f = flags + (opts.cs ? '' : 'i');
    return new RegExp(p, f);
  }

  // ─── Render current match ───
  function _renderCurrent(state) {
    if (_editMode) _exitEditMode(state);

    const m = _matches[_matchIdx];
    if (!m) return;
    const term = state.findInput.value.trim();
    const opts = { cs: state.csChk.checked, regex: state.reChk.checked };
    const text = _currentTexts[m.chId] || '';

    // Find the actual occurrence in current text
    const replacedBefore = _matches.slice(0, _matchIdx).filter(x => x.chId === m.chId && x.replaced).length;
    const occInCurrent = m.occIdx - replacedBefore;

    let hit;
    try {
      const re = _buildRe(term, opts, 'g');
      const hits = [...text.matchAll(re)];
      hit = hits[occInCurrent];
    } catch { hit = null; }

    if (!hit) { _goNext(state); return; }

    const idx = hit.index;
    const matchTxt = hit[0];
    const bStart = Math.max(0, idx - CONTEXT_LEN);
    const aEnd   = Math.min(text.length, idx + matchTxt.length + CONTEXT_LEN);
    _bStartFull = bStart;
    _rsAEndFull = aEnd;

    // Build context display with highlight
    const before = (bStart > 0 ? '…' : '') + text.slice(bStart, idx);
    const after  = text.slice(idx + matchTxt.length, aEnd) + (aEnd < text.length ? '…' : '');

    state.contextDisplay.innerHTML = '';
    const bNode = document.createElement('span');
    bNode.style.cssText = 'white-space:pre-wrap;word-break:break-all';
    bNode.textContent = before;

    const mark = document.createElement('mark');
    mark.style.cssText = 'background:rgba(var(--accent-rgb,201,168,76),0.4);color:var(--accent);border-radius:3px;padding:0 3px;font-weight:700;outline:2px solid var(--accent);white-space:pre-wrap';
    mark.textContent = matchTxt;

    const aNode = document.createElement('span');
    aNode.style.cssText = 'white-space:pre-wrap;word-break:break-all';
    aNode.textContent = after;

    state.contextDisplay.append(bNode, mark, aNode);
    setTimeout(() => mark.scrollIntoView({ block:'nearest', behavior:'smooth' }), 40);

    // Progress
    const pct = ((_matchIdx + 1) / _matches.length) * 100;
    state.progressFill.style.width = pct + '%';
    state.countLabel.textContent = `${_matchIdx + 1} / ${_matches.length} รายการ`;
    state.chapterLabel.textContent = `ตอน ${m.chNum ?? '?'}: ${m.chTitle}`;

    // Show UI
    state.progressWrap.hidden = false;
    state.contextWrap.hidden  = false;
    state.replaceBtn.hidden   = false;
    state.skipBtn.hidden      = false;
    state.editToggleBtn.hidden= false;
    state.prevBtn.hidden      = _matchIdx <= 0;
    state.saveCtxBtn.hidden   = true;
    state.endMsg.hidden       = true;

    // Pre-fill replace input
    state.replaceInput.value = matchTxt;
  }

  function _replaceAndNext(state) {
    const m = _matches[_matchIdx];
    if (!m) return;
    const term = state.findInput.value.trim();
    const replaceWith = state.replaceInput.value;
    const opts = { cs: state.csChk.checked, regex: state.reChk.checked };

    const replacedBefore = _matches.slice(0, _matchIdx).filter(x => x.chId === m.chId && x.replaced).length;
    const occInCurrent = m.occIdx - replacedBefore;

    let text = _currentTexts[m.chId] || '';
    try {
      const re = _buildRe(term, opts, 'g');
      const hits = [...text.matchAll(re)];
      const hit = hits[occInCurrent];
      if (hit) {
        text = text.slice(0, hit.index) + replaceWith + text.slice(hit.index + hit[0].length);
        _currentTexts[m.chId] = text;
        _pendingChanges[m.chId] = text;
        m.replaced = true;
      }
    } catch {}
    _goNext(state);
  }

  function _goNext(state) {
    if (_matchIdx < _matches.length - 1) {
      _matchIdx++;
      _renderCurrent(state);
    } else {
      _showEnd(state);
    }
  }

  function _goPrev(state) {
    if (_matchIdx > 0) {
      _matchIdx--;
      state.endMsg.hidden = true;
      _renderCurrent(state);
    }
  }

  function _showEnd(state) {
    if (_editMode) _exitEditMode(state);
    state.contextWrap.hidden  = true;
    state.replaceBtn.hidden   = true;
    state.skipBtn.hidden      = true;
    state.editToggleBtn.hidden= true;
    state.saveCtxBtn.hidden   = true;
    state.prevBtn.hidden      = true;
    state.endMsg.hidden       = false;
    state.progressFill.style.width = '100%';
    state.countLabel.textContent = `✓ ตรวจครบ ${_matches.length} รายการ`;
    state.countLabel.style.color = 'var(--ok)';
  }

  // ─── Free-edit mode ───
  function _enterEditMode(state) {
    _editMode = true;
    const m = _matches[_matchIdx];
    if (!m) return;
    const text = _currentTexts[m.chId] || '';
    state.contextEdit.value = text.slice(_bStartFull, _rsAEndFull);
    state.contextDisplay.style.display = 'none';
    state.contextEdit.style.display    = 'block';
    state.editHint.style.display       = 'block';
    state.replaceBtn.hidden  = true;
    state.skipBtn.hidden     = true;
    state.saveCtxBtn.hidden  = false;
    state.editToggleBtn.textContent = '✕ ยกเลิก';
    state.editToggleBtn.style.color = 'var(--err)';

    // Highlight match in textarea
    const term = state.findInput.value.trim();
    const opts = { cs: state.csChk.checked, regex: state.reChk.checked };
    const snippet = state.contextEdit.value;
    try {
      const re = _buildRe(term, opts);
      const pos = snippet.search(re);
      if (pos >= 0) {
        state.contextEdit.focus();
        state.contextEdit.setSelectionRange(pos, pos + (snippet.match(re)?.[0]?.length || 0));
      } else state.contextEdit.focus();
    } catch { state.contextEdit.focus(); }
  }

  function _exitEditMode(state) {
    _editMode = false;
    state.contextDisplay.style.display = 'block';
    state.contextEdit.style.display    = 'none';
    state.editHint.style.display       = 'none';
    state.replaceBtn.hidden  = false;
    state.skipBtn.hidden     = false;
    state.saveCtxBtn.hidden  = true;
    state.editToggleBtn.textContent = '✏ แก้ไขตรงๆ';
    state.editToggleBtn.style.color = '';
  }

  function _saveContextAndNext(state) {
    const m = _matches[_matchIdx];
    if (!m) return;
    const edited   = state.contextEdit.value;
    const fullText = _currentTexts[m.chId] || '';
    const newText  = fullText.slice(0, _bStartFull) + edited + fullText.slice(_rsAEndFull);
    if (newText !== fullText) {
      _currentTexts[m.chId]  = newText;
      _pendingChanges[m.chId] = newText;
      m.replaced = true;
    }
    _exitEditMode(state);
    _goNext(state);
  }

  // ─── Save pending changes on close ───
  async function _saveAndApply() {
    const ws = NF.state.currentWs;
    if (!ws) return;
    const ids = Object.keys(_pendingChanges);
    if (!ids.length) return;
    (ws.chapters || []).forEach(ch => {
      if (_pendingChanges[ch.id] !== undefined) {
        ch.translated  = _pendingChanges[ch.id];
        ch.updatedAt   = Date.now();
        ch.wordCount   = ch.translated.length;
      }
    });
    await NF.store.saveWorkspace(ws);
    NF.chapters?.render();
    NF.toast.success(`บันทึกการแก้ไข ${ids.length} ตอน ✓`);
    _matches = [];
    _pendingChanges = {};
  }

  return { open };
})();

/* ═══════════════════════════════════════════════════════
   settings-tab.js — all settings wiring
   ═══════════════════════════════════════════════════════ */

NF.settingsTab = (function() {

  const $ = NF.$;

  function init() {
    // ── API Key ──
    $('#btnSaveKey').onclick = () => {
      const k = $('#apiKeyInput').value.trim();
      if (!k) { NF.store.clearApiKey(); NF.toast.info('ลบ API Key แล้ว'); return; }
      NF.store.setApiKey(k);
      NF.toast.success('บันทึก API Key แล้ว');
    };
    $('#btnTestKey').onclick = async () => {
      try {
        const k = $('#apiKeyInput').value.trim();
        if (k) NF.store.setApiKey(k);
        NF.toast.info('กำลังทดสอบ...');
        const info = await NF.api.testKey();
        const limit = info?.data?.limit_remaining ?? info?.data?.limit ?? '—';
        NF.toast.success(`Key OK! credits remaining: ${limit}`);
      } catch (e) {
        NF.toast.error(e.message);
      }
    };
    $('#btnTogglePw').onclick = () => {
      const i = $('#apiKeyInput');
      i.type = i.type === 'password' ? 'text' : 'password';
    };

    // ── Models ──
    // ── Models: handled by buildModelPickers() + dropdown change handler ──

    // ── Translation ──
    $('#tempRange').oninput = () => {
      $('#tempVal').textContent = $('#tempRange').value;
    };
    $('#tempRange').onchange = saveWsSettings;
    ['chunkSize', 'chunkMode', 'useStream', 'useContext', 'useAutoGlossary', 'translateTitles', 'nonThaiDetect'].forEach(id => {
      const el = $('#' + id);
      if (el) el.onchange = saveWsSettings;
    });

    // ── Register ──
    $('#registerDefault').onchange = () => {
      saveWsSettings();
      _updateFluidHint();
    };
    $('#narratorPronoun').onchange = saveWsSettings;

    // ── Workspace info ──
    $('#btnSaveWsInfo').onclick = async () => {
      const ws = NF.state.currentWs;
      if (!ws) return;
      ws.title = $('#wsTitleInput').value.trim() || 'Untitled';
      ws.author = $('#wsAuthorInput').value.trim();
      ws.tags = $('#wsTagsInput').value.trim();
      ws.synopsis = $('#wsSynopsisInput').value;
      ws.instruction = $('#wsInstructionInput').value;
      await NF.store.saveWorkspace(ws);
      NF.toast.success('บันทึกข้อมูลเรื่องแล้ว');
      NF.workspace.updateUIForWs();
      NF.emit('ws:listChanged');
    };
    $('#btnDeleteWs').onclick = () => NF.workspace.deleteCurrent();

    // ── Marathon ──
    ['mConcurrency', 'mDailyLimit', 'mRetry', 'mAutoSummary', 'mWarmupFirst', 'mSortByNum'].forEach(id => {
      const el = $('#' + id);
      if (el) el.onchange = saveMarathonSettings;
    });

    // ── Credit (Global) ──
    initCreditPanel();

    // ── Appearance ──
    $('#themeSelect').onchange = () => {
      NF.store.setTheme($('#themeSelect').value);
    };
    $('#fontSize').onchange = () => {
      NF.store.setFontSize($('#fontSize').value);
    };

    // ── Backup ──
    $('#btnExportWsJSON').onclick = () => NF.workspace.exportJSON();
    $('#btnExportAllWsJSON').onclick = () => NF.sidebar?.exportAll?.();
    $('#btnResetCost').onclick = async () => {
      const ok = await NF.modal.confirm({ title: 'Reset ค่าใช้จ่ายสะสม?', message: 'ไม่เกี่ยวกับข้อมูลแปล แค่ reset ตัวนับค่าใช้จ่าย', danger: true });
      if (ok) { NF.store.resetCosts(); NF.toast.success('Reset แล้ว'); updateCostBadge(); }
    };
    $('#btnWipeAll').onclick = async () => {
      const ok = await NF.modal.confirm({
        title: 'ลบข้อมูลทั้งหมด?',
        message: 'จะลบ Workspace ทั้งหมดและ API Key อย่างถาวร ย้อนกลับไม่ได้',
        danger: true, confirmLabel: 'ลบทั้งหมด',
      });
      if (!ok) return;
      await NF.idb.clear('workspaces');
      await NF.idb.clear('meta');
      localStorage.clear();
      location.reload();
    };

    NF.on('costs:updated', updateCostBadge);
    NF.on('ws:selected', load);

    // ─── Dev Log panel ───
    initDevLog();
  }

  // ═══════════════════════════════════════════
  // DEV LOG PANEL
  // ═══════════════════════════════════════════
  let _devLogUnsub = null;
  let _devLogOpen = false;

  function initDevLog() {
    $('#btnDevLogToggle').onclick = () => {
      _devLogOpen = !_devLogOpen;
      $('#devLogBody').hidden = !_devLogOpen;
      $('#btnDevLogToggle').textContent = _devLogOpen ? 'ซ่อน' : 'แสดง';
      if (_devLogOpen) refreshDevLog();
    };

    $('#devLogLevelFilter').onchange = refreshDevLog;
    $('#devLogSearch').oninput = NF.debounce(refreshDevLog, 200);

    $('#btnDevLogClear').onclick = () => {
      NF.log.clear();
      refreshDevLog();
    };
    $('#btnDevLogCopy').onclick = async () => {
      try {
        const text = NF.log.toText(currentFilter());
        await navigator.clipboard.writeText(text);
        NF.toast.success('คัดลอก log แล้ว');
      } catch (e) {
        NF.toast.error('คัดลอกไม่สำเร็จ: ' + e.message);
      }
    };
    $('#btnDevLogDownload').onclick = () => {
      NF.log.downloadText(currentFilter());
      NF.toast.success('Download แล้ว');
    };

    // live update
    _devLogUnsub = NF.log.subscribe((entry) => {
      if (!_devLogOpen) return;
      if (entry?._cleared) { refreshDevLog(); return; }
      appendDevLogRow(entry);
    });
  }

  function currentFilter() {
    return {
      level: $('#devLogLevelFilter')?.value || '',
      q: $('#devLogSearch')?.value || '',
    };
  }

  function refreshDevLog() {
    const box = $('#devLogBox');
    if (!box) return;
    box.innerHTML = '';
    const entries = NF.log.list(currentFilter());
    for (const e of entries) appendDevLogRow(e, true);
    $('#devLogCount').textContent = entries.length + ' / ' + NF.log._buf.length + ' entries';
    if ($('#devLogAutoScroll').checked) box.scrollTop = box.scrollHeight;
  }

  function appendDevLogRow(entry, batch = false) {
    // respect current filter when streaming a single new entry
    if (!batch) {
      const f = currentFilter();
      if (f.level) {
        const order = { debug: 0, info: 1, warn: 2, error: 3 };
        if ((order[entry.level] ?? 0) < (order[f.level] ?? 0)) return;
      }
      if (f.q) {
        const q = f.q.toLowerCase();
        if (!entry.msg.toLowerCase().includes(q) && !entry.tag.toLowerCase().includes(q)) return;
      }
    }
    const box = $('#devLogBox');
    if (!box) return;
    const row = NF.el('div', { class: 'dev-log-row ' + (entry.level === 'debug' ? 'dbg' : entry.level) },
      NF.el('span', { class: 'dlt', text: new Date(entry.ts).toTimeString().slice(0, 8) }),
      NF.el('span', { class: 'dll', text: entry.level }),
      (() => {
        const body = NF.el('span', { class: 'dlm' });
        const t = NF.el('b', { text: '[' + entry.tag + '] ' });
        body.appendChild(t);
        body.appendChild(document.createTextNode(entry.msg));
        if (entry.data !== undefined) {
          let s = '';
          try { s = JSON.stringify(entry.data); } catch { s = String(entry.data); }
          if (s && s !== '{}') {
            body.appendChild(NF.el('span', { class: 'dld', text: s.length > 400 ? s.slice(0, 400) + '…' : s }));
          }
        }
        return body;
      })(),
    );
    box.appendChild(row);
    if (!batch && $('#devLogAutoScroll')?.checked) box.scrollTop = box.scrollHeight;
    // update count lazily
    const cnt = $('#devLogCount');
    if (cnt) cnt.textContent = box.children.length + ' / ' + NF.log._buf.length + ' entries';
  }

  function _updateFluidHint() {
    const hint = $('#fluidModeHint');
    if (!hint) return;
    hint.style.display = $('#registerDefault')?.value === 'fluid' ? '' : 'none';
  }

  function load() {
    const ws = NF.state.currentWs;

    // API Key (always from LS)
    $('#apiKeyInput').value = NF.store.getApiKey() || '';

    // Credit panel (Global — โหลดเสมอ แม้ไม่มี ws)
    loadCreditPanel();

    if (!ws) return;
    const s = ws.settings || {};
    // models are rendered via buildModelPickers() below
    buildModelPickers();
    $('#tempRange').value = s.temperature ?? 0.7;
    $('#tempVal').textContent = s.temperature ?? 0.7;
    $('#chunkSize').value = s.chunkSize || 2500;
    $('#chunkMode').value = s.chunkMode || 'size';
    $('#useStream').checked = s.useStream !== false;
    $('#useContext').checked = s.useContext !== false;
    $('#useAutoGlossary').checked = s.useAutoGlossary !== false;
    if ($('#translateTitles')) $('#translateTitles').checked = s.translateTitles !== false;
    if ($('#nonThaiDetect')) $('#nonThaiDetect').checked = s.nonThaiDetect !== false;
    $('#registerDefault').value = s.registerDefault || 'neutral';
    $('#narratorPronoun').value = s.narratorPronoun || 'auto';

    $('#wsTitleInput').value = ws.title || '';
    $('#wsAuthorInput').value = ws.author || '';
    $('#wsTagsInput').value = ws.tags || '';
    $('#wsSynopsisInput').value = ws.synopsis || '';
    $('#wsInstructionInput').value = ws.instruction || '';

    const m = ws.marathon || {};
    $('#mConcurrency').value = m.concurrency || 3;
    $('#mDailyLimit').value = m.dailyLimit || 0;
    $('#mRetry').checked = m.retry !== false;
    $('#mAutoSummary').checked = m.autoSummary !== false;
    if ($('#mWarmupFirst')) $('#mWarmupFirst').checked = m.warmupFirst !== false;
    if ($('#mSortByNum'))   $('#mSortByNum').checked   = m.sortByNum !== false;

    $('#themeSelect').value = NF.store.getTheme();
    $('#fontSize').value = NF.store.getFontSize();

    updateBackupLabel();
    updateCostBadge();
    _updateFluidHint();
  }

  // ─── Build model pickers (dropdown + optional custom input fallback) ───
  function buildModelPickers() {
    const ws = NF.state.currentWs;
    const specs = [
      { wrapId: 'modelTranslateWrap', inputId: 'modelTranslate',
        current: ws?.settings?.translateModel, allowInherit: false },
      { wrapId: 'modelGlossaryWrap',  inputId: 'modelGlossary',
        current: ws?.settings?.glossaryModel, allowInherit: true },
      { wrapId: 'modelSummaryWrap',   inputId: 'modelSummary',
        current: ws?.settings?.summaryModel,  allowInherit: true },
    ];
    for (const spec of specs) {
      const wrap = $('#' + spec.wrapId);
      const hidden = $('#' + spec.inputId);
      if (!wrap || !hidden) continue;
      wrap.innerHTML = '';
      const sel = NF.models.buildSelect({
        currentValue: spec.current,
        includeInherit: spec.allowInherit,
        onChange: (value) => onModelPickerChange(wrap, hidden, value),
      });
      wrap.appendChild(sel);
      // custom input — shown only when dropdown = __custom__
      const custom = NF.el('input', {
        type: 'text',
        class: 'input mono',
        placeholder: 'org/model-name',
        style: { marginTop: '8px', display: 'none' },
      });
      custom.oninput = () => {
        hidden.value = custom.value.trim();
        saveWsSettings();
      };
      wrap.appendChild(custom);
      // initialize hidden + custom visibility
      if (sel.value === '__custom__') {
        hidden.value = spec.current || '';
        custom.value = spec.current || '';
        custom.style.display = '';
      } else {
        hidden.value = sel.value;
      }
    }
  }

  function onModelPickerChange(wrap, hidden, value) {
    const custom = wrap.querySelector('input.input');
    if (value === '__custom__') {
      custom.style.display = '';
      hidden.value = custom.value.trim();
      setTimeout(() => custom.focus(), 0);
    } else {
      custom.style.display = 'none';
      hidden.value = value;
    }
    saveWsSettings();
  }

  async function saveWsSettings() {
    const ws = NF.state.currentWs;
    if (!ws) return;
    ws.settings = ws.settings || {};
    const defaultModel = NF.models.defaultId();
    ws.settings.translateModel = $('#modelTranslate').value.trim() || defaultModel;
    // empty = "inherit from translate" for glossary/summary
    const gloss = $('#modelGlossary').value.trim();
    const sum = $('#modelSummary').value.trim();
    ws.settings.glossaryModel = gloss || ws.settings.translateModel;
    ws.settings.summaryModel  = sum   || ws.settings.translateModel;
    ws.settings.temperature = parseFloat($('#tempRange').value) || 0.7;
    ws.settings.chunkSize = parseInt($('#chunkSize').value, 10) || 2500;
    ws.settings.chunkMode = $('#chunkMode').value;
    ws.settings.useStream = $('#useStream').checked;
    ws.settings.useContext = $('#useContext').checked;
    ws.settings.useAutoGlossary = $('#useAutoGlossary').checked;
    ws.settings.translateTitles = NF.isChecked('#translateTitles', true);
    ws.settings.nonThaiDetect   = NF.isChecked('#nonThaiDetect', true);
    ws.settings.registerDefault = $('#registerDefault').value;
    ws.settings.narratorPronoun = $('#narratorPronoun').value;
    await NF.store.saveWorkspace(ws);
  }

  async function saveMarathonSettings() {
    const ws = NF.state.currentWs;
    if (!ws) return;
    ws.marathon = ws.marathon || {};
    ws.marathon.concurrency = parseInt($('#mConcurrency').value, 10) || 3;
    ws.marathon.dailyLimit = parseInt($('#mDailyLimit').value, 10) || 0;
    ws.marathon.retry = $('#mRetry').checked;
    ws.marathon.autoSummary = $('#mAutoSummary').checked;
    ws.marathon.warmupFirst = NF.isChecked('#mWarmupFirst', true);
    ws.marathon.sortByNum = NF.isChecked('#mSortByNum', true);
    await NF.store.saveWorkspace(ws);
  }

  // ═══════════════════════════════════════════
  // Credit Panel (Global config)
  // ═══════════════════════════════════════════
  function initCreditPanel() {
    const fields = [
      ['creditEnabled',         'enabled',         'checked'],
      ['creditName',            'translatorName',  'value'],
      ['creditContact',         'contact',         'value'],
      ['creditMessage',         'message',         'value'],
      ['creditPlacement',       'placement',       'value'],
      ['creditRandomStyle',     'randomStyle',     'checked'],
      ['creditIncludeChInfo',   'includeChapterInfo', 'checked'],
      ['creditAutoApply',       'autoApplyOnTranslate', 'checked'],
    ];

    // wire change handlers
    for (const [elId] of fields) {
      const el = $('#' + elId);
      if (!el) continue;
      const evt = (el.type === 'checkbox' || el.tagName === 'SELECT') ? 'change' : 'input';
      el.addEventListener(evt, NF.debounce(saveCreditConfig, 200));
    }

    $('#btnCreditPreview').onclick = previewCredit;
    $('#btnCreditApplyAll').onclick = applyCreditToCurrentWs;
    $('#btnCreditStripAll').onclick = stripCreditFromCurrentWs;
  }

  function loadCreditPanel() {
    const cfg = NF.credit?.load?.() || {};
    const setVal = (id, key, prop) => {
      const el = $('#' + id);
      if (!el) return;
      el[prop] = cfg[key] !== undefined ? cfg[key] : (prop === 'checked' ? false : '');
    };
    setVal('creditEnabled',       'enabled',              'checked');
    setVal('creditName',          'translatorName',       'value');
    setVal('creditContact',       'contact',              'value');
    setVal('creditMessage',       'message',              'value');
    setVal('creditPlacement',     'placement',            'value');
    setVal('creditRandomStyle',   'randomStyle',          'checked');
    setVal('creditIncludeChInfo', 'includeChapterInfo',   'checked');
    setVal('creditAutoApply',     'autoApplyOnTranslate', 'checked');
  }

  function saveCreditConfig() {
    if (!NF.credit) return;
    const cfg = NF.credit.load();
    cfg.enabled            = NF.isChecked('#creditEnabled', false);
    cfg.translatorName     = $('#creditName').value.trim();
    cfg.contact            = $('#creditContact').value.trim();
    cfg.message            = $('#creditMessage').value.trim();
    cfg.placement          = $('#creditPlacement').value || 'footer';
    cfg.randomStyle        = NF.isChecked('#creditRandomStyle', true);
    cfg.includeChapterInfo = NF.isChecked('#creditIncludeChInfo', true);
    cfg.autoApplyOnTranslate = NF.isChecked('#creditAutoApply', false);
    NF.credit.save(cfg);
  }

  async function previewCredit() {
    saveCreditConfig();
    const cfg = NF.credit.load();
    if (!cfg.enabled) { NF.toast.warn('เปิดใช้ก่อน'); return; }
    if (!cfg.translatorName) { NF.toast.warn('ใส่ชื่อนักแปลก่อน'); return; }

    // สร้าง preview ทั้ง 3 รอบ (random pattern → ดูได้ว่ามันต่างกันจริง)
    const ws = NF.state.currentWs || { title: 'ตัวอย่างเรื่อง' };
    const fakeChapter = { num: 1, title: 'ตอนแรก' };
    const sampleBody = '...เนื้อหาที่แปลแล้วจะอยู่ตรงนี้ (ตัวอย่างนี้ไม่แสดงเนื้อหาจริง)...';
    const samples = [];
    for (let i = 0; i < 3; i++) {
      samples.push(NF.credit.apply(sampleBody, { chapter: fakeChapter, ws }));
    }

    const body = NF.el('div', {});
    body.appendChild(NF.el('p', { class: 'modal-help',
      text: 'นี่คือตัวอย่าง credit ที่จะแทรก — สังเกตว่าทั้ง 3 รอบไม่เหมือนกัน (random pattern)' }));
    samples.forEach((s, i) => {
      body.appendChild(NF.el('h4', { text: `ตัวอย่างที่ ${i + 1}`, style: { marginTop: '12px', color: 'var(--accent)' } }));
      body.appendChild(NF.el('pre', {
        style: {
          background: 'var(--bg-sunken)',
          padding: '12px',
          borderRadius: '6px',
          fontFamily: 'var(--ff-serif)',
          fontSize: '14px',
          lineHeight: '1.7',
          whiteSpace: 'pre-wrap',
          margin: '8px 0 0',
          border: '1px solid var(--line)',
        },
        text: s,
      }));
    });
    body.appendChild(NF.el('p', { class: 'modal-help', style: { marginTop: '14px' },
      text: '🔒 ในข้อความข้างบนมี zero-width signature ซ่อนอยู่ (มองไม่เห็น) ใช้เป็นลายมือสำหรับตรวจสอบภายหลัง' }));

    const closeBtn = NF.el('button', { class: 'btn btn-primary', text: 'ปิด' });
    const foot = NF.el('div', {}, closeBtn);
    const inst = NF.modal.open({ title: '✒ ตัวอย่าง Credit', body, footer: foot, size: 'lg' });
    closeBtn.onclick = () => inst.close();
  }

  async function applyCreditToCurrentWs() {
    const ws = NF.state.currentWs;
    if (!ws) { NF.toast.warn('ยังไม่ได้เลือก workspace'); return; }
    saveCreditConfig();
    const cfg = NF.credit.load();
    if (!cfg.enabled || !cfg.translatorName) {
      NF.toast.error('เปิดใช้ + ใส่ชื่อนักแปลก่อน');
      return;
    }
    const target = (ws.chapters || []).filter(c => c.translated);
    if (!target.length) { NF.toast.warn('ยังไม่มีตอนที่แปลแล้ว'); return; }
    const ok = await NF.modal.confirm({
      title: 'ใส่ Credit?',
      message: `จะใส่ credit ใน ${target.length} ตอนที่แปลแล้ว (ตอนที่มี credit อยู่แล้วจะถูกแทนที่ด้วยรอบใหม่)`,
      confirmLabel: 'ใส่เลย',
    });
    if (!ok) return;
    try {
      const n = await NF.credit.applyToChapters(ws, target);
      NF.toast.success(`ใส่ credit ${n} ตอน`);
      NF.chapters.render();
    } catch (e) {
      NF.toast.error(e.message);
    }
  }

  async function stripCreditFromCurrentWs() {
    const ws = NF.state.currentWs;
    if (!ws) { NF.toast.warn('ยังไม่ได้เลือก workspace'); return; }
    const target = (ws.chapters || []).filter(c => c.translated && NF.credit.has(c.translated));
    if (!target.length) { NF.toast.warn('ไม่มีตอนที่มี credit'); return; }
    const ok = await NF.modal.confirm({
      title: 'ถอด Credit?',
      message: `จะถอด credit จาก ${target.length} ตอน — เนื้อหาแปลคงเดิม แค่ลบบล็อก credit ออก`,
      danger: true,
      confirmLabel: 'ถอด',
    });
    if (!ok) return;
    const n = await NF.credit.stripFromChapters(ws, target);
    NF.toast.success(`ถอด credit จาก ${n} ตอน`);
    NF.chapters.render();
  }

  function updateCostBadge() {
    const c = NF.store.getCosts();
    $('#costAmount').textContent = NF.fmt.usd(c.totalUsd || 0);
  }

  function updateBackupLabel() {
    const t = NF.store.getLastBackup();
    $('#backupReminder').textContent = t ? `Backup ล่าสุด: ${NF.fmt.timeAgo(t)}` : 'ยังไม่เคย backup — แนะนำให้ export เก็บ';
  }

  return { init, load, saveWsSettings, updateCostBadge };
})();

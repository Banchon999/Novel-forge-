/* ═══════════════════════════════════════════════════════
   chapters.js — chapter list tab
   ═══════════════════════════════════════════════════════ */

NF.chapters = (function() {

  const $ = NF.$;

  function init() {
    $('#btnAddChapter').onclick = () => openEditor();
    $('#btnSelectMode').onclick = toggleBulk;
    $('#btnExitBulk').onclick = exitBulk;
    $('#bulkSelectAll').onchange = toggleSelectAll;

    // bulk actions
    NF.$$('.bulk-actions [data-bulk]').forEach(b => {
      b.onclick = () => handleBulkAction(b.dataset.bulk);
    });

    // filter/sort
    $('#chapterSearch').oninput = NF.debounce(() => {
      NF.state.chapterFilter.q = $('#chapterSearch').value;
      render();
    }, 200);
    $('#chapterFilterStatus').onchange = () => {
      NF.state.chapterFilter.status = $('#chapterFilterStatus').value;
      render();
    };
    $('#chapterSort').onchange = () => {
      NF.state.chapterFilter.sort = $('#chapterSort').value;
      render();
    };

    // "more" menu
    const menuBtn = $('#btnChMore');
    const menu = $('#menuChMore');
    menuBtn.onclick = (e) => {
      e.stopPropagation();
      menu.hidden = !menu.hidden;
    };
    document.addEventListener('click', (e) => {
      if (!menu.contains(e.target) && e.target !== menuBtn) menu.hidden = true;
    });
    menu.addEventListener('click', (e) => {
      const b = e.target.closest('button[data-act]');
      if (!b) return;
      menu.hidden = true;
      handleMenuAction(b.dataset.act);
    });
  }

  function render() {
    const ws = NF.state.currentWs;
    const box = $('#chapterList');
    if (!box) {
      NF.log.error('chapters', 'render: #chapterList not found in DOM');
      return;
    }
    box.innerHTML = '';
    const emptyEl = $('#chapterEmpty');

    if (!ws) {
      NF.log.dbg('chapters', 'render: no workspace');
      if (emptyEl) emptyEl.hidden = false;
      return;
    }

    const all = ws.chapters || [];
    NF.log.dbg('chapters', 'render', { count: all.length, wsId: ws.id });

    if (!all.length) {
      if (emptyEl) emptyEl.hidden = false;
      $('#chapterStats').textContent = '0 / 0';
      return;
    }
    if (emptyEl) emptyEl.hidden = true;

    const { q, status, sort } = NF.state.chapterFilter;
    let list = all.filter(c => {
      if (status && status !== 'all' && c.status !== status) {
        if (!(status === 'pending' && (c.status === undefined || c.status === 'pending'))) return false;
      }
      if (q) {
        const ql = q.toLowerCase();
        if (!(c.title || '').toLowerCase().includes(ql)
          && !(c.sourceText || '').toLowerCase().includes(ql)) return false;
      }
      return true;
    });

    if (sort === 'num-asc')       list.sort((a,b) => (a.num||0) - (b.num||0));
    else if (sort === 'num-desc') list.sort((a,b) => (b.num||0) - (a.num||0));
    else if (sort === 'updated-desc') list.sort((a,b) => (b.updatedAt||0) - (a.updatedAt||0));

    const totalTr = all.filter(c => c.status === 'translated' || c.status === 'edited').length;
    $('#chapterStats').textContent = `${totalTr} / ${all.length} แปลแล้ว`;

    const bulk = NF.state.bulkMode;
    box.parentElement.classList.toggle('bulk-mode', bulk);
    $('#bulkBar').hidden = !bulk;

    for (const ch of list) {
      const card = NF.el('div', {
        class: 'ch-card' + (ch._selected ? ' selected' : ''),
        dataset: { id: ch.id },
        onclick: (e) => {
          if (bulk) {
            ch._selected = !ch._selected;
            updateBulkCount();
            render();
          } else {
            openEditor(ch.id);
          }
        },
      },
        NF.el('div', { class: 'ch-chk-wrap' },
          NF.el('input', { type: 'checkbox', class: 'ch-chk', checked: !!ch._selected, onclick: (e) => e.stopPropagation() })
        ),
        NF.el('div', { class: 'ch-num', text: '#' + (ch.num || '—') }),
        NF.el('div', { class: 'ch-body' },
          NF.el('div', { class: 'ch-title', text: ch.title || '(ไม่มีชื่อ)' }),
          NF.el('div', { class: 'ch-meta' },
            NF.el('span', { text: NF.fmt.chars(ch.sourceText || '') }),
            NF.el('span', { text: NF.fmt.timeAgo(ch.updatedAt || ch.createdAt) }),
          ),
        ),
        NF.el('span', { class: 'ch-status ' + (ch.status || 'pending'), text: labelForStatus(ch.status) }),
      );
      box.appendChild(card);
    }

    updateBulkCount();
    NF.workspace.updateCounts();
  }

  function labelForStatus(s) {
    switch (s) {
      case 'translated':   return 'แปลแล้ว';
      case 'edited':       return 'แก้ไขแล้ว';
      case 'translating':  return 'กำลังแปล';
      case 'error':        return 'ผิดพลาด';
      default:             return 'ยังไม่แปล';
    }
  }

  function toggleBulk() {
    NF.state.bulkMode = !NF.state.bulkMode;
    if (!NF.state.bulkMode) {
      (NF.state.currentWs?.chapters || []).forEach(c => c._selected = false);
    }
    render();
  }
  function exitBulk() {
    NF.state.bulkMode = false;
    (NF.state.currentWs?.chapters || []).forEach(c => c._selected = false);
    render();
  }
  function toggleSelectAll() {
    const all = NF.state.currentWs?.chapters || [];
    const target = $('#bulkSelectAll').checked;
    all.forEach(c => c._selected = target);
    render();
  }

  function updateBulkCount() {
    const sel = (NF.state.currentWs?.chapters || []).filter(c => c._selected);
    $('#bulkCount').textContent = sel.length;
  }

  async function handleBulkAction(act) {
    const ws = NF.state.currentWs;
    if (!ws) return;
    const selected = ws.chapters.filter(c => c._selected);

    if (act === 'pending') {
      ws.chapters.forEach(c => c._selected = (c.status !== 'translated' && c.status !== 'edited'));
      render(); return;
    }
    if (act === 'translated') {
      ws.chapters.forEach(c => c._selected = (c.status === 'translated' || c.status === 'edited'));
      render(); return;
    }

    if (!selected.length) { NF.toast.warn('ยังไม่ได้เลือก'); return; }

    if (act === 'delete') {
      const ok = await NF.modal.confirm({
        title: 'ลบตอนที่เลือก?',
        message: `จะลบ ${selected.length} ตอนถาวร`,
        danger: true, confirmLabel: 'ลบ',
      });
      if (!ok) return;
      ws.chapters = ws.chapters.filter(c => !c._selected);
      await NF.store.saveWorkspace(ws);
      exitBulk();
      NF.toast.success(`ลบ ${selected.length} ตอนแล้ว`);
      return;
    }

    if (act === 'translate') {
      // hand off to auto-tab
      NF.autoTab.startWithSelection(selected.map(c => c.id));
      return;
    }

    if (act === 'credit') {
      const cfg = NF.credit?.load?.();
      if (!cfg?.enabled || !cfg?.translatorName) {
        NF.toast.error('ตั้งค่า Credit ใน Settings ก่อน (เปิดใช้ + ใส่ชื่อ)');
        NF.tabs.activate('settings');
        return;
      }
      const target = selected.filter(c => c.translated);
      if (!target.length) { NF.toast.warn('ตอนที่เลือกยังไม่ได้แปล'); return; }
      const ok = await NF.modal.confirm({
        title: 'ใส่ Credit?',
        message: `จะใส่ credit ใน ${target.length} ตอนที่เลือก (ตอนที่มี credit อยู่แล้วจะถูกแทนที่)`,
        confirmLabel: 'ใส่เลย',
      });
      if (!ok) return;
      try {
        const n = await NF.credit.applyToChapters(ws, target);
        NF.toast.success(`ใส่ credit ${n} ตอน`);
        exitBulk();
      } catch (e) {
        NF.toast.error(e.message);
      }
      return;
    }

    if (act === 'strip-credit') {
      const target = selected.filter(c => c.translated && NF.credit?.has?.(c.translated));
      if (!target.length) { NF.toast.warn('ตอนที่เลือกไม่มี credit'); return; }
      const ok = await NF.modal.confirm({
        title: 'ถอด Credit?',
        message: `จะถอด credit จาก ${target.length} ตอนที่เลือก (เนื้อหาแปลคงเดิม)`,
        danger: true,
        confirmLabel: 'ถอด',
      });
      if (!ok) return;
      const n = await NF.credit.stripFromChapters(ws, target);
      NF.toast.success(`ถอด credit ${n} ตอน`);
      exitBulk();
      return;
    }

    if (act === 'export') {
      NF.importExport.openExportModal(selected.map(c => c.id));
      return;
    }
  }

  async function handleMenuAction(act) {
    if (act === 'import-epub') {
      const f = await NF.pickFile('.epub');
      if (f) await NF.importExport.importEpub(f);
    }
    else if (act === 'import-txt') {
      const fs = await NF.pickFiles('.txt,.zip');
      if (fs.length) await NF.importExport.importTxtOrZip(fs);
    }
    else if (act === 'import-paste') {
      NF.importExport.openPasteModal();
    }
    else if (act === 'export-sel') {
      NF.importExport.openExportModal();
    }
    else if (act === 'renumber') {
      await renumber();
    }
    else if (act === 'bulk-rename') {
      await bulkRename();
    }
    else if (act === 'recover-images') {
      await recoverImages();
    }
    else if (act === 'clean-source') {
      await NF.chapterTools?.cleanAllChapters();
    }
    else if (act === 'line-breaks-all') {
      await NF.chapterTools?.addLineBreaksAllChapters('double');
    }
    else if (act === 'consistency-ws') {
      NF.consistencyCheck?.openForWorkspace();
    }
  }

  async function recoverImages() {
    const ws = NF.state.currentWs;
    if (!ws?.chapters?.length) return;
    let sourceNormalized = 0;
    let recovered = 0;
    let scanned = 0;
    let chaptersAffected = 0;

    for (const ch of ws.chapters) {
      // Step 1: normalize source so future translations see [IMG:]
      if (ch.sourceText) {
        const norm = NF.imageGuard.normalizeMarkup(ch.sourceText);
        if (norm.count > 0 && norm.text !== ch.sourceText) {
          ch.sourceText = norm.text;
          sourceNormalized += norm.count;
          ch.updatedAt = Date.now();
        }
      }

      if (!ch.translated) continue;
      scanned++;

      // Step 2: collect ALL URLs from source — both [IMG:] tokens AND bare
      const tokenUrls = NF.imageGuard.extractUrls(ch.sourceText || '');
      const bareUrls  = NF.imageGuard.findBareImageUrls(ch.sourceText || '');
      // dedupe
      const allSrcUrls = Array.from(new Set([...tokenUrls, ...bareUrls]));
      if (!allSrcUrls.length) continue;

      // Step 3: which are missing from translation?
      const trUrls = new Set([
        ...NF.imageGuard.extractUrls(ch.translated),
        ...NF.imageGuard.findBareImageUrls(ch.translated),
      ]);
      const missing = allSrcUrls.filter(u => !trUrls.has(u));
      if (!missing.length) continue;

      // Step 4: append at end (graceful — user can move them later)
      const tags = missing.map(u => `[IMG: ${u}]`).join('\n\n');
      ch.translated = ch.translated.trimEnd() + '\n\n' + tags;
      ch.updatedAt = Date.now();
      if (ch.status === 'translated') ch.status = 'edited';
      recovered += missing.length;
      chaptersAffected++;
    }

    if (recovered > 0 || sourceNormalized > 0) {
      await NF.store.saveWorkspace(ws);
      render();
    }
    NF.modal.alert({
      title: 'กอบกู้ลิงก์ภาพเสร็จสิ้น',
      message:
        `สแกน ${scanned} ตอน\n` +
        `Normalize source ${sourceNormalized} จุด (URL เปล่า → [IMG:])\n` +
        `กู้รูปที่หายในคำแปล ${recovered} จุด · ${chaptersAffected} ตอน\n\n` +
        `ภาพที่กู้คืนถูก append ไว้ท้ายตอน — ย้ายตำแหน่งเองได้ในตัวแก้ไขตอน`,
    });
    NF.log.info('chapters', 'recover-images', { scanned, sourceNormalized, recovered, chaptersAffected });
  }

  async function renumber() {
    const ws = NF.state.currentWs;
    if (!ws?.chapters?.length) return;
    ws.chapters.forEach((c, i) => c.num = i + 1);
    await NF.store.saveWorkspace(ws);
    render();
    NF.toast.success('จัดลำดับใหม่แล้ว');
  }

  // ═══════════════════════════════════════════════════════
  // Bulk Rename v3 — Editor modal (inspired by NovelTrans เก่า)
  // ───────────────────────────────────────────────────────
  // Flow:
  //  1. Modal แสดง <input> ของชื่อทุกตอน — แก้ได้โดยตรง
  //  2. ปุ่ม "🤖 AI แปลทั้งหมด" → batch ไป AI แล้วเติมค่าลง input
  //     (ไม่แตะ ws.chapters — user ต้องกด Save เอง)
  //  3. Find & Replace แถวเล็ก — live highlight + replace ใน input
  //  4. "💾 บันทึกทั้งหมด" → apply input → ws.chapters ทีเดียว
  // ═══════════════════════════════════════════════════════
  async function bulkRename() {
    const ws = NF.state.currentWs;
    if (!ws?.chapters?.length) { NF.toast.warn('ไม่มีตอน'); return; }

    const sorted = [...ws.chapters].sort((a, b) => (a.num || 0) - (b.num || 0));

    const body = NF.el('div', {});

    // ─── AI toolbar ───
    const aiBtn = NF.el('button', { class: 'btn btn-primary', text: '🤖 AI แปลชื่อทั้งหมด' });
    const modelWrap = NF.el('div', { id: 'brModelWrap', style: { minWidth: '220px' } });
    const statusSpan = NF.el('span', { id: 'brStatus', class: 'dim', style: { fontSize: '12px', fontFamily: 'var(--ff-mono)' }, text: '' });

    body.appendChild(NF.el('div', { style: { display: 'flex', gap: '8px', alignItems: 'center', flexWrap: 'wrap', marginBottom: '8px' } },
      aiBtn, modelWrap, statusSpan,
    ));
    body.appendChild(NF.el('p', { class: 'hint', style: { marginBottom: '12px' },
      text: 'แก้ไขชื่อโดยตรง หรือกด 🤖 เพื่อให้ AI แปลชื่อเป็นไทยทั้งหมด — AI จะดู body ของตอนนั้นด้วยเพื่อแปลได้จังหวะกัน' }));

    // ─── Find & Replace ───
    const frFind    = NF.el('input', { type: 'text', class: 'input', placeholder: 'ค้นหาในชื่อตอน...', id: 'brFrFind',   style: { flex: '1', minWidth: '120px' } });
    const frReplace = NF.el('input', { type: 'text', class: 'input', placeholder: 'แทนที่ด้วย...',     id: 'brFrReplace', style: { flex: '1', minWidth: '120px' } });
    const frCase    = NF.el('input', { type: 'checkbox', id: 'brFrCase' });
    const frInfo    = NF.el('span', { id: 'brFrInfo', class: 'dim', style: { fontSize: '12px', flex: '1' }, text: 'พิมพ์เพื่อค้นหา' });
    const frBtn     = NF.el('button', { class: 'btn-chip primary', text: 'แทนที่ทั้งหมด' });

    body.appendChild(NF.el('div', {
      style: {
        padding: '10px 12px',
        background: 'var(--bg-sunken)',
        border: '1px solid var(--line)',
        borderRadius: 'var(--r-sm)',
        marginBottom: '8px',
      },
    },
      NF.el('div', { style: { fontSize: '12px', color: 'var(--accent)', marginBottom: '6px', fontWeight: '600' }, text: '⇄ Find & Replace ชื่อตอน' }),
      NF.el('div', { style: { display: 'flex', gap: '6px', marginBottom: '6px', flexWrap: 'wrap' } }, frFind, frReplace),
      NF.el('div', { style: { display: 'flex', gap: '12px', alignItems: 'center', flexWrap: 'wrap' } },
        NF.el('label', { class: 'chk-wrap' }, frCase, NF.el('span', { text: 'Case-sensitive' })),
        frInfo, frBtn,
      ),
    ));

    // ─── Chapter list — editable inputs ───
    const listBox = NF.el('div', {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: '4px',
        maxHeight: '380px',
        overflowY: 'auto',
        padding: '6px',
        background: 'var(--bg-sunken)',
        border: '1px solid var(--line)',
        borderRadius: 'var(--r-sm)',
      },
    });
    const inputs = [];
    for (const ch of sorted) {
      const inp = NF.el('input', {
        type: 'text',
        class: 'br-input',
        value: ch.title || '',
        dataset: { id: ch.id },
        style: {
          flex: '1',
          background: 'transparent',
          border: 'none',
          borderBottom: '1px dashed var(--line)',
          color: 'var(--ink)',
          fontSize: '13px',
          padding: '4px 6px',
          outline: 'none',
          transition: 'border-color 150ms',
        },
      });
      inp.addEventListener('focus', () => { inp.style.borderBottomColor = 'var(--accent)'; });
      inp.addEventListener('blur',  () => { inp.style.borderBottomColor = inp.dataset.hit === '1' ? 'var(--accent)' : 'var(--line)'; });
      const row = NF.el('div', {
        style: {
          display: 'flex', alignItems: 'center', gap: '8px',
          padding: '4px 6px',
          background: 'var(--bg-raise)',
          borderRadius: '4px',
        },
      },
        NF.el('span', { style: { minWidth: '36px', fontSize: '11px', color: 'var(--ink-dim)', fontFamily: 'var(--ff-mono)' }, text: '#' + (ch.num || '?') }),
        inp,
      );
      inputs.push({ ch, input: inp });
      listBox.appendChild(row);
    }
    body.appendChild(listBox);

    // ─── Footer buttons ───
    const saveBtn = NF.el('button', { class: 'btn btn-primary', text: '💾 บันทึกทั้งหมด' });
    const cancel = NF.el('button', { class: 'btn btn-ghost', text: 'ยกเลิก' });
    const foot = NF.el('div', {}, cancel, saveBtn);
    const inst = NF.modal.open({ title: '✏ แก้ไขชื่อตอน', body, footer: foot, size: 'lg' });

    // ─── Wire model picker ───
    const modelSel = NF.models.buildSelect({
      currentValue: ws.settings?.glossaryModel || ws.settings?.translateModel,
      onChange: () => {},
    });
    modelWrap.appendChild(modelSel);

    // ─── Wire AI button ───
    const abortCtrl = { ctrl: null };
    aiBtn.onclick = async () => {
      if (abortCtrl.ctrl) {
        abortCtrl.ctrl.abort();
        return;
      }
      await runAiTranslateInputs({ ws, inputs, statusSpan, aiBtn, modelSel, abortCtrl });
    };

    // ─── Wire Find & Replace ───
    const rebuildRe = () => {
      const find = frFind.value;
      if (!find) return null;
      try {
        const escaped = find.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
        return new RegExp(escaped, frCase.checked ? 'g' : 'gi');
      } catch { return null; }
    };
    const updateFrHighlight = () => {
      const re = rebuildRe();
      if (!re) {
        frInfo.textContent = 'พิมพ์เพื่อค้นหา';
        frInfo.style.color = 'var(--ink-dim)';
        inputs.forEach(({ input }) => {
          input.style.background = '';
          input.style.borderBottomColor = 'var(--line)';
          input.dataset.hit = '';
        });
        return;
      }
      let total = 0, chCount = 0;
      inputs.forEach(({ input }) => {
        const v = input.value;
        const hits = (v.match(re) || []).length;
        total += hits;
        if (hits) chCount++;
        input.style.background = hits ? 'rgba(212, 162, 74, 0.1)' : '';
        input.style.borderBottomColor = hits ? 'var(--accent)' : 'var(--line)';
        input.dataset.hit = hits ? '1' : '';
      });
      frInfo.textContent = total ? `พบ ${total} รายการใน ${chCount} ตอน` : 'ไม่พบ';
      frInfo.style.color = total ? 'var(--accent)' : 'var(--err)';
    };
    frFind.addEventListener('input', NF.debounce(updateFrHighlight, 150));
    frCase.addEventListener('change', updateFrHighlight);
    frBtn.onclick = () => {
      const re = rebuildRe();
      if (!re) { NF.toast.warn('ใส่คำค้นหาก่อน'); return; }
      const replaceWith = frReplace.value;
      let total = 0;
      inputs.forEach(({ input }) => {
        const before = input.value;
        const after = before.replace(re, replaceWith);
        if (after !== before) {
          input.value = after;
          total += (before.match(re) || []).length;
          input.style.background = 'rgba(130, 181, 102, 0.14)';
          input.style.borderBottomColor = 'var(--ok)';
        }
      });
      if (total) {
        frInfo.textContent = `แทนที่ ${total} รายการแล้ว ✓`;
        frInfo.style.color = 'var(--ok)';
      } else {
        frInfo.textContent = 'ไม่พบสิ่งที่ต้องแทนที่';
        frInfo.style.color = 'var(--err)';
      }
    };

    // ─── Wire save ───
    cancel.onclick = () => {
      if (abortCtrl.ctrl) abortCtrl.ctrl.abort();
      inst.close();
    };
    saveBtn.onclick = async () => {
      let changed = 0;
      for (const { ch, input } of inputs) {
        const newTitle = NF.translator.cleanupTitle(input.value) || input.value.trim();
        if (!newTitle) continue;
        if (ch.title !== newTitle) {
          ch.title = newTitle;
          ch.translatedTitle = newTitle;   // เก็บทั้งสอง
          ch.updatedAt = Date.now();
          changed++;
        }
      }
      if (changed > 0) {
        await NF.store.saveWorkspace(ws);
        render();
        NF.translateTab?.refreshChapterList?.();
        NF.readTab?.refreshChapterList?.();
        NF.toast.success(`บันทึกชื่อ ${changed} ตอนแล้ว`);
      } else {
        NF.toast.info('ไม่มีการเปลี่ยนแปลง');
      }
      inst.close();
    };
  }

  // ─── AI translate titles ลง inputs (ไม่แตะ ws.chapters) ───
  // ใช้ body ของแต่ละตอนเป็น context ให้ AI แปลได้จังหวะกับเนื้อหา
  async function runAiTranslateInputs({ ws, inputs, statusSpan, aiBtn, modelSel, abortCtrl }) {
    const model = modelSel.value === '__custom__' ? null : modelSel.value;
    if (!model) { NF.toast.error('เลือก model ก่อน'); return; }
    if (!NF.store.getApiKey()) {
      NF.toast.error('ยังไม่ได้ตั้ง API Key');
      return;
    }

    abortCtrl.ctrl = new AbortController();
    aiBtn.textContent = '■ หยุด';
    aiBtn.classList.remove('btn-primary');
    aiBtn.classList.add('btn-danger');

    // batch ตอนใหญ่เพื่อให้ AI เห็นหลายตอนพร้อมกัน → context ต่อเนื่อง
    // แต่ต้อง cap ให้ body ไม่ยาวเกินไป
    const BATCH_BY_COUNT = 8;
    const BODY_SNIPPET_CHARS = 200;   // ส่ง body ต้นๆ กับ AI เพื่อ context
    const targets = inputs.slice();

    let done = 0, failed = 0;

    try {
      for (let i = 0; i < targets.length; i += BATCH_BY_COUNT) {
        if (abortCtrl.ctrl.signal.aborted) break;
        const batch = targets.slice(i, i + BATCH_BY_COUNT);
        const bi = Math.floor(i / BATCH_BY_COUNT) + 1;
        const totalBatches = Math.ceil(targets.length / BATCH_BY_COUNT);
        statusSpan.textContent = `Batch ${bi}/${totalBatches}...`;

        // previous translated titles จาก batch ก่อนหน้า (state ของ input ปัจจุบัน)
        const prev = targets
          .slice(0, i)
          .map(t => ({ src: t.ch.title, cur: t.input.value }))
          .filter(p => p.src && p.cur && p.src !== p.cur)
          .slice(-10);

        const glossaryRelevant = NF.translator.smartGlossary(
          batch.map(b => b.ch.title || '').join(' '),
          ws.glossary || []
        ).slice(0, 40);

        // build prompt
        const prompt = buildBatchTitlePrompt({ ws, batch, prev, glossary: glossaryRelevant, bodyChars: BODY_SNIPPET_CHARS });

        try {
          const res = await NF.api.call({
            model,
            messages: [{ role: 'user', content: prompt }],
            temperature: 0.3,
            max_tokens: Math.max(1500, batch.length * 120),
            signal: abortCtrl.ctrl.signal,
          });
          let raw = (res.choices?.[0]?.message?.content || '').trim();
          raw = raw.replace(/^```(?:json)?\s*/i, '').replace(/\s*```$/, '').trim();

          let parsed = null;
          try {
            parsed = JSON.parse(raw);
          } catch {
            // try to extract [ ... ]
            const m = raw.match(/\[[\s\S]*\]/);
            if (m) { try { parsed = JSON.parse(m[0]); } catch {} }
          }

          if (!Array.isArray(parsed)) {
            // fallback: split by line, strip numbering
            parsed = raw.split('\n')
              .map(l => l.replace(/^\d+\.\s*/, '').replace(/^["']|["']$/g, '').trim())
              .filter(Boolean);
          }

          // apply to inputs
          for (let j = 0; j < batch.length; j++) {
            const translated = parsed[j];
            if (typeof translated === 'string' && translated.trim()) {
              const cleaned = NF.translator.cleanupTitle(translated);
              if (cleaned) {
                batch[j].input.value = cleaned;
                batch[j].input.style.background = 'rgba(130, 181, 102, 0.12)';
                batch[j].input.style.borderBottomColor = 'var(--ok)';
                done++;
                continue;
              }
            }
            failed++;
          }
        } catch (err) {
          if (err.name === 'AbortError') throw err;
          NF.log?.warn('chapters', 'bulk rename batch failed', { err: err.message });
          failed += batch.length;
        }

        statusSpan.textContent = `✓ ${done} · ✗ ${failed} (${Math.min(i + BATCH_BY_COUNT, targets.length)}/${targets.length})`;
      }

      statusSpan.textContent = `เสร็จสิ้น — แปลแล้ว ${done}/${targets.length}` + (failed ? ` (ล้มเหลว ${failed})` : '');
    } catch (err) {
      if (err.name === 'AbortError') {
        statusSpan.textContent = `หยุดแล้ว — ทำเสร็จ ${done}/${targets.length}`;
      } else {
        statusSpan.textContent = '❌ ' + err.message;
      }
    } finally {
      abortCtrl.ctrl = null;
      aiBtn.textContent = '🤖 AI แปลชื่อทั้งหมด';
      aiBtn.classList.remove('btn-danger');
      aiBtn.classList.add('btn-primary');
    }
  }

  // ─── Build prompt for batch title translation with body context ───
  function buildBatchTitlePrompt({ ws, batch, prev, glossary, bodyChars }) {
    const tags = ws?.tags || '';
    const instruction = ws?.instruction || '';
    const registerKey = ws?.settings?.registerDefault || 'neutral';

    const glossaryStr = glossary?.length
      ? glossary.map(g => `• ${g.source} → ${g.thai}${g.type ? ' ('+g.type+')' : ''}`).join('\n')
      : '(ไม่มี)';

    const prevStr = prev?.length
      ? prev.map(p => `  "${p.src}" → "${p.cur}"`).join('\n')
      : '(ไม่มี — เริ่มต้น)';

    // แต่ละตอนส่ง: เลข + source title + body snippet
    const items = batch.map((b, i) => {
      const body = (b.ch.sourceText || '').slice(0, bodyChars).replace(/\n+/g, ' ').trim();
      return `${i + 1}. SOURCE_TITLE: ${b.ch.title || '(empty)'}\n   BODY_OPENING: ${body || '(ไม่มีเนื้อหา)'}`;
    }).join('\n\n');

    return `You are a chapter-title translator for a Thai webnovel${tags ? ` (genre: ${tags})` : ''}.

YOUR TASK: Translate ${batch.length} chapter titles to natural Thai.

CRITICAL CONSISTENCY RULES:
- Same word in SOURCE must translate to SAME Thai word across this batch AND matching the PREVIOUS pairs below.
- Use body opening to understand the story rhythm — the translated title should match the tone of the content (e.g., action scene → punchy title, emotional scene → soft title).
- Use EXACT Thai from GLOSSARY for proper nouns.
- Keep titles concise (under 40 Thai chars). No "ตอนที่ X:" prefix unless source has it.
- If source title is already Thai, keep it as-is.
- Register: ${registerKey}

GLOSSARY (must follow exactly):
${glossaryStr}

PREVIOUS TRANSLATIONS (for consistency — match word choices):
${prevStr}

${instruction ? `NOVEL-SPECIFIC CONTEXT:\n${instruction}\n\n` : ''}CHAPTERS WITH BODY CONTEXT:
${items}

OUTPUT — a pure JSON array of exactly ${batch.length} strings in the same order, no markdown, no commentary:
["translated title 1", "translated title 2", ...]`;
  }

  // ─── Editor modal ───
  function openEditor(id) {
    const ws = NF.state.currentWs;
    if (!ws) return;
    let ch = id ? ws.chapters.find(c => c.id === id) : null;
    const isNew = !ch;
    if (isNew) {
      const nextNum = (ws.chapters.reduce((m, c) => Math.max(m, c.num || 0), 0)) + 1;
      ch = {
        id: NF.genId(),
        num: nextNum,
        title: '',
        sourceText: '',
        translated: '',
        status: 'pending',
        createdAt: Date.now(),
        updatedAt: Date.now(),
      };
    }

    const body = NF.el('div', {});
    body.appendChild(NF.el('div', { class: 'form-grid-2' },
      NF.el('div', { class: 'field' },
        NF.el('span', { text: 'ลำดับ' }),
        NF.el('input', { id: 'edChNum', type: 'number', class: 'input', value: ch.num || '' }),
      ),
      NF.el('div', { class: 'field' },
        NF.el('span', { text: 'สถานะ' }),
        (() => {
          const s = NF.el('select', { id: 'edChStatus', class: 'select' });
          [['pending','ยังไม่แปล'],['translated','แปลแล้ว'],['edited','แก้ไขแล้ว']].forEach(([v,l]) => {
            const o = NF.el('option', { value: v }, l);
            if (ch.status === v) o.selected = true;
            s.appendChild(o);
          });
          return s;
        })(),
      ),
    ));
    body.appendChild(NF.el('div', { class: 'field' },
      NF.el('span', { text: 'ชื่อตอน' }),
      NF.el('input', { id: 'edChTitle', class: 'input', value: ch.title || '' }),
    ));
    body.appendChild(NF.el('div', { class: 'field' },
      NF.el('span', { text: 'Raw (ภาษาต้นฉบับ)' }),
      NF.el('textarea', { id: 'edChSource', class: 'input textarea', rows: 8, text: ch.sourceText || '' }),
    ));
    body.appendChild(NF.el('div', { class: 'field' },
      NF.el('span', { text: 'คำแปล (ภาษาไทย)' }),
      NF.el('textarea', { id: 'edChTr', class: 'input textarea', rows: 8, text: ch.translated || '' }),
    ));

    const ok = NF.el('button', { class: 'btn btn-primary', text: 'บันทึก' });
    const delBtn = NF.el('button', { class: 'btn btn-danger', text: '🗑 ลบ', style: isNew ? { display: 'none' } : {} });
    const cancel = NF.el('button', { class: 'btn btn-ghost', text: 'ยกเลิก' });

    // credit toggle button (only when chapter has translation)
    const hasCreditNow = !isNew && ch.translated && NF.credit?.has?.(ch.translated);
    const creditBtn = NF.el('button', {
      class: 'btn btn-ghost',
      text: hasCreditNow ? '🧹 ถอด Credit' : '✒ ใส่ Credit',
      style: (isNew || !ch.translated) ? { display: 'none' } : {},
    });

    const foot = NF.el('div', {}, delBtn, NF.el('span', { class: 'spacer' }), creditBtn, cancel, ok);
    const inst = NF.modal.open({ title: isNew ? 'เพิ่มตอนใหม่' : `แก้ไข: ${ch.title || '#' + ch.num}`, body, footer: foot, size: 'lg' });
    cancel.onclick = () => inst.close();
    creditBtn.onclick = async () => {
      const ta = $('#edChTr');
      if (!ta.value.trim()) { NF.toast.warn('ยังไม่มีคำแปล'); return; }
      const cfg = NF.credit?.load?.();
      if (NF.credit.has(ta.value)) {
        ta.value = NF.credit.stripExisting(ta.value);
        creditBtn.textContent = '✒ ใส่ Credit';
        NF.toast.success('ถอดแล้ว — กดบันทึกเพื่อยืนยัน');
      } else {
        if (!cfg?.enabled || !cfg?.translatorName) {
          NF.toast.error('ตั้งค่า Credit ใน Settings ก่อน');
          NF.tabs.activate('settings');
          return;
        }
        ta.value = NF.credit.apply(ta.value, { chapter: ch, ws });
        creditBtn.textContent = '🧹 ถอด Credit';
        NF.toast.success('ใส่แล้ว — กดบันทึกเพื่อยืนยัน');
      }
    };
    ok.onclick = async () => {
      ch.num = parseInt($('#edChNum').value, 10) || ch.num;
      ch.title = $('#edChTitle').value.trim();
      ch.sourceText = $('#edChSource').value;
      ch.translated = $('#edChTr').value;
      ch.status = $('#edChStatus').value;
      ch.updatedAt = Date.now();
      if (isNew) ws.chapters.push(ch);
      await NF.store.saveWorkspace(ws);
      inst.close();
      render();
      NF.toast.success(isNew ? 'เพิ่มตอนแล้ว' : 'บันทึกแล้ว');
    };
    delBtn.onclick = async () => {
      const yes = await NF.modal.confirm({ title: 'ลบตอนนี้?', message: `"${ch.title || '#'+ch.num}" จะถูกลบถาวร`, danger: true, confirmLabel: 'ลบ' });
      if (!yes) return;
      ws.chapters = ws.chapters.filter(c => c.id !== ch.id);
      await NF.store.saveWorkspace(ws);
      inst.close();
      render();
      NF.toast.success('ลบแล้ว');
    };
  }

  return { init, render, openEditor };
})();

/* ═══════════════════════════════════════════════════════
   chapters-tools.js (appended) — Clean Source + Line Breaks
   ═══════════════════════════════════════════════════════ */

NF.chapterTools = (function() {

  // ─── Clean Source Text ───
  // ลบ Base64 string ยาวๆ / URL ที่ติดมากับ source text
  function cleanSourceStr(text) {
    return text
      .replace(/[A-Za-z0-9+/]{20,}={0,2}/g, '')   // Base64
      .replace(/https?:\/\/\S+/g, '')              // URL
      .replace(/[ \t]{2,}/g, ' ')                  // ช่องว่างซ้ำ
      .replace(/\n{3,}/g, '\n\n')                  // blank lines เกิน
      .trim();
  }

  // Clean source text ของตอนเดียว (เรียกจาก chapter editor)
  async function cleanCurrentChapter(chId) {
    const ws = NF.state.currentWs;
    if (!ws) return;
    const ch = ws.chapters.find(c => c.id === chId);
    if (!ch?.sourceText) { NF.toast.warn('ไม่มี source text'); return; }
    const cleaned = cleanSourceStr(ch.sourceText);
    if (cleaned === ch.sourceText) { NF.toast.info('ไม่พบสิ่งที่ต้องลบ'); return; }
    const removed = ch.sourceText.length - cleaned.length;
    const ok = await NF.modal.confirm({
      title: '🧹 ล้าง Source Text?',
      message: `จะลบ ${removed.toLocaleString()} ตัวอักษร (Base64/URL ที่ติดมา)`,
      confirmLabel: 'ล้างเลย',
    });
    if (!ok) return;
    ch.sourceText = cleaned;
    ch.updatedAt  = Date.now();
    await NF.store.saveWorkspace(ws);
    NF.toast.success(`🧹 ลบออก ${removed.toLocaleString()} ตัวอักษร`);
    return cleaned;
  }

  // Clean source text ทุกตอนใน workspace
  async function cleanAllChapters() {
    const ws = NF.state.currentWs;
    if (!ws) return;
    const ok = await NF.modal.confirm({
      title: '🧹 ล้าง Source Text ทุกตอน?',
      message: 'จะลบ Base64/URL ที่ติดมาใน sourceText ทุกตอน ไม่กระทบคำแปล',
      confirmLabel: 'ล้างทั้งหมด',
    });
    if (!ok) return;
    let affected = 0, totalRemoved = 0;
    ws.chapters.forEach(ch => {
      if (!ch.sourceText) return;
      const cleaned = cleanSourceStr(ch.sourceText);
      if (cleaned !== ch.sourceText) {
        totalRemoved += ch.sourceText.length - cleaned.length;
        ch.sourceText = cleaned;
        ch.updatedAt  = Date.now();
        affected++;
      }
    });
    if (!affected) { NF.toast.info('ไม่พบสิ่งที่ต้องลบ'); return; }
    await NF.store.saveWorkspace(ws);
    NF.chapters?.render();
    NF.toast.success(`🧹 ลบออก ${totalRemoved.toLocaleString()} ตัวอักษร จาก ${affected} ตอน`);
  }

  // ─── Add Line Breaks ───
  // เพิ่ม blank line ระหว่างทุก paragraph ใน translated text
  function addLineBreaksStr(text) {
    return text
      .split('\n')
      .map(l => l.trimEnd())
      .join('\n\n')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }

  // Add 1 extra newline between existing paragraph breaks
  function addOneLineStr(text) {
    return text.replace(/\n+/g, m => m + '\n').replace(/\n{3,}/g, '\n\n').trim();
  }

  // เพิ่ม line break ทุกตอนใน workspace
  async function addLineBreaksAllChapters(mode = 'double') {
    const ws = NF.state.currentWs;
    if (!ws) return;
    const fn = mode === 'double' ? addLineBreaksStr : addOneLineStr;
    const label = mode === 'double' ? 'เพิ่ม Line Break' : 'Add 1 Line';
    const ok = await NF.modal.confirm({
      title: `📐 ${label} ทุกตอน?`,
      message: 'จะเพิ่ม blank line ใน translated text ทุกตอน ไม่สามารถย้อนกลับได้',
      confirmLabel: label,
    });
    if (!ok) return;
    let affected = 0;
    ws.chapters.forEach(ch => {
      if (!ch.translated) return;
      const result = fn(ch.translated);
      if (result !== ch.translated) { ch.translated = result; affected++; }
    });
    if (!affected) { NF.toast.info('ทุกตอนมี Line Break แล้ว'); return; }
    await NF.store.saveWorkspace(ws);
    NF.toast.success(`📐 ${label} ใน ${affected} ตอน ✓`);
  }

  // เพิ่ม line break ใน translated output บนหน้าแปล (translate tab)
  function addLineBreaksOutput(mode = 'double') {
    const el = document.getElementById('translationOutput');
    if (!el) return;
    const text = el.innerText?.trim() || '';
    if (!text) { NF.toast.warn('ยังไม่มีคำแปล'); return; }
    const fn   = mode === 'double' ? addLineBreaksStr : addOneLineStr;
    const result = fn(text);
    if (result === text) { NF.toast.info('ไม่มีอะไรเปลี่ยน'); return; }
    el.innerText = result;
    NF.toast.success('📐 เพิ่ม Line Break แล้ว');
  }

  return {
    cleanSourceStr,
    cleanCurrentChapter,
    cleanAllChapters,
    addLineBreaksStr,
    addOneLineStr,
    addLineBreaksAllChapters,
    addLineBreaksOutput,
  };
})();

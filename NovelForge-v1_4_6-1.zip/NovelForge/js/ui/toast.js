/* ═══════════════════════════════════════════════════════
   toast.js — notification stack
   ═══════════════════════════════════════════════════════ */

NF.toast = (function() {
  function show(msg, type = '', duration = 3200) {
    const stack = document.getElementById('toastStack');
    if (!stack) return;
    const t = NF.el('div', { class: 'toast ' + (type || ''), text: msg });
    stack.appendChild(t);
    setTimeout(() => {
      t.style.animation = 'toastOut 200ms ease forwards';
      setTimeout(() => t.remove(), 200);
    }, duration);
  }
  return {
    info(m, d)    { show(m, '', d); },
    success(m, d) { show(m, 'success', d); },
    error(m, d)   { show(m, 'error', d || 5000); },
    warn(m, d)    { show(m, 'warn', d); },
  };
})();

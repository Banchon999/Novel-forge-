/* ═══════════════════════════════════════════════════════
   modal.js — Modal system
   ═══════════════════════════════════════════════════════ */

NF.modal = (function() {

  let _activeEl = null;

  // open({ title, body (HTMLElement|string), footer (HTMLElement|null), size: 'md'|'lg'|'xl', onClose })
  function open(opts = {}) {
    const root = document.getElementById('modalRoot');

    const backdrop = NF.el('div', { class: 'modal-backdrop', onclick: (e) => {
      if (e.target === backdrop && opts.dismissOnBackdrop !== false) close();
    }});

    const modal = NF.el('div', { class: 'modal' + (opts.size ? ' ' + opts.size : '') });

    // head
    const head = NF.el('div', { class: 'modal-head' },
      NF.el('div', { class: 'modal-title', text: opts.title || '' }),
      NF.el('button', { class: 'icon-btn close-btn', onclick: close }, '✕'),
    );
    modal.appendChild(head);

    // body
    const body = NF.el('div', { class: 'modal-body' });
    if (typeof opts.body === 'string') body.innerHTML = opts.body;
    else if (opts.body instanceof Node) body.appendChild(opts.body);
    modal.appendChild(body);

    // footer
    if (opts.footer) {
      const foot = NF.el('div', { class: 'modal-foot' });
      if (opts.footer instanceof Node) foot.appendChild(opts.footer);
      else foot.innerHTML = opts.footer;
      modal.appendChild(foot);
    }

    backdrop.appendChild(modal);
    root.appendChild(backdrop);
    _activeEl = backdrop;

    // esc to close
    const onKey = (e) => { if (e.key === 'Escape') close(); };
    document.addEventListener('keydown', onKey);

    function close() {
      if (!backdrop.parentNode) return;
      backdrop.style.animation = 'bdIn 180ms ease reverse';
      setTimeout(() => {
        backdrop.remove();
        document.removeEventListener('keydown', onKey);
        if (_activeEl === backdrop) _activeEl = null;
        opts.onClose && opts.onClose();
      }, 150);
    }

    return { close, modal, body };
  }

  function confirm({ title = 'ยืนยัน?', message = '', danger = false, confirmLabel = 'ยืนยัน', cancelLabel = 'ยกเลิก' }) {
    return new Promise((resolve) => {
      const body = NF.el('p', { style: { margin: 0, lineHeight: 1.7 }, text: message });
      const confirmBtn = NF.el('button', { class: danger ? 'btn btn-danger' : 'btn btn-primary', text: confirmLabel });
      const cancelBtn  = NF.el('button', { class: 'btn btn-ghost', text: cancelLabel });
      const foot = NF.el('div', {}, cancelBtn, confirmBtn);
      const inst = open({ title, body, footer: foot, onClose: () => resolve(false), size: null });
      confirmBtn.onclick = () => { resolve(true); inst.close(); };
      cancelBtn.onclick  = () => { resolve(false); inst.close(); };
    });
  }

  function prompt({ title = 'กรุณากรอก', message = '', value = '', placeholder = '', okLabel = 'ตกลง' }) {
    return new Promise((resolve) => {
      const input = NF.el('input', { class: 'input', value, placeholder, style: { marginTop: '8px' } });
      const body = NF.el('div', {});
      if (message) body.appendChild(NF.el('p', { style: { margin: '0 0 6px' }, text: message }));
      body.appendChild(input);
      const okBtn = NF.el('button', { class: 'btn btn-primary', text: okLabel });
      const cBtn = NF.el('button', { class: 'btn btn-ghost', text: 'ยกเลิก' });
      const foot = NF.el('div', {}, cBtn, okBtn);
      const inst = open({ title, body, footer: foot, onClose: () => resolve(null) });
      okBtn.onclick = () => { resolve(input.value); inst.close(); };
      cBtn.onclick  = () => { resolve(null); inst.close(); };
      setTimeout(() => input.focus(), 100);
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { resolve(input.value); inst.close(); } });
    });
  }

  function alert({ title = 'แจ้งเตือน', message = '' }) {
    return new Promise((resolve) => {
      const body = NF.el('p', { style: { margin: 0, lineHeight: 1.7 }, text: message });
      const okBtn = NF.el('button', { class: 'btn btn-primary', text: 'เข้าใจแล้ว' });
      const foot = NF.el('div', {}, okBtn);
      const inst = open({ title, body, footer: foot, onClose: () => resolve() });
      okBtn.onclick = () => { resolve(); inst.close(); };
    });
  }

  return { open, confirm, prompt, alert };
})();

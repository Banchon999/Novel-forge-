/* ═══════════════════════════════════════════════════════
   util.js — DOM shortcuts + formatters
   ═══════════════════════════════════════════════════════ */

NF.$  = (sel, root) => (root || document).querySelector(sel);
NF.$$ = (sel, root) => Array.from((root || document).querySelectorAll(sel));

NF.el = function(tag, attrs = {}, ...children) {
  const e = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class')        e.className = v;
    else if (k === 'html')    e.innerHTML = v;
    else if (k === 'text')    e.textContent = v;
    else if (k === 'style' && typeof v === 'object') Object.assign(e.style, v);
    else if (k === 'dataset') for (const [dk, dv] of Object.entries(v)) e.dataset[dk] = dv;
    else if (k.startsWith('on') && typeof v === 'function') e.addEventListener(k.slice(2).toLowerCase(), v);
    else if (v === false || v == null) continue;
    else e.setAttribute(k, v === true ? '' : v);
  }
  for (const c of children.flat()) {
    if (c == null || c === false) continue;
    if (typeof c === 'string') e.appendChild(document.createTextNode(c));
    else e.appendChild(c);
  }
  return e;
};

NF.fmt = {
  num(n, d = 0) { return Number(n).toLocaleString(undefined, { minimumFractionDigits: d, maximumFractionDigits: d }); },
  usd(n) { return '$' + Number(n).toFixed(2); },
  date(ts) {
    if (!ts) return '—';
    const d = new Date(ts);
    return d.toLocaleDateString('th-TH', { year: 'numeric', month: 'short', day: 'numeric' });
  },
  timeAgo(ts) {
    if (!ts) return '—';
    const diff = Date.now() - ts;
    if (diff < 60_000) return 'เมื่อกี้';
    if (diff < 3_600_000) return Math.floor(diff / 60000) + ' นาทีก่อน';
    if (diff < 86_400_000) return Math.floor(diff / 3_600_000) + ' ชม.ก่อน';
    const d = Math.floor(diff / 86_400_000);
    if (d < 30) return d + ' วันก่อน';
    return new Date(ts).toLocaleDateString('th-TH');
  },
  chars(s) {
    if (!s) return '0 ตัวอักษร';
    return `${Number(s.length).toLocaleString()} ตัวอักษร`;
  },
};

NF.debounce = function(fn, ms = 200) {
  let t;
  return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
};

NF.download = function(bytes, filename, mime = 'application/octet-stream') {
  const blob = (bytes instanceof Blob) ? bytes : new Blob([bytes], { type: mime });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.style.display = 'none';
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(url); a.remove(); }, 100);
};

NF.pickFile = function(accept) {
  return new Promise((res) => {
    const input = document.createElement('input');
    input.type = 'file';
    if (accept) input.accept = accept;
    input.onchange = () => res(input.files[0] || null);
    input.click();
  });
};

NF.pickFiles = function(accept) {
  return new Promise((res) => {
    const input = document.createElement('input');
    input.type = 'file';
    input.multiple = true;
    if (accept) input.accept = accept;
    input.onchange = () => res(Array.from(input.files || []));
    input.click();
  });
};

NF.readText = function(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = () => rej(r.error);
    r.readAsText(file);
  });
};
NF.readBuf = function(file) {
  return new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(r.result);
    r.onerror = () => rej(r.error);
    r.readAsArrayBuffer(file);
  });
};

NF.slug = function(s) {
  return String(s || '')
    .trim()
    .replace(/[\/\\:*?"<>|]/g, '_')
    .slice(0, 80);
};

/* Safely read a checkbox's checked state. If the element does not exist
   (version mismatch, removed UI, etc.) return fallback instead of crashing. */
NF.isChecked = function(sel, fallback = false) {
  const el = typeof sel === 'string' ? NF.$(sel) : sel;
  if (!el) return fallback;
  return el.checked === true;
};

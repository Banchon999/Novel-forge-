/* ═══════════════════════════════════════════════════════
   tabs.js — tab bar behavior
   ═══════════════════════════════════════════════════════ */

NF.tabs = (function() {

  function init() {
    const btns = NF.$$('.tab-btn');
    btns.forEach(b => {
      b.onclick = () => activate(b.dataset.tab);
    });
    NF.$('#btnSettings').onclick = () => activate('settings');
  }

  function activate(name) {
    NF.state.activeTab = name;
    NF.$$('.tab-btn').forEach(b => b.classList.toggle('active', b.dataset.tab === name));
    NF.$$('.tab-panel').forEach(p => p.classList.toggle('active', p.dataset.panel === name));
    NF.emit('tab:changed', { name });
  }

  return { init, activate };
})();

/* ═══════════════════════════════════════════════════════
   sidebar.js — workspace list + controls
   ═══════════════════════════════════════════════════════ */

NF.sidebar = (function() {

  const $ = NF.$;

  function init() {
    $('#btnSidebar').onclick = open;
    $('#btnCloseSidebar').onclick = close;
    $('#sidebarBackdrop').onclick = close;

    $('#btnNewWs').onclick = () => {
      NF.workspace.promptCreate();
    };
    $('#btnImportWs').onclick = () => $('#importWsFile').click();
    $('#importWsFile').onchange = async (e) => {
      const file = e.target.files?.[0];
      if (!file) return;
      e.target.value = '';
      await NF.workspace.importFromFile(file);
    };
    $('#btnExportAllWs').onclick = exportAll;

    NF.on('ws:listChanged', render);
    NF.on('ws:selected', render);
  }

  function open() {
    NF.state.sidebarOpen = true;
    $('#sidebar').classList.add('open');
    $('#sidebarBackdrop').classList.add('open');
    render();
  }

  function close() {
    NF.state.sidebarOpen = false;
    $('#sidebar').classList.remove('open');
    $('#sidebarBackdrop').classList.remove('open');
  }

  async function render() {
    const list = await NF.store.listWorkspaces();
    const box = $('#wsList');
    box.innerHTML = '';
    if (!list.length) {
      box.appendChild(NF.el('div', {
        style: { padding: '28px 12px', textAlign: 'center', color: 'var(--ink-dim)', fontSize: '13px' },
        text: 'ยังไม่มี Workspace',
      }));
      return;
    }
    const curId = NF.state.currentWs?.id;
    for (const ws of list) {
      const totalCh = ws.chapters?.length || 0;
      const pending = (ws.chapters || []).filter(c => c.status !== 'translated' && c.status !== 'edited').length;
      const item = NF.el('div', { class: 'ws-item' + (curId === ws.id ? ' active' : ''), onclick: () => {
        NF.workspace.select(ws.id);
        close();
      }},
        NF.el('div', { class: 'ws-item-title', text: ws.title || 'Untitled' }),
        NF.el('div', { class: 'ws-item-meta' },
          NF.el('span', { class: 'ch', text: `${totalCh} ตอน` }),
          pending > 0 ? NF.el('span', { class: 'pd', text: `${pending} ยังไม่แปล` }) : null,
          NF.el('span', { class: '', text: NF.fmt.timeAgo(ws.updatedAt) }),
        ),
      );
      box.appendChild(item);
    }
  }

  async function exportAll() {
    const list = await NF.store.listWorkspaces();
    if (!list.length) { NF.toast.warn('ยังไม่มี workspace'); return; }
    const data = { _novelforge_backup: true, ts: Date.now(), workspaces: list };
    NF.download(JSON.stringify(data, null, 2), `novelforge-backup-${new Date().toISOString().slice(0,10)}.json`, 'application/json');
    NF.store.markBackup();
    NF.toast.success(`Export ${list.length} workspace แล้ว`);
  }

  return { init, open, close, render, exportAll };
})();

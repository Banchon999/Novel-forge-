/* ═══════════════════════════════════════════════════════
   credit.js — Translator credit watermark
   ───────────────────────────────────────────────────────
   เป้าหมาย:
   1. แทรก credit แบบที่กัน "find & replace ครั้งเดียวลบหมด"
      ได้ — โดยใช้ pattern ที่ random ไม่ซ้ำกันทุกครั้ง
   2. เก็บแยก เป็น "บล็อก credit" ที่ append ตอนท้าย
      (และ optional ตอนต้น) ไม่ปนกับเนื้อหาที่ AI แปลมา
   3. Zero-width signature ฝังในบล็อก credit เพื่อ proof
      (ผู้ดูดที่รู้เรื่องสามารถลบได้ — ออกแบบมากันคนทั่วไป)

   จุดกดใช้:
   - Auto: เปิดใน settings → ใส่หลัง marathon เสร็จ + หลัง translate เดี่ยว
   - Manual: ปุ่มใน chapter editor / bulk action

   เก็บค่าใน localStorage (Global, แชร์ทั้งแอป)
   ═══════════════════════════════════════════════════════ */

NF.credit = (function() {

  const LS_KEY = 'nf_credit_config';
  // marker = ZWJ ZWJ ZWJ (× 3) — ไม่ใช้ใน encoding (encoding ใช้ ZWSP=0, ZWNJ=1)
  // ดังนั้น marker จะไม่เกิดเป็น sub-sequence ของ payload แน่นอน
  const MARKER_OPEN  = '\u200D\u200D\u200D';
  const MARKER_CLOSE = '\u200D\u200D\u200D';

  // ─── default config ───
  function defaults() {
    return {
      enabled: false,
      translatorName: '',          // ชื่อนักแปล/นามปากกา
      contact: '',                 // ลิงก์/IG/เว็บ
      message: '',                 // ข้อความเสริม เช่น "ถ้าชอบ ฝากกดติดตาม"
      placement: 'footer',         // 'footer' | 'header' | 'both'
      autoApplyOnTranslate: false, // ใส่ตอนแปลเสร็จ (เดี่ยว + marathon)
      randomStyle: true,           // สุ่ม pattern ทุกครั้ง
      includeChapterInfo: true,    // ใส่ #ตอน · ชื่อเรื่อง
      separator: 'auto',           // 'auto' | 'minimal' | 'box' | 'line'
    };
  }

  function load() {
    try {
      const raw = localStorage.getItem(LS_KEY);
      if (!raw) return defaults();
      return { ...defaults(), ...JSON.parse(raw) };
    } catch { return defaults(); }
  }

  function save(cfg) {
    localStorage.setItem(LS_KEY, JSON.stringify(cfg));
  }

  // ─── Pattern generators (สุ่มไม่ซ้ำ) ───
  // คนทั่วไป find & replace บรรทัดนึงไม่หมด เพราะ pattern ต่างกัน

  // ตัวคั่นบนล่าง — สุ่มจากชุดที่หลากหลาย
  const SEPARATORS_TOP = [
    '═══════════════════════════',
    '─── ❖ ───',
    '· · ·  ✦  · · ·',
    '━━━━━━━━━━━━━━',
    '◆ ◆ ◆',
    '~ ~ ~ ❀ ~ ~ ~',
    '▱▰▱▰▱▰▱▰▱▰▱▰',
    '✿  ✿  ✿',
    '═════════ ❦ ═════════',
    '· · · · · · · · ·',
  ];

  const SEPARATORS_BOTTOM = [
    '═══════════════════════════',
    '─── ❖ ───',
    '✦ · · · · · · ✦',
    '━━━━━━━━━━━━━━',
    '◆ ◆ ◆',
    '~ ~ ~ ❀ ~ ~ ~',
    '▰▱▰▱▰▱▰▱▰▱▰▱',
    '✿  ✿  ✿',
    '═════════ ❦ ═════════',
    '· · · · · · · · ·',
  ];

  // ป้ายชื่อหัวบล็อก — สุ่มเลือก
  const TAG_VARIANTS = [
    '✒ แปลโดย',
    '❖ แปล',
    '✿ ผู้แปล',
    '◈ Translator',
    '☘ แปลและเรียบเรียง',
    '⚜ ฝีมือแปล',
    '✎ แปลไทยโดย',
    '❀ Translation',
  ];

  // ป้าย optional ข้อความเสริม
  const MESSAGE_PREFIX = ['', '✦ ', '· ', '— ', '☆ ', ''];

  function pick(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
  }

  // ─── Zero-width signature ───
  // ฝังชื่อนักแปลเป็น binary ใน zero-width chars
  // (กันคนที่ไม่รู้เทคนิคนี้ — คนรู้ลบได้ง่ายด้วย regex)
  function buildZWSignature(name) {
    if (!name) return '';
    // encode ชื่อเป็น hex แล้วแทนแต่ละ bit ด้วย ZWSP/ZWNJ
    const bytes = new TextEncoder().encode(name);
    let bits = '';
    for (const b of bytes) {
      bits += b.toString(2).padStart(8, '0');
    }
    let out = MARKER_OPEN;
    for (const ch of bits) {
      out += ch === '0' ? '\u200B' : '\u200C';   // ZWSP = 0, ZWNJ = 1
    }
    out += MARKER_CLOSE;
    return out;
  }

  // อ่าน signature กลับ (ใช้ตรวจว่าใครแปล)
  function readZWSignature(text) {
    if (!text) return null;
    // open == close → ใช้ non-greedy + escape ทุก char
    const reStr = MARKER_OPEN + '([\\u200B\\u200C]+?)' + MARKER_CLOSE;
    const re = new RegExp(reStr);
    const m = text.match(re);
    if (!m) return null;
    let bits = '';
    for (const ch of m[1]) {
      bits += ch === '\u200B' ? '0' : '1';
    }
    if (bits.length % 8 !== 0) return null;
    const bytes = [];
    for (let i = 0; i < bits.length; i += 8) {
      bytes.push(parseInt(bits.slice(i, i + 8), 2));
    }
    try {
      return new TextDecoder().decode(new Uint8Array(bytes));
    } catch { return null; }
  }

  // ─── Build credit block ───
  // ส่งกลับเป็น string — แยกบล็อกชัดเจน คั่นด้วยบรรทัดว่าง
  function buildBlock({ chapter, ws, position }) {
    const cfg = load();
    if (!cfg.enabled || !cfg.translatorName) return '';

    const lines = [];
    const sep = cfg.randomStyle
      ? (position === 'top' ? pick(SEPARATORS_TOP) : pick(SEPARATORS_BOTTOM))
      : '═══════════════════════════';
    const tag = cfg.randomStyle ? pick(TAG_VARIANTS) : '✒ แปลโดย';
    const msgPrefix = cfg.randomStyle ? pick(MESSAGE_PREFIX) : '';

    lines.push(sep);

    // chapter info (optional)
    if (cfg.includeChapterInfo && chapter) {
      const chTitle = chapter.title || `ตอนที่ ${chapter.num || '?'}`;
      const wsTitle = ws?.title || '';
      // สลับ format ทุกครั้ง
      const fmts = [
        `${wsTitle}${wsTitle ? ' · ' : ''}${chTitle}`,
        `[${chTitle}]${wsTitle ? ' — ' + wsTitle : ''}`,
        `${chTitle}${wsTitle ? ` (${wsTitle})` : ''}`,
      ];
      lines.push(cfg.randomStyle ? pick(fmts) : fmts[0]);
    }

    // translator name (always)
    lines.push(`${tag}: ${cfg.translatorName}`);

    if (cfg.contact) {
      const cFmts = [
        `📌 ${cfg.contact}`,
        `→ ${cfg.contact}`,
        `· ${cfg.contact}`,
        cfg.contact,
      ];
      lines.push(cfg.randomStyle ? pick(cFmts) : cFmts[0]);
    }

    if (cfg.message) {
      lines.push(`${msgPrefix}${cfg.message}`);
    }

    // close separator
    lines.push(sep);

    // zero-width signature inside the block (ผูกกับ separator)
    const zwSig = buildZWSignature(cfg.translatorName);
    if (zwSig) {
      // วาง zw sig แทรกในบรรทัด separator ด้วย — ลบยากขึ้นหน่อย
      lines[0] = lines[0] + zwSig;
    }

    return lines.join('\n');
  }

  // ─── Apply credit to chapter text ───
  // ส่งกลับ string ใหม่ ไม่ mutate
  function apply(translatedText, { chapter, ws } = {}) {
    const cfg = load();
    if (!cfg.enabled || !cfg.translatorName) return translatedText;

    // ลบ credit เก่า (ถ้ามี) ก่อนใส่ใหม่ — กันใส่ซ้อน
    let text = stripExisting(translatedText);

    const placement = cfg.placement || 'footer';
    if (placement === 'header' || placement === 'both') {
      const top = buildBlock({ chapter, ws, position: 'top' });
      if (top) text = top + '\n\n' + text;
    }
    if (placement === 'footer' || placement === 'both') {
      const bot = buildBlock({ chapter, ws, position: 'bottom' });
      if (bot) text = text.trimEnd() + '\n\n' + bot;
    }
    return text;
  }

  // ─── Detect & strip credit blocks ───
  // หา block ที่ฝัง zw signature → ลบทั้งบล็อก
  // (รวมถึงเส้น separator ที่ติดกัน)
  function stripExisting(text) {
    if (!text) return text;
    // หา zw signature → backtrack หา blank line ก่อนหน้า → ตัด
    const sigRe = new RegExp(MARKER_OPEN + '[\\u200B\\u200C]+?' + MARKER_CLOSE, 'g');
    const matches = [...text.matchAll(sigRe)];
    if (!matches.length) return text;

    let out = text;
    // ลบจากท้ายไปต้น เพื่อไม่ต้องคำนวณ index ใหม่
    for (let i = matches.length - 1; i >= 0; i--) {
      const m = matches[i];
      const sigPos = m.index;
      // หา blank line ก่อนหน้า (\n\n) — เป็นจุดเริ่มของบล็อก
      const before = out.slice(0, sigPos);
      const blockStart = before.lastIndexOf('\n\n');
      const startCut = blockStart >= 0 ? blockStart : 0;
      // หา blank line ถัดจาก signature — เป็นจุดจบของบล็อก
      const afterSig = out.indexOf('\n\n', sigPos);
      const endCut = afterSig >= 0 ? afterSig : out.length;
      out = out.slice(0, startCut) + out.slice(endCut);
    }
    return out.trimEnd();
  }

  // ─── Detect: มี credit ใน text มั้ย ───
  function has(text) {
    if (!text) return false;
    const re = new RegExp(MARKER_OPEN + '[\\u200B\\u200C]+' + MARKER_CLOSE);
    return re.test(text);
  }

  // ─── Apply to many chapters ───
  async function applyToChapters(ws, chapters) {
    const cfg = load();
    if (!cfg.enabled || !cfg.translatorName) {
      throw new Error('ยังไม่ได้เปิด/ตั้งค่า Credit นักแปล');
    }
    let n = 0;
    for (const ch of chapters) {
      if (!ch.translated) continue;
      ch.translated = apply(ch.translated, { chapter: ch, ws });
      ch.updatedAt = Date.now();
      if (ch.status === 'translated') ch.status = 'edited';
      n++;
    }
    if (n > 0) await NF.store.saveWorkspace(ws);
    return n;
  }

  async function stripFromChapters(ws, chapters) {
    let n = 0;
    for (const ch of chapters) {
      if (!ch.translated || !has(ch.translated)) continue;
      ch.translated = stripExisting(ch.translated);
      ch.updatedAt = Date.now();
      n++;
    }
    if (n > 0) await NF.store.saveWorkspace(ws);
    return n;
  }

  return {
    load, save, defaults,
    apply, stripExisting, has,
    applyToChapters, stripFromChapters,
    readZWSignature,
    // exposed for debug
    _buildBlock: buildBlock,
    _buildZWSignature: buildZWSignature,
  };
})();

/* ═══════════════════════════════════════════════════════
   log.js — Dev log system
   ───────────────────────────────────────────────────────
   Ring buffer of log entries with levels (debug/info/warn/error).
   Every entry also mirrors to console. Settings panel can
   view live, filter, copy, and download as .txt.

   Usage:
     NF.log.info('module', 'message', { optionalData })
     NF.log.error('marathon', 'worker crashed', err)
     NF.log.dbg('translator', 'chunk split', { count })
   ═══════════════════════════════════════════════════════ */

NF.log = (function() {

  const MAX = 2000;
  const buf = [];
  const subs = new Set();
  let seq = 0;

  function write(level, tag, msg, data) {
    const entry = {
      seq: ++seq,
      ts: Date.now(),
      level,
      tag: String(tag || '—'),
      msg: String(msg || ''),
      data: data !== undefined ? safeSerialize(data) : undefined,
    };
    buf.push(entry);
    if (buf.length > MAX) buf.shift();

    // mirror to console
    const label = `[NF:${tag}]`;
    const args = data !== undefined ? [label, msg, data] : [label, msg];
    if (level === 'error')      console.error(...args);
    else if (level === 'warn')  console.warn(...args);
    else if (level === 'debug') console.debug(...args);
    else                        console.log(...args);

    // notify subscribers
    for (const fn of subs) {
      try { fn(entry); } catch {}
    }
    return entry;
  }

  function safeSerialize(v) {
    if (v == null) return v;
    if (v instanceof Error) {
      return { _error: true, name: v.name, message: v.message, stack: v.stack };
    }
    if (typeof v === 'function') return '[function]';
    try {
      // round-trip to strip circular & non-JSON content
      return JSON.parse(JSON.stringify(v));
    } catch {
      try { return String(v); } catch { return '[unserializable]'; }
    }
  }

  function list(filter = {}) {
    let out = buf;
    if (filter.level) out = out.filter(e => matchLevel(e.level, filter.level));
    if (filter.tag)   out = out.filter(e => e.tag === filter.tag);
    if (filter.q) {
      const q = filter.q.toLowerCase();
      out = out.filter(e => e.msg.toLowerCase().includes(q) || e.tag.toLowerCase().includes(q));
    }
    return out;
  }

  // level filter: 'error' → errors only; 'warn' → warn+error; 'info' → info+warn+error; '' → all
  function matchLevel(actual, min) {
    const order = { debug: 0, info: 1, warn: 2, error: 3 };
    return (order[actual] ?? 0) >= (order[min] ?? 0);
  }

  function clear() {
    buf.length = 0;
    for (const fn of subs) { try { fn({ _cleared: true }); } catch {} }
  }

  function subscribe(fn) {
    subs.add(fn);
    return () => subs.delete(fn);
  }

  function formatEntry(e) {
    const t = new Date(e.ts).toISOString().replace('T', ' ').slice(0, 23);
    const lvl = e.level.toUpperCase().padEnd(5);
    let line = `${t}  ${lvl}  [${e.tag}]  ${e.msg}`;
    if (e.data !== undefined) {
      try { line += '  ' + JSON.stringify(e.data); } catch {}
    }
    return line;
  }

  function toText(filter) {
    return list(filter).map(formatEntry).join('\n');
  }

  function downloadText(filter) {
    const text = toText(filter);
    const stamp = new Date().toISOString().replace(/[:.]/g, '-').slice(0, 19);
    const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
    NF.download(blob, `novelforge-log-${stamp}.txt`, 'text/plain;charset=utf-8');
  }

  // ─── catch unhandled errors + promise rejections ───
  window.addEventListener('error', (ev) => {
    write('error', 'window', ev.message || 'unknown error', {
      file: ev.filename, line: ev.lineno, col: ev.colno,
      stack: ev.error?.stack,
    });
  });
  window.addEventListener('unhandledrejection', (ev) => {
    write('error', 'promise', 'Unhandled promise rejection', {
      reason: ev.reason instanceof Error
        ? { name: ev.reason.name, message: ev.reason.message, stack: ev.reason.stack }
        : ev.reason,
    });
  });

  return {
    debug: (tag, msg, data) => write('debug', tag, msg, data),
    dbg:   (tag, msg, data) => write('debug', tag, msg, data),
    info:  (tag, msg, data) => write('info',  tag, msg, data),
    warn:  (tag, msg, data) => write('warn',  tag, msg, data),
    error: (tag, msg, data) => write('error', tag, msg, data),
    list, clear, subscribe,
    toText, formatEntry, downloadText,
    _buf: buf,
  };
})();

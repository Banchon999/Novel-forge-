/* ═══════════════════════════════════════════════════════
   storage.js — workspace CRUD, settings, costs
   ═══════════════════════════════════════════════════════ */

const LS = {
  APIKEY:      'nf_apikey',
  COSTS:       'nf_costs',
  THEME:       'nf_theme',
  FS:          'nf_font_size',
  LAST_BACKUP: 'nf_last_backup',
};

NF.genId = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 7);

// ─── Workspaces ───
NF.store = {

  async listWorkspaces() {
    const all = await NF.idb.getAll('workspaces');
    return all.sort((a, b) => (b.updatedAt || 0) - (a.updatedAt || 0));
  },

  async getWorkspace(id) {
    return await NF.idb.get('workspaces', id);
  },

  async saveWorkspace(ws) {
    ws.updatedAt = Date.now();
    await NF.idb.put('workspaces', ws);
  },

  async deleteWorkspace(id) {
    await NF.idb.del('workspaces', id);
  },

  async createWorkspace(info = {}) {
    const ws = {
      id: NF.genId(),
      title:       info.title || 'Untitled',
      author:      info.author || '',
      tags:        info.tags || '',
      synopsis:    info.synopsis || '',
      instruction: info.instruction || '',
      sourceLang:  info.sourceLang || 'auto',
      targetLang:  'th',
      createdAt:   Date.now(),
      updatedAt:   Date.now(),

      chapters:    [],
      glossary:    [],

      settings:    {
        translateModel: 'google/gemini-2.5-flash',
        glossaryModel:  'google/gemini-2.5-flash',
        summaryModel:   'google/gemini-2.5-flash',
        temperature: 0.7,
        chunkSize: 2500,
        chunkMode: 'size',
        useStream: true,
        useContext: true,
        useAutoGlossary: true,
        translateTitles: true,
        registerDefault: 'neutral',
        narratorPronoun: 'auto',
      },

      marathon: {
        concurrency: 3,
        dailyLimit: 0,
        retry: true,
        autoSummary: true,
        queue: [],
        stats: { date: '', done: 0 },
      },

      context: {
        enabled: true,
        maxTokens: 2000,
        summaries: [],   // [{chId, chNum, title, summary, ts}]
      },

      costs: { in: 0, out: 0, usd: 0 },
    };
    await this.saveWorkspace(ws);
    return ws;
  },

  // meta
  async getLastWs()   { return await NF.idb.get('meta', 'last_ws'); },
  async setLastWs(id) { await NF.idb.put('meta', id, 'last_ws'); },
  async clearLastWs() { await NF.idb.del('meta', 'last_ws'); },

  // ─── API Key ───
  getApiKey()    { return localStorage.getItem(LS.APIKEY) || ''; },
  setApiKey(k)   { localStorage.setItem(LS.APIKEY, k); },
  clearApiKey()  { localStorage.removeItem(LS.APIKEY); },

  // ─── Theme / font ───
  getTheme()     { return localStorage.getItem(LS.THEME) || 'ink'; },
  setTheme(t)    { localStorage.setItem(LS.THEME, t); document.documentElement.setAttribute('data-theme', t); },
  getFontSize()  { return localStorage.getItem(LS.FS) || 'md'; },
  setFontSize(s) { localStorage.setItem(LS.FS, s); document.documentElement.setAttribute('data-fs', s); },

  // ─── Costs (accumulated, global) ───
  getCosts() {
    try { return JSON.parse(localStorage.getItem(LS.COSTS) || '{}'); }
    catch { return {}; }
  },
  setCosts(c) { localStorage.setItem(LS.COSTS, JSON.stringify(c)); },
  addCost(inputTok, outputTok, model) {
    const c = this.getCosts();
    c.totalIn  = (c.totalIn || 0) + inputTok;
    c.totalOut = (c.totalOut || 0) + outputTok;
    const pricing = NF.api.PRICING[model] || { in: 0, out: 0 };
    const usd = (inputTok / 1e6) * pricing.in + (outputTok / 1e6) * pricing.out;
    c.totalUsd = (c.totalUsd || 0) + usd;
    this.setCosts(c);

    // also attach to ws
    if (NF.state.currentWs) {
      NF.state.currentWs.costs = NF.state.currentWs.costs || { in: 0, out: 0, usd: 0 };
      NF.state.currentWs.costs.in  += inputTok;
      NF.state.currentWs.costs.out += outputTok;
      NF.state.currentWs.costs.usd += usd;
      NF.store.saveWorkspace(NF.state.currentWs).catch(() => {});
    }
    NF.emit('costs:updated');
    return usd;
  },
  resetCosts() {
    localStorage.removeItem(LS.COSTS);
    NF.emit('costs:updated');
  },

  // backup
  markBackup()    { localStorage.setItem(LS.LAST_BACKUP, Date.now().toString()); },
  getLastBackup() { return parseInt(localStorage.getItem(LS.LAST_BACKUP) || '0', 10); },
};

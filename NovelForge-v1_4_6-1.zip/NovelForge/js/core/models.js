/* ═══════════════════════════════════════════════════════
   models.js — Curated OpenRouter model catalog
   ───────────────────────────────────────────────────────
   Groups: thai-strong (tested good for Thai translation),
           budget (cheap daily driver), reasoning (slow but
           smart for hard passages), custom (user-entered).
   ═══════════════════════════════════════════════════════ */

NF.models = (function() {

  const CATALOG = [
    // ═══ 🌟 เก่งไทย · แนะนำสำหรับนิยาย ═══
    {
      id: 'google/gemini-2.5-pro',
      name: 'Gemini 2.5 Pro',
      group: 'thai-strong',
      note: 'เก่งไทยที่สุด context ยาว · แพงหน่อย',
      strengths: ['thai', 'long-context', 'creative'],
    },
    {
      id: 'anthropic/claude-sonnet-4.5',
      name: 'Claude Sonnet 4.5',
      group: 'thai-strong',
      note: 'โทนไทยเป็นธรรมชาติ เข้าใจโครงเรื่องลึก · ปานกลาง',
      strengths: ['thai', 'creative', 'literary'],
    },
    {
      id: 'anthropic/claude-opus-4.1',
      name: 'Claude Opus 4.1',
      group: 'thai-strong',
      note: 'แข็งแกร่งสุดด้านวรรณกรรม · แพงมาก',
      strengths: ['thai', 'creative', 'literary'],
    },
    {
      id: 'openai/gpt-5',
      name: 'GPT-5',
      group: 'thai-strong',
      note: 'สมดุลดี โทนไทยลื่น · ปานกลาง',
      strengths: ['thai', 'creative'],
    },

    // ═══ 💰 ประหยัด · ใช้รันทีละเยอะ ═══
    {
      id: 'google/gemini-2.5-flash',
      name: 'Gemini 2.5 Flash',
      group: 'budget',
      note: 'เร็ว ถูก ไทยโอเค · แนะนำเป็น default',
      strengths: ['thai', 'fast', 'cheap'],
      default: true,
    },
    {
      id: 'google/gemini-2.5-flash-lite',
      name: 'Gemini 2.5 Flash Lite',
      group: 'budget',
      note: 'ถูกสุดในตระกูล Gemini · ไทยพอใช้',
      strengths: ['fast', 'cheap'],
    },
    {
      id: 'anthropic/claude-haiku-4.5',
      name: 'Claude Haiku 4.5',
      group: 'budget',
      note: 'เร็ว โทนไทยดีกว่า Flash · ราคากลาง',
      strengths: ['thai', 'fast'],
    },
    {
      id: 'openai/gpt-5-mini',
      name: 'GPT-5 Mini',
      group: 'budget',
      note: 'ถูก ไทยโอเค',
      strengths: ['fast', 'cheap'],
    },
    {
      id: 'deepseek/deepseek-v3.2-exp',
      name: 'DeepSeek V3.2',
      group: 'budget',
      note: 'ถูกมาก ไทยกลางๆ เหมาะกับ glossary extraction',
      strengths: ['cheap'],
    },
    {
      id: 'x-ai/grok-4-fast',
      name: 'Grok 4 Fast',
      group: 'budget',
      note: 'เร็ว ราคาต่ำ โทนค่อนข้างตรง',
      strengths: ['fast', 'cheap'],
    },

    // ═══ 🧠 Reasoning · ใช้ตอนที่ยากมาก ═══
    {
      id: 'openai/o3',
      name: 'OpenAI o3',
      group: 'reasoning',
      note: 'คิดหนัก ช้า ใช้กับฉากที่ซับซ้อนมาก',
      strengths: ['reasoning', 'hard-passages'],
    },
    {
      id: 'google/gemini-2.5-pro-thinking',
      name: 'Gemini 2.5 Pro (thinking)',
      group: 'reasoning',
      note: 'คิดก่อนตอบ · ใช้ตอนยาก',
      strengths: ['reasoning', 'thai'],
    },
  ];

  const GROUP_LABELS = {
    'thai-strong': '🌟 เก่งไทย (แนะนำสำหรับแปลนิยาย)',
    'budget':      '💰 ประหยัด (เหมาะรันทีละเยอะ)',
    'reasoning':   '🧠 Reasoning (สำหรับตอนที่ยากมาก)',
  };

  function list()      { return CATALOG.slice(); }
  function byId(id)    { return CATALOG.find(m => m.id === id) || null; }
  function defaultId() { return CATALOG.find(m => m.default)?.id || 'google/gemini-2.5-flash'; }

  // Build a <select> populated with optgroups + custom option.
  // onChange receives the selected value (id or 'custom').
  function buildSelect({ id, currentValue, onChange, includeCustom = true, includeInherit = false }) {
    const sel = document.createElement('select');
    sel.className = 'select';
    if (id) sel.id = id;

    if (includeInherit) {
      const o = document.createElement('option');
      o.value = '';
      o.textContent = '↰ ใช้ค่าเดียวกับ Translation Model';
      sel.appendChild(o);
    }

    // group by group key
    const groups = {};
    for (const m of CATALOG) {
      groups[m.group] = groups[m.group] || [];
      groups[m.group].push(m);
    }
    for (const g of Object.keys(groups)) {
      const og = document.createElement('optgroup');
      og.label = GROUP_LABELS[g] || g;
      for (const m of groups[g]) {
        const o = document.createElement('option');
        o.value = m.id;
        o.textContent = m.name + (m.note ? ` — ${m.note}` : '');
        og.appendChild(o);
      }
      sel.appendChild(og);
    }

    if (includeCustom) {
      const og = document.createElement('optgroup');
      og.label = '⚙ อื่นๆ';
      const o = document.createElement('option');
      o.value = '__custom__';
      o.textContent = 'ใส่ model ID เอง...';
      og.appendChild(o);
      sel.appendChild(og);
    }

    // set current value — if not in catalog, it's a custom value
    if (currentValue && byId(currentValue)) {
      sel.value = currentValue;
    } else if (currentValue) {
      sel.value = '__custom__';
    } else if (!includeInherit) {
      sel.value = defaultId();
    }

    if (onChange) {
      sel.addEventListener('change', () => onChange(sel.value));
    }
    return sel;
  }

  return { list, byId, defaultId, buildSelect, CATALOG, GROUP_LABELS };
})();

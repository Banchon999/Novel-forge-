/* ═══════════════════════════════════════════════════════
   translator.js — Translation engine
   ───────────────────────────────────────────────────────
   Responsibilities:
   - Split source text into chunks (scene, size, paragraph, whole)
   - Build Smart Glossary (only relevant entries per chunk)
   - Build Context summary (only most recent N chapters)
   - Translate each chunk (stream or non-stream)
   - Generate chapter summary after each successful translation
   ═══════════════════════════════════════════════════════ */

NF.translator = (function() {

  // ═══ Chunking ═══
  function splitChunks(text, opts = {}) {
    const mode = opts.mode || 'size';
    const size = Math.max(200, opts.size || 2500);
    const tsz = text.length;

    if (tsz <= size * 1.3 && mode !== 'paragraph') {
      // small enough → single chunk
      return [text];
    }

    if (mode === 'whole') {
      return [text];
    }

    if (mode === 'scene') {
      const parts = text.split(/\n\s*[-=─★✦※＊*]{3,}\s*\n|\n\s*#{2,}\s*\n/g)
                        .map(s => s.trim())
                        .filter(Boolean);
      if (parts.length > 1) return parts;
      // fallback
      return splitBySize(text, size);
    }

    if (mode === 'paragraph') {
      // one paragraph per chunk (for very precise short-context translation)
      const parts = text.split(/\n{2,}/).map(s => s.trim()).filter(Boolean);
      // merge small ones
      const merged = [];
      let buf = '';
      for (const p of parts) {
        if ((buf + '\n\n' + p).length > size && buf) {
          merged.push(buf); buf = p;
        } else {
          buf = buf ? (buf + '\n\n' + p) : p;
        }
      }
      if (buf) merged.push(buf);
      return merged;
    }

    // default = 'size' (smart split at paragraph boundary closest to target size)
    return splitBySize(text, size);
  }

  function splitBySize(text, size) {
    const paras = text.split(/\n{2,}/);
    const chunks = [];
    let buf = '';
    for (const p of paras) {
      if (!p.trim()) continue;
      if (buf && (buf.length + p.length + 2) > size) {
        chunks.push(buf);
        buf = p;
      } else {
        buf = buf ? (buf + '\n\n' + p) : p;
      }
    }
    if (buf) chunks.push(buf);

    // second-pass: if any chunk is still > 2× size, cut mid-paragraph
    const out = [];
    for (const c of chunks) {
      if (c.length <= size * 2) { out.push(c); continue; }
      let i = 0;
      while (i < c.length) {
        const slice = c.slice(i, i + size);
        // prefer cut at sentence end
        const mark = Math.max(slice.lastIndexOf('。'), slice.lastIndexOf('.'), slice.lastIndexOf('!'), slice.lastIndexOf('?'), slice.lastIndexOf('\n'));
        if (mark > size * 0.5) {
          out.push(slice.slice(0, mark + 1).trim());
          i += mark + 1;
        } else {
          out.push(slice.trim());
          i += size;
        }
      }
    }
    return out.filter(Boolean);
  }

  // ═══ Smart Glossary ═══
  // Only inject glossary entries relevant to this chunk.
  //
  // Logic:
  //  1. Term appears in chunk → always include
  //  2. Character not in chunk → include only if glossary has ≤20 chars total
  //     (small cast = cheap, safe to include all for pronoun consistency)
  //     If cast is large, only include chars that appear in chunk.
  //  3. Hard cap: max 60 entries total to keep prompt lean.
  function smartGlossary(chunk, allGlossary = []) {
    if (!allGlossary.length) return [];

    const seen = new Set();
    const add = (g) => { if (!seen.has(g.source)) { seen.add(g.source); out.push(g); } };
    const out = [];

    // Pass 1: entries whose source term appears in this chunk
    for (const g of allGlossary) {
      if (!g?.source || !g?.thai) continue;
      if (chunk.includes(g.source)) add(g);
    }

    // Pass 2: characters not yet added
    const allChars = allGlossary.filter(g => g?.type === 'character' && g?.source && g?.thai);
    if (allChars.length <= 20) {
      // Small cast — include all for pronoun consistency (cheap)
      for (const g of allChars) add(g);
    } else {
      // Large cast — only include chars already found in chunk (pass 1 handled it)
      // Add up to 10 "main characters" as a safety net (first 10 in glossary = likely protagonists)
      let extraCount = 0;
      for (const g of allChars) {
        if (seen.has(g.source)) continue;
        if (extraCount >= 10) break;
        add(g);
        extraCount++;
      }
    }

    // Hard cap
    return out.slice(0, 60);
  }

  function glossaryToPromptStr(list) {
    if (!list.length) return '';
    return list.map(g => {
      const src = g.source || g.korean || '';
      const ty  = g.type || 'term';
      const ge  = g.gender ? ` [${g.gender}]` : '';
      const nt  = g.note ? ` // ${g.note}` : '';
      return `• ${src} → ${g.thai} (${ty}${ge})${nt}`;
    }).join('\n');
  }

  // ═══ Context string — recent summaries ═══
  function buildContextStr(ws, currentChId) {
    if (!ws?.context?.enabled) return '';
    const summaries = ws.context.summaries || [];
    if (!summaries.length) return '';

    // find last 3 BEFORE current chapter
    const idx = summaries.findIndex(s => s.chId === currentChId);
    const pool = idx >= 0 ? summaries.slice(Math.max(0, idx - 3), idx) : summaries.slice(-3);
    if (!pool.length) return '';
    return pool.map(s => `[ตอนที่ ${s.chNum || '?'}: ${s.title || ''}]\n${s.summary}`).join('\n\n');
  }

  // ═══ Translate one chunk ═══
  async function translateChunk({ chunk, ws, chapterTitle, glossaryList, contextStr, signal, onStream }) {
    // ═══ Image Guard — phase 1: strip ═══
    // Replace [IMG: url] tokens with sentinels so the AI can't "helpfully"
    // delete URLs. Works even if the model ignores the prompt hint.
    const guarded = NF.imageGuard.strip(chunk);
    const sourceForAI = guarded.clean;
    if (guarded.count > 0) {
      NF.log?.dbg('translator', `image guard: stripped ${guarded.count} images`, { count: guarded.count });
    }

    const prompt = NF.prompts.buildTranslate({
      sourceText: sourceForAI,
      glossaryStr: glossaryToPromptStr(glossaryList),
      contextStr,
      ws,
      chapterTitle,
      hasImages: guarded.count > 0,
    });

    const model = ws?.settings?.translateModel || 'google/gemini-2.5-flash';
    const temp  = ws?.settings?.temperature ?? 0.7;
    const stream = ws?.settings?.useStream !== false;
    const messages = [{ role: 'user', content: prompt }];
    const max_tokens = Math.max(2000, Math.ceil(chunk.length * 2));

    // Wrap user onStream so we can restore sentinels progressively for preview
    let rawResult;
    if (stream && onStream) {
      const wrapped = (delta, full) => {
        // show partially-restored text in UI while streaming
        try {
          const { text } = NF.imageGuard.restore(full, guarded.map);
          onStream(delta, text);
        } catch {
          onStream(delta, full);
        }
      };
      rawResult = await NF.api.stream({
        model, messages, temperature: temp, max_tokens, signal,
        onChunk: wrapped,
      });
    } else {
      const res = await NF.api.call({ model, messages, temperature: temp, max_tokens, signal });
      rawResult = res.choices?.[0]?.message?.content || '';
    }

    // ═══ Image Guard — phase 2: restore ═══
    if (guarded.count > 0) {
      const { text, restored, missing, added } = NF.imageGuard.restore(rawResult, guarded.map);
      if (added > 0) {
        NF.log?.warn('translator', `AI dropped ${added} image(s) — re-appended at end`, { missing });
      } else if (restored < guarded.count) {
        NF.log?.warn('translator', `image guard: only ${restored}/${guarded.count} restored`);
      } else {
        NF.log?.dbg('translator', `image guard: ${restored}/${guarded.count} intact`);
      }
      return text;
    }
    return rawResult;
  }

  // ═══ Translate entire chapter (multi-chunk orchestration) ═══
  async function translateChapter({ ws, chapter, signal, onProgress, onChunkStream, skipSave = false }) {
    if (!chapter.sourceText || !chapter.sourceText.trim()) throw new Error('ไม่มี source text');

    const settings = ws.settings || {};

    // ─── Step 0: แปล title (non-fatal — ถ้าพังใช้ source title) ───
    // แปลก่อน body เพื่อให้ title มีอยู่ใน prepend ต่อ
    const translateTitles = settings.translateTitles !== false;
    let thaiTitle = chapter.translatedTitle || '';
    if (translateTitles && chapter.title && !chapter.translatedTitle) {
      onProgress && onProgress({ stage: 'title', chunkIdx: -1 });
      try {
        thaiTitle = await translateTitle({ chapter, ws, signal });
        if (thaiTitle && thaiTitle !== chapter.title) {
          chapter.translatedTitle = thaiTitle;
          chapter.title = thaiTitle;   // ทับของเดิม ตามที่ user ต้องการ
        }
      } catch (err) {
        if (err.name === 'AbortError') throw err;
        NF.log?.warn('translator', 'title translate failed — using source', { err: err.message });
        thaiTitle = chapter.title;
      }
    } else if (chapter.translatedTitle) {
      thaiTitle = chapter.translatedTitle;
    } else {
      thaiTitle = chapter.title || '';
    }

    const chunks = splitChunks(chapter.sourceText, {
      mode: settings.chunkMode || 'size',
      size: settings.chunkSize || 2500,
    });

    onProgress && onProgress({ stage: 'start', total: chunks.length, done: 0 });

    const contextStr = buildContextStr(ws, chapter.id);
    const translatedParts = [];

    for (let i = 0; i < chunks.length; i++) {
      if (signal?.aborted) throw new DOMException('Aborted', 'AbortError');
      const chunk = chunks[i];
      const gloss = smartGlossary(chunk, ws.glossary || []);

      onProgress && onProgress({ stage: 'chunk-start', total: chunks.length, done: i, chunkIdx: i, chunkSize: chunk.length });

      let segText = '';
      try {
        segText = await translateChunk({
          chunk, ws,
          chapterTitle: chapter.title,
          glossaryList: gloss,
          contextStr,
          signal,
          onStream: (delta, full) => {
            onChunkStream && onChunkStream(i, delta, full);
          },
        });
      } catch (err) {
        if (err.name === 'AbortError') throw err;
        // retry once on network
        await sleep(600);
        segText = await translateChunk({
          chunk, ws,
          chapterTitle: chapter.title,
          glossaryList: gloss,
          contextStr,
          signal,
        });
      }

      segText = cleanupTranslation(segText);
      translatedParts.push(segText);

      onProgress && onProgress({ stage: 'chunk-done', total: chunks.length, done: i + 1, chunkIdx: i });
    }

    let fullThai = translatedParts.join('\n\n');

    // --- Non-Thai Detector ---
    try {
      fullThai = await scanAndFixNonThai({ ws, chapter, translatedText: fullThai, signal });
    } catch (err) {
      if (err.name === 'AbortError') throw err;
      NF.log?.warn('translator', 'non-thai scan failed', err);
    }

    // ─── Prepend translated title ไปที่หัว body ───
    // ตามที่ user ต้องการ: แปล title แล้วเอาคำแปลไปใส่ body ด้วย
    // ตรวจว่า AI ไม่ได้ใส่ title ไว้บรรทัดแรกแล้ว (บาง model อาจทำเองได้)
    let bodyWithTitle = fullThai;
    if (thaiTitle) {
      const firstLine = fullThai.split('\n')[0]?.trim() || '';
      // ถ้าบรรทัดแรกของ body ไม่ใช่ title (exact หรือ normalized) → prepend
      const norm = s => String(s).replace(/\s+/g, '').toLowerCase();
      if (norm(firstLine) !== norm(thaiTitle)) {
        bodyWithTitle = thaiTitle + '\n\n' + fullThai;
      }
    }

    // ═══ Auto-apply credit (single-mode translation) ═══
    let finalThai = bodyWithTitle;
    try {
      const creditCfg = NF.credit?.load();
      if (creditCfg?.enabled && creditCfg?.autoApplyOnTranslate && creditCfg?.translatorName) {
        finalThai = NF.credit.apply(bodyWithTitle, { chapter, ws });
      }
    } catch (e) {
      NF.log?.warn('translator', 'credit apply failed', e);
    }

    if (!skipSave) {
      chapter.translated = finalThai;
      chapter.status = 'translated';
      chapter.translatedAt = Date.now();
      chapter.updatedAt = Date.now();
      await NF.store.saveWorkspace(ws);
    }

    // Auto-summarize for context — ใช้ fullThai (ไม่มี credit ปน)
    if (settings.useContext && !skipSave) {
      try {
        const sum = await summarizeChapter(ws, chapter, fullThai, signal);
        if (sum) {
          ws.context.summaries = ws.context.summaries || [];
          // replace existing
          const existIdx = ws.context.summaries.findIndex(s => s.chId === chapter.id);
          const entry = {
            chId: chapter.id,
            chNum: chapter.num,
            title: chapter.title,
            summary: sum,
            ts: Date.now(),
          };
          if (existIdx >= 0) ws.context.summaries[existIdx] = entry;
          else ws.context.summaries.push(entry);
          await NF.store.saveWorkspace(ws);
        }
      } catch (e) { /* summary failure non-fatal */ }
    }

    onProgress && onProgress({ stage: 'done', total: chunks.length, done: chunks.length, text: fullThai });
    return fullThai;
  }

  // ═══ Summarizer ═══
  async function summarizeChapter(ws, chapter, translatedText, signal) {
    let text = translatedText || chapter.translated || '';
    // ถอด credit block ออกก่อนสรุป — กัน AI สรุปว่ามี "นักแปล" เป็นตัวละคร
    if (NF.credit?.has?.(text)) {
      text = NF.credit.stripExisting(text);
    }
    if (!text.trim()) return null;
    const model = ws.settings?.summaryModel || ws.settings?.translateModel || 'google/gemini-2.5-flash';
    // cap input length
    const capped = text.length > 6000 ? (text.slice(0, 3000) + '\n\n...[ย่อ]...\n\n' + text.slice(-2000)) : text;
    const prompt = NF.prompts.buildSummary({
      translatedText: capped,
      chapterNum: chapter.num,
      chapterTitle: chapter.title,
    });
    const res = await NF.api.call({
      model,
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.3,
      max_tokens: 500,
      signal,
    });
    return res.choices?.[0]?.message?.content?.trim() || null;
  }

  // ═══ Translate one chapter title ═══
  // ใช้ glossary + previous titles เพื่อความต่อเนื่อง
  async function translateTitle({ chapter, ws, signal }) {
    const sourceTitle = (chapter.title || '').trim();
    if (!sourceTitle) return '';

    // ถ้า title เป็นภาษาไทยเกือบทั้งหมดอยู่แล้ว ไม่ต้องแปล
    if (isLikelyThai(sourceTitle)) return sourceTitle;

    // หา glossary ที่ relevant กับ title
    const gloss = NF.translator.smartGlossary(sourceTitle, ws.glossary || []);

    // หา previous titles — 5 ตอนก่อนหน้าที่แปลแล้ว
    const sortedDone = (ws.chapters || [])
      .filter(c => c.id !== chapter.id && c.translatedTitle && c.title)
      .sort((a, b) => (a.num || 0) - (b.num || 0));
    const idx = chapter.num
      ? sortedDone.findIndex(c => (c.num || 0) >= chapter.num)
      : -1;
    const pool = idx >= 0 ? sortedDone.slice(Math.max(0, idx - 5), idx) : sortedDone.slice(-5);
    const previousTitles = pool.map(c => ({
      num: c.num, source: c.title, thai: c.translatedTitle,
    }));

    const prompt = NF.prompts.buildTitleTranslate({
      sourceTitle, ws, glossaryList: gloss, previousTitles,
    });

    const model = ws?.settings?.translateModel || 'google/gemini-2.5-flash';
    const temp  = ws?.settings?.temperature ?? 0.7;

    try {
      const res = await NF.api.call({
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature: Math.min(temp, 0.5),   // title ต้องเสถียร — ลด temp
        max_tokens: 120,
        signal,
      });
      let t = res.choices?.[0]?.message?.content || '';
      t = cleanupTitle(t);
      return t || sourceTitle;
    } catch (err) {
      if (err.name === 'AbortError') throw err;
      NF.log?.warn('translator', 'translateTitle failed', { err: err.message });
      return sourceTitle;   // fallback: เก็บของเดิม
    }
  }

  // title cleanup — strip quotes, leading/trailing punctuation, explain prefixes
  function cleanupTitle(s) {
    if (!s) return '';
    let t = String(s).trim();
    // multi-line: take first non-empty line
    t = t.split('\n').map(l => l.trim()).filter(Boolean)[0] || '';
    // strip wrapping quotes
    t = t.replace(/^["'"'「『`]+|["'"'」』`]+$/g, '');
    // strip leading "Thai title:" / "แปล:" / "ชื่อตอน:" etc.
    t = t.replace(/^(Thai title|Translated title|Title|แปล|ชื่อตอน|คำแปล)\s*[:：\-–]\s*/i, '');
    // strip bullet/number prefix
    t = t.replace(/^[\d]+\.\s*/, '');
    t = t.replace(/^[-–—•·]\s*/, '');
    // strip code fence
    t = t.replace(/^`+|`+$/g, '');
    // cap length ที่ reasonable
    if (t.length > 200) t = t.slice(0, 200);
    return t.trim();
  }

  // คร่าวๆ: ข้อความนี้เป็นไทยเกือบทั้งหมดหรือไม่
  function isLikelyThai(s) {
    if (!s) return false;
    const thaiChars = s.match(/[\u0E00-\u0E7F]/g)?.length || 0;
    const nonSpaceChars = s.replace(/\s/g, '').length;
    if (!nonSpaceChars) return false;
    return thaiChars / nonSpaceChars >= 0.7;
  }

  // ═══ Output cleanup ═══
  function cleanupTranslation(text) {
    if (!text) return '';
    let t = text;

    // Strip leading labels like "Translation:" / "คำแปล:"
    t = t.replace(/^(?:Translation|Thai Translation|การแปล|คำแปล)\s*:\s*\n*/i, '');

    // Strip code-fences
    t = t.replace(/^```[a-z]*\n?/i, '').replace(/\n?```\s*$/, '');

    // Normalize multiple blank lines to max 2
    t = t.replace(/\n{3,}/g, '\n\n');

    // Trim trailing whitespace on each line
    t = t.split('\n').map(l => l.replace(/[ \t]+$/, '')).join('\n');

    return t.trim();
  }

  function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

  // ═══ Non-Thai Detector ═══
  // สแกน translated text ว่ามีคำนอกภาษาไทย (ภาษาต้นฉบับ) หลงอยู่ไหม
  // ถ้าเจอ chunk ไหน → แปลใหม่อัตโนมัติ (silent)
  //
  // Logic:
  //   - แบ่ง translated text เป็น "chunks" ตาม paragraph
  //   - แต่ละ chunk: คำนวณ Thai ratio
  //   - chunk ที่ Thai ratio < threshold → ถือว่ามีปัญหา
  //   - ดึง source chunk ที่ตรงกัน → แปลใหม่
  //
  // Returns: { fixed: number, newText: string }

  const NON_THAI_THAI_RATIO_MIN = 0.35; // chunk ต้องมีอักษรไทยอย่างน้อย 35%
  const NON_THAI_MIN_CHUNK_LEN  = 20;   // chunk สั้นกว่านี้ข้าม (อาจเป็น scene break)

  function _thaiRatio(s) {
    if (!s) return 1;
    const chars = s.replace(/\s/g, '');
    if (!chars.length) return 1;
    const thaiChars = (chars.match(/[\u0E00-\u0E7F]/g) || []).length;
    // ตัวเลข + เครื่องหมายวรรคตอน + emoji ไม่นับ
    const countable = chars.replace(/[\d\s\p{P}\p{S}]/gu, '').length || chars.length;
    return thaiChars / countable;
  }

  function _findNonThaiChunkIndices(translatedText) {
    const paragraphs = translatedText.split(/\n\n+/);
    const badIndices = [];
    paragraphs.forEach((p, i) => {
      if (p.trim().length < NON_THAI_MIN_CHUNK_LEN) return;
      // ยกเว้น scene break markers
      if (/^[\s\-=─★✦※＊*◇□]{3,}$/.test(p.trim())) return;
      // ยกเว้น [IMG: ...]
      if (/^\[IMG:/i.test(p.trim())) return;
      if (_thaiRatio(p) < NON_THAI_THAI_RATIO_MIN) {
        badIndices.push(i);
      }
    });
    return { paragraphs, badIndices };
  }

  // Re-translate specific paragraph indices from source
  async function retranslateNonThaiChunks({ ws, chapter, translatedText, signal }) {
    const { paragraphs, badIndices } = _findNonThaiChunkIndices(translatedText);
    if (!badIndices.length) return { fixed: 0, newText: translatedText };

    NF.log?.info('translator', `non-thai detector: พบ ${badIndices.length} chunk ที่ต้องแปลใหม่`);

    // แบ่ง source text เป็น paragraph เช่นกัน (ตาม \n\n)
    const srcParagraphs = (chapter.sourceText || '').split(/\n\n+/);

    let fixed = 0;
    const newParagraphs = [...paragraphs];

    for (const idx of badIndices) {
      if (signal?.aborted) break;

      // หา source paragraph ที่ตรงกัน — ถ้า index เกิน ใช้ chunk สุดท้าย
      const srcIdx = Math.min(idx, srcParagraphs.length - 1);
      const srcChunk = srcParagraphs[srcIdx]?.trim();
      if (!srcChunk) continue;

      const gloss = smartGlossary(srcChunk, ws.glossary || []);
      try {
        const retranslated = await translateChunk({
          chunk: srcChunk,
          ws,
          chapterTitle: chapter.title,
          glossaryList: gloss,
          contextStr: '',
          signal,
          onStream: null, // silent
        });
        if (retranslated && _thaiRatio(retranslated) >= NON_THAI_THAI_RATIO_MIN) {
          newParagraphs[idx] = cleanupTranslation(retranslated);
          fixed++;
          NF.log?.info('translator', `non-thai: แปล paragraph ${idx} ใหม่แล้ว`);
        }
      } catch (err) {
        if (err.name === 'AbortError') throw err;
        NF.log?.warn('translator', `non-thai: แปล paragraph ${idx} ล้มเหลว`, err);
      }
    }

    return { fixed, newText: newParagraphs.join('\n\n') };
  }

  // หลังแปลเสร็จ: สแกนและแปลใหม่ถ้าพบปัญหา (เรียกจาก translateChapter)
  async function scanAndFixNonThai({ ws, chapter, translatedText, signal }) {
    const enabled = ws?.settings?.nonThaiDetect !== false; // default on
    if (!enabled) return translatedText;
    if (!translatedText?.trim()) return translatedText;

    const { badIndices } = _findNonThaiChunkIndices(translatedText);
    if (!badIndices.length) return translatedText;

    NF.log?.info('translator', `🔍 Non-Thai Detector: พบ ${badIndices.length} chunk ผิดปกติ → แปลใหม่`);
    const { fixed, newText } = await retranslateNonThaiChunks({ ws, chapter, translatedText, signal });
    if (fixed > 0) {
      NF.toast?.info(`🔍 แปลใหม่ ${fixed} ย่อหน้าที่มีภาษาผิด`);
    }
    return newText;
  }

  // ═══ Honorific Check ═══
  // ส่งเฉพาะบรรทัดที่มี ครับ/ค่ะ/ฉัน/เธอ ไปให้ AI ตรวจ
  // ประหยัด token เพราะไม่ส่งทั้งตอน

  const HONORIFIC_KEYWORDS = ['ครับ', 'ค่ะ', 'คะ', 'นะคะ', 'นะครับ', 'ฉัน', 'เธอ', 'ผม', 'กู', 'เขา', 'นาง'];

  const HONORIFIC_PROMPT = `You are a Thai webnovel particle editor. Fix ONLY incorrect gendered sentence-ending particles and pronouns.
Do NOT change any other content, names, or meaning.

RULES:
• Male speaker → ครับ, นะครับ (and ผม/กู/เขา)
• Female speaker → ค่ะ, คะ, นะคะ (and ฉัน/นาง/เธอ)

GLOSSARY (use for speaker gender):
{glossary}

TEXT TO FIX:
{text}

Return ONLY the corrected text. No explanation.`;

  // สกัดเฉพาะบรรทัดที่มี keyword + 1 บรรทัด context รอบๆ
  function _extractHonorifixLines(text) {
    const lines = text.split('\n');
    const relevantIndices = new Set();
    lines.forEach((line, i) => {
      if (HONORIFIC_KEYWORDS.some(kw => line.includes(kw))) {
        if (i > 0) relevantIndices.add(i - 1);
        relevantIndices.add(i);
        if (i < lines.length - 1) relevantIndices.add(i + 1);
      }
    });
    return {
      lines,
      relevantIndices,
      // ข้อความที่ส่ง AI — เฉพาะบรรทัดที่เกี่ยวข้อง
      snippet: [...relevantIndices].sort((a,b) => a-b).map(i => lines[i]).join('\n'),
    };
  }

  // Returns: { original, fixed, diffLines } or null if no change
  async function runHonorifixCheck({ ws, text, signal }) {
    if (!text?.trim()) return null;
    const glossary = ws?.glossary || [];
    const model = ws?.settings?.translateModel || 'google/gemini-2.5-flash';

    const { lines, relevantIndices, snippet } = _extractHonorifixLines(text);
    if (!snippet.trim()) return null;

    // Build minimal glossary (characters only, with gender)
    const charGlossary = glossary
      .filter(g => g.type === 'character' && g.gender && g.gender !== 'neutral')
      .slice(0, 40)
      .map(g => `• ${g.source} → ${g.thai} [${g.gender}]`)
      .join('\n') || '(ไม่มี)';

    const prompt = HONORIFIC_PROMPT
      .replace('{glossary}', charGlossary)
      .replace('{text}', snippet);

    const res = await NF.api.call({
      model,
      messages: [{ role: 'user', content: prompt }],
      temperature: 0.1,
      max_tokens: Math.max(1000, Math.ceil(snippet.length * 1.5)),
      signal,
    });

    const fixedSnippet = res.choices?.[0]?.message?.content?.trim();
    if (!fixedSnippet || fixedSnippet === snippet) return { changed: false, text };

    // Patch แค่บรรทัดที่เกี่ยวข้อง กลับเข้าไปใน full text
    const fixedLines = fixedSnippet.split('\n');
    const relevantArr = [...relevantIndices].sort((a, b) => a - b);
    const newLines = [...lines];
    relevantArr.forEach((lineIdx, i) => {
      if (fixedLines[i] !== undefined) newLines[lineIdx] = fixedLines[i];
    });
    const newText = newLines.join('\n');

    // นับ diff
    const diffCount = lines.filter((l, i) => l !== newLines[i]).length;

    return { changed: diffCount > 0, text: newText, diffCount, original: text };
  }

  return {
    splitChunks,
    smartGlossary,
    glossaryToPromptStr,
    buildContextStr,
    translateChunk,
    translateChapter,
    translateTitle,
    summarizeChapter,
    cleanupTranslation,
    cleanupTitle,
    isLikelyThai,
    scanAndFixNonThai,
    retranslateNonThaiChunks,
    runHonorifixCheck,
    _thaiRatio,
    _findNonThaiChunkIndices,
  };
})();

/* ═══════════════════════════════════════════════════════
   docx.js — Minimal .docx (OOXML) builder
   ───────────────────────────────────────────────────────
   Creates a Word-compatible .docx that Google Drive can
   open as a Google Doc. No external libraries needed.
   ═══════════════════════════════════════════════════════ */

NF.docx = (function() {

  function escXml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // Build a single .docx containing one or more sections.
  // sections: [{ heading, paragraphs: [string, ...] }]
  async function build({ title = '', sections = [] }) {
    const paraBlocks = [];

    // Title
    if (title) {
      paraBlocks.push(`
      <w:p>
        <w:pPr><w:pStyle w:val="Title"/></w:pPr>
        <w:r><w:rPr><w:sz w:val="48"/><w:b/></w:rPr><w:t>${escXml(title)}</w:t></w:r>
      </w:p>`);
    }

    for (const sec of sections) {
      if (sec.heading) {
        paraBlocks.push(`
      <w:p>
        <w:pPr><w:pStyle w:val="Heading1"/><w:pageBreakBefore/></w:pPr>
        <w:r><w:rPr><w:sz w:val="36"/><w:b/></w:rPr><w:t>${escXml(sec.heading)}</w:t></w:r>
      </w:p>`);
      }

      for (const raw of (sec.paragraphs || [])) {
        const text = String(raw || '');
        if (!text.trim()) {
          paraBlocks.push(`<w:p/>`);
          continue;
        }
        // split by newline inside same paragraph → <w:br/>
        const lines = text.split('\n');
        const runs = lines.map((ln, i) => {
          const t = escXml(ln);
          return (i === 0 ? '' : '<w:br/>') + `<w:t xml:space="preserve">${t}</w:t>`;
        }).join('');
        paraBlocks.push(`
      <w:p>
        <w:r>${runs}</w:r>
      </w:p>`);
      }
    }

    const docXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document
  xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    ${paraBlocks.join('')}
    <w:sectPr>
      <w:pgSz w:w="11906" w:h="16838"/>
      <w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/>
    </w:sectPr>
  </w:body>
</w:document>`;

    const stylesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:docDefaults>
    <w:rPrDefault>
      <w:rPr><w:rFonts w:ascii="Sarabun" w:hAnsi="Sarabun" w:cs="Sarabun"/><w:sz w:val="24"/></w:rPr>
    </w:rPrDefault>
  </w:docDefaults>
  <w:style w:type="paragraph" w:styleId="Title">
    <w:name w:val="Title"/>
    <w:pPr><w:spacing w:before="240" w:after="240"/><w:jc w:val="center"/></w:pPr>
    <w:rPr><w:rFonts w:ascii="Sarabun" w:hAnsi="Sarabun"/><w:b/><w:sz w:val="48"/></w:rPr>
  </w:style>
  <w:style w:type="paragraph" w:styleId="Heading1">
    <w:name w:val="heading 1"/>
    <w:pPr><w:spacing w:before="480" w:after="240"/></w:pPr>
    <w:rPr><w:rFonts w:ascii="Sarabun" w:hAnsi="Sarabun"/><w:b/><w:sz w:val="36"/></w:rPr>
  </w:style>
</w:styles>`;

    const contentTypesXml = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
</Types>`;

    const rootRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>`;

    const docRels = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>
</Relationships>`;

    const files = {
      '[Content_Types].xml':  contentTypesXml,
      '_rels/.rels':          rootRels,
      'word/document.xml':    docXml,
      'word/styles.xml':      stylesXml,
      'word/_rels/document.xml.rels': docRels,
    };
    // compress xml parts
    const zipFiles = {};
    for (const [k, v] of Object.entries(files)) {
      zipFiles[k] = { data: v, compress: true };
    }
    return await NF.zip.write(zipFiles);
  }

  return { build };
})();

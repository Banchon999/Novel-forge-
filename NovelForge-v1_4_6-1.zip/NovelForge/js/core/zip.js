/* ═══════════════════════════════════════════════════════
   zip.js — Pure-JS ZIP read/write (no dependencies)
   Reads: store (0) and deflate (8)
   Writes: store only (for compatibility & simplicity)
   ═══════════════════════════════════════════════════════ */

NF.zip = (function() {

  // ─── CRC32 ───
  let _crcTable = null;
  function crcTable() {
    if (_crcTable) return _crcTable;
    const t = new Uint32Array(256);
    for (let i = 0; i < 256; i++) {
      let c = i;
      for (let j = 0; j < 8; j++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      t[i] = c;
    }
    return _crcTable = t;
  }
  function crc32(data) {
    const t = crcTable();
    let c = 0xFFFFFFFF;
    for (let i = 0; i < data.length; i++) c = t[(c ^ data[i]) & 0xFF] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }

  // ─── little-endian helpers ───
  const u16 = v => [v & 0xFF, (v >> 8) & 0xFF];
  const u32 = v => [v & 0xFF, (v >> 8) & 0xFF, (v >> 16) & 0xFF, (v >> 24) & 0xFF];
  function concat(...arr) {
    let total = 0; for (const a of arr) total += a.length;
    const out = new Uint8Array(total);
    let p = 0;
    for (const a of arr) { out.set(a, p); p += a.length; }
    return out;
  }

  // ─── READ ───
  async function read(arrayBuffer) {
    const bytes = new Uint8Array(arrayBuffer);
    const decoder = new TextDecoder('utf-8', { fatal: false });
    const readU16 = o => bytes[o] | (bytes[o+1] << 8);
    const readU32 = o => bytes[o] | (bytes[o+1]<<8) | (bytes[o+2]<<16) | (bytes[o+3]<<24);

    // find End of Central Directory
    let eocd = -1;
    for (let i = bytes.length - 22; i >= 0; i--) {
      if (bytes[i]===0x50 && bytes[i+1]===0x4B && bytes[i+2]===0x05 && bytes[i+3]===0x06) { eocd = i; break; }
      if (eocd < 0 && i < bytes.length - 65535 - 22) break;
    }
    if (eocd < 0) throw new Error('ไม่ใช่ ZIP ที่ถูกต้อง');

    const cdOff = readU32(eocd + 16);
    const cdEntries = readU16(eocd + 8);
    const files = {};
    let pos = cdOff;

    for (let i = 0; i < cdEntries; i++) {
      if (pos + 46 > bytes.length) break;
      if (bytes[pos]!==0x50||bytes[pos+1]!==0x4B||bytes[pos+2]!==0x01||bytes[pos+3]!==0x02) break;
      const compression = readU16(pos + 10);
      const compSize = readU32(pos + 20);
      const uncompSize = readU32(pos + 24);
      const fnLen = readU16(pos + 28);
      const extraLen = readU16(pos + 30);
      const commentLen = readU16(pos + 32);
      const localOffset = readU32(pos + 42);
      const filename = decoder.decode(bytes.slice(pos + 46, pos + 46 + fnLen));
      files[filename] = { compression, compSize, uncompSize, localOffset };
      pos += 46 + fnLen + extraLen + commentLen;
    }

    async function readRaw(filename) {
      const ent = files[filename];
      if (!ent) return null;
      let lp = ent.localOffset;
      if (lp + 30 > bytes.length) return null;
      const fnLen2 = readU16(lp + 26);
      const extraLen2 = readU16(lp + 28);
      lp += 30 + fnLen2 + extraLen2;
      const comp = bytes.slice(lp, lp + ent.compSize);
      if (ent.compression === 0) return comp;
      if (ent.compression === 8) {
        try {
          const ds = new DecompressionStream('deflate-raw');
          const writer = ds.writable.getWriter();
          writer.write(comp); writer.close();
          const reader = ds.readable.getReader();
          const chunks = [];
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            chunks.push(value);
          }
          return concat(...chunks);
        } catch { return null; }
      }
      return null;
    }

    async function readText(filename) {
      const raw = await readRaw(filename);
      return raw ? decoder.decode(raw) : null;
    }

    return {
      files,
      entries: Object.keys(files),
      readRaw, readText,
    };
  }

  // ─── WRITE ───
  //  Accepts { name: string | Uint8Array | { data, compress } }
  async function write(fileMap) {
    const enc = new TextEncoder();
    const localParts = [];
    const centralParts = [];
    let offset = 0;

    for (const [name, content] of Object.entries(fileMap)) {
      let dataBytes, compress = false;
      if (typeof content === 'string') dataBytes = enc.encode(content);
      else if (content instanceof Uint8Array) dataBytes = content;
      else if (content && content.data) {
        dataBytes = typeof content.data === 'string' ? enc.encode(content.data) : content.data;
        compress = !!content.compress;
      } else {
        dataBytes = enc.encode(String(content));
      }

      const uncompSize = dataBytes.length;
      const crc = crc32(dataBytes);

      let storedBytes = dataBytes;
      let compression = 0;

      // Attempt deflate-raw compression if requested
      if (compress && typeof CompressionStream !== 'undefined' && dataBytes.length > 64) {
        try {
          const cs = new CompressionStream('deflate-raw');
          const writer = cs.writable.getWriter();
          writer.write(dataBytes); writer.close();
          const reader = cs.readable.getReader();
          const chunks = [];
          while (true) {
            const { done, value } = await reader.read();
            if (done) break;
            chunks.push(value);
          }
          const out = concat(...chunks);
          if (out.length < dataBytes.length) {
            storedBytes = out;
            compression = 8;
          }
        } catch { /* fallback to store */ }
      }

      const nameBytes = enc.encode(name);
      const compSize = storedBytes.length;

      const localHeader = new Uint8Array([
        0x50,0x4B,0x03,0x04,
        0x14,0x00,
        0x00,0x00,
        ...u16(compression),
        0x00,0x00, 0x21,0x00,   // time & date (arbitrary)
        ...u32(crc),
        ...u32(compSize),
        ...u32(uncompSize),
        ...u16(nameBytes.length),
        0x00,0x00,
        ...nameBytes,
      ]);

      localParts.push(localHeader, storedBytes);

      const centralHeader = new Uint8Array([
        0x50,0x4B,0x01,0x02,
        0x14,0x00, 0x14,0x00,
        0x00,0x00,
        ...u16(compression),
        0x00,0x00, 0x21,0x00,
        ...u32(crc),
        ...u32(compSize),
        ...u32(uncompSize),
        ...u16(nameBytes.length),
        0x00,0x00,               // extra
        0x00,0x00,               // comment
        0x00,0x00,               // disk
        0x00,0x00,               // internal attr
        0x00,0x00,0x00,0x00,     // external attr
        ...u32(offset),
        ...nameBytes,
      ]);
      centralParts.push(centralHeader);

      offset += localHeader.length + storedBytes.length;
    }

    const centralStart = offset;
    let centralSize = 0;
    for (const p of centralParts) centralSize += p.length;
    offset += centralSize;

    const eocd = new Uint8Array([
      0x50,0x4B,0x05,0x06,
      0x00,0x00, 0x00,0x00,
      ...u16(centralParts.length),
      ...u16(centralParts.length),
      ...u32(centralSize),
      ...u32(centralStart),
      0x00,0x00,
    ]);

    return concat(...localParts, ...centralParts, eocd);
  }

  return { read, write, crc32 };
})();

/* ═══════════════════════════════════════════════════════
   api.js — OpenRouter API + streaming + pricing
   ═══════════════════════════════════════════════════════ */

NF.api = {

  ENDPOINT: 'https://openrouter.ai/api/v1/chat/completions',

  // USD per 1M tokens — approximate; adjust if needed
  PRICING: {
    'google/gemini-2.5-flash':             { in: 0.30, out: 2.50 },
    'google/gemini-2.5-flash-lite':        { in: 0.10, out: 0.40 },
    'google/gemini-2.5-pro':               { in: 1.25, out: 10.0 },
    'google/gemini-2.0-flash-001':         { in: 0.10, out: 0.40 },
    'anthropic/claude-3.5-sonnet':         { in: 3.00, out: 15.0 },
    'anthropic/claude-3.5-haiku':          { in: 0.80, out: 4.00 },
    'anthropic/claude-sonnet-4':           { in: 3.00, out: 15.0 },
    'openai/gpt-4o-mini':                  { in: 0.15, out: 0.60 },
    'openai/gpt-4o':                       { in: 2.50, out: 10.0 },
    'deepseek/deepseek-chat':              { in: 0.14, out: 0.28 },
    'deepseek/deepseek-v3.1':              { in: 0.27, out: 1.10 },
    'qwen/qwen-2.5-72b-instruct':          { in: 0.23, out: 0.40 },
    'x-ai/grok-4-fast':                    { in: 0.20, out: 0.50 },
  },

  // Non-streaming call
  async call({ model, messages, temperature = 0.7, max_tokens = 4000, signal }) {
    const key = NF.store.getApiKey();
    if (!key) throw new Error('ยังไม่ได้ตั้งค่า API Key');

    const res = await fetch(this.ENDPOINT, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${key}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': location.origin || 'https://novelforge.app',
        'X-Title': 'NovelForge',
      },
      body: JSON.stringify({ model, messages, temperature, max_tokens }),
      signal,
    });

    if (!res.ok) {
      const txt = await res.text().catch(() => '');
      throw new Error(`API ${res.status}: ${txt.slice(0, 200)}`);
    }
    const data = await res.json();
    const usage = data.usage || {};
    if (usage.prompt_tokens || usage.completion_tokens) {
      NF.store.addCost(usage.prompt_tokens || 0, usage.completion_tokens || 0, model);
    }
    return data;
  },

  // Streaming call — returns full text, passes chunks to onChunk
  async stream({ model, messages, temperature = 0.7, max_tokens = 4000, signal, onChunk, onUsage }) {
    const key = NF.store.getApiKey();
    if (!key) throw new Error('ยังไม่ได้ตั้งค่า API Key');

    const res = await fetch(this.ENDPOINT, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${key}`,
        'Content-Type': 'application/json',
        'Accept': 'text/event-stream',
        'HTTP-Referer': location.origin || 'https://novelforge.app',
        'X-Title': 'NovelForge',
      },
      body: JSON.stringify({ model, messages, temperature, max_tokens, stream: true, usage: { include: true } }),
      signal,
    });

    if (!res.ok) {
      const txt = await res.text().catch(() => '');
      throw new Error(`API ${res.status}: ${txt.slice(0, 200)}`);
    }

    const reader = res.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let fullText = '';
    let usage = null;

    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';
      for (const line of lines) {
        if (!line.startsWith('data:')) continue;
        const payload = line.slice(5).trim();
        if (!payload || payload === '[DONE]') continue;
        try {
          const obj = JSON.parse(payload);
          const delta = obj.choices?.[0]?.delta?.content || '';
          if (delta) {
            fullText += delta;
            onChunk && onChunk(delta, fullText);
          }
          if (obj.usage) usage = obj.usage;
        } catch { /* ignore malformed SSE line */ }
      }
    }

    if (usage && onUsage) onUsage(usage.prompt_tokens || 0, usage.completion_tokens || 0);
    if (usage) NF.store.addCost(usage.prompt_tokens || 0, usage.completion_tokens || 0, model);
    return fullText;
  },

  async testKey() {
    const key = NF.store.getApiKey();
    if (!key) throw new Error('ยังไม่ได้ใส่ API Key');
    const res = await fetch('https://openrouter.ai/api/v1/auth/key', {
      headers: { 'Authorization': `Bearer ${key}` },
    });
    if (!res.ok) throw new Error(`API key ไม่ผ่าน (${res.status})`);
    const data = await res.json();
    return data;
  },
};

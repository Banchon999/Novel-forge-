/* ═══════════════════════════════════════════════════════
   image-guard.js — Protect [IMG: url] tokens from AI
   ───────────────────────────────────────────────────────
   Problem: AI translators (esp. Gemini, GPT) routinely
   strip or mangle URLs in [IMG: ...] tokens when they
   appear inline — they look like "formatting" to an LLM.

   Solution:
   1. Before sending to AI, replace each [IMG:url] with
      a sentinel: ⟨IMG·001⟩ (unicode brackets unlikely to
      appear in source text, simple number inside)
   2. Keep a map {001 → url, 002 → url, ...}
   3. After AI returns, restore sentinels → [IMG: url]
   4. If AI dropped a sentinel entirely, re-insert all
      missing images at the END of the chunk (graceful
      degradation — image survives, position approximate)

   This runs regardless of model, so it's bulletproof.
   ═══════════════════════════════════════════════════════ */

NF.imageGuard = (function() {

  // Match [IMG: anything-not-bracket] — url can have : / . ? & = - _ etc
  const IMG_RE = /\[IMG:\s*([^\]]+?)\]/g;

  // Sentinel format: ⟨IMG·001⟩ (U+27E8 MATHEMATICAL LEFT ANGLE BRACKET
  // + U+00B7 MIDDLE DOT + U+27E9). Highly unlikely to appear in novels.
  const SENTINEL_OPEN  = '\u27E8';   // ⟨
  const SENTINEL_CLOSE = '\u27E9';   // ⟩
  const SENTINEL_SEP   = '\u00B7';   // ·

  function makeSentinel(n) {
    return SENTINEL_OPEN + 'IMG' + SENTINEL_SEP + String(n).padStart(3, '0') + SENTINEL_CLOSE;
  }

  function sentinelRegexForIndex(n) {
    // match both canonical form and common AI mangling. AI translators
    // frequently mimic the original [IMG: url] pattern with a number
    // where the url used to be, e.g. [IMG:001], or strip the unicode
    // brackets entirely. Accept any of these:
    //   ⟨IMG·001⟩        canonical
    //   ⟨IMG.001⟩       dot sub
    //   ⟨IMG:001⟩       colon sub  ← AI often does this
    //   ⟨IMG 001⟩       space
    //   ⟨IMG-001⟩       dash
    //   ⟨IMG_001⟩       underscore
    //   ⟨ IMG · 001 ⟩   padded
    //   <IMG·001>        ascii angle brackets
    //   [IMG·001]        square brackets
    //   [IMG:001]        square brackets + colon (most common AI form)
    //   (IMG·001)        parens
    const pad = String(n).padStart(3, '0');
    return new RegExp(
      // open: any of ⟨ < [ (      
      // separator (optional whitespace): any of · . : - _ space ·
      // close: matching bracket
      `[\\u27E8<\\[(]\\s*IMG\\s*[\\u00B7.:\\-_ ·]?\\s*${pad}\\s*[\\u27E9>\\])]`,
      'g'
    );
  }

  // ─── strip ───
  // Returns { clean, map, count }
  //   clean: source text with sentinels in place of [IMG:]
  //   map:   { "001": url, ... }
  //   count: number of images replaced
  function strip(text) {
    if (!text) return { clean: '', map: {}, count: 0 };
    const map = {};
    let idx = 0;
    const clean = text.replace(IMG_RE, (_, url) => {
      idx++;
      const key = String(idx).padStart(3, '0');
      map[key] = url.trim();
      return makeSentinel(idx);
    });
    return { clean, map, count: idx };
  }

  // ─── restore ───
  // Returns { text, restored, missing, added }
  //   text:     translated text with [IMG:url] put back
  //   restored: count of sentinels successfully replaced (incl. mangled variants)
  //   missing:  array of image keys AI dropped entirely
  //   added:    count of images re-appended to end because they were missing
  function restore(translated, map) {
    if (!translated) translated = '';
    if (!map || !Object.keys(map).length) {
      return { text: translated, restored: 0, missing: [], added: 0 };
    }

    let out = translated;
    let restored = 0;
    const missing = [];

    for (const key of Object.keys(map)) {
      const url = map[key];
      const n = parseInt(key, 10);
      const tag = `[IMG: ${url}]`;

      // Pass 1: tight regex (canonical + common mangled forms)
      const re = sentinelRegexForIndex(n);
      if (re.test(out)) {
        out = out.replace(re, tag);
        restored++;
        continue;
      }

      // Pass 2: looser — match bare IMG+number with any non-letter separator,
      // even without enclosing brackets. This catches AI outputs like:
      //   "IMG 001", "IMG-001", "image 001", "[รูป 001]"
      const pad = String(n).padStart(3, '0');
      const loose = new RegExp(
        `(?:[\\u27E8<\\[(]\\s*)?(?:IMG|image|รูป|pic)\\s*[^\\w\\s]?\\s*${pad}(?:\\s*[\\u27E9>\\])])?`,
        'gi'
      );
      if (loose.test(out)) {
        out = out.replace(loose, tag);
        restored++;
        continue;
      }

      // Pass 3: AI may have translated "IMG 001" → "ภาพที่ 001" or similar
      const translated = new RegExp(`(?:ภาพ(?:ที่)?|รูป(?:ที่)?)\\s*${pad}`, 'g');
      if (translated.test(out)) {
        out = out.replace(translated, tag);
        restored++;
        continue;
      }

      // no match anywhere → mark missing
      missing.push(key);
    }

    // Re-append missing images at end so they're not lost forever.
    // Place a gentle separator so reader knows these came from the guard.
    let added = 0;
    if (missing.length) {
      const tags = missing.map(k => `[IMG: ${map[k]}]`).join('\n\n');
      out = out.trimEnd() + '\n\n' + tags;
      added = missing.length;
    }

    return { text: out, restored, missing, added };
  }

  // ─── extractUrls ───
  // Return just the list of image URLs in a text (for inspection/reports)
  function extractUrls(text) {
    if (!text) return [];
    const urls = [];
    let m;
    IMG_RE.lastIndex = 0;
    while ((m = IMG_RE.exec(text)) !== null) urls.push(m[1].trim());
    return urls;
  }

  // ─── findBareImageUrls ───
  // Find image URLs that are NOT wrapped in [IMG: ...] — bare URLs
  // sitting on their own line, or inside <img>, or markdown.
  // Used for retroactive normalization of chapters imported before
  // image-guard existed.
  function findBareImageUrls(text) {
    if (!text) return [];
    const urls = [];
    // <img src=...>
    const imgTagRe = /<img\b[^>]*\bsrc\s*=\s*["']([^"']+)["'][^>]*>/gi;
    let m;
    while ((m = imgTagRe.exec(text)) !== null) urls.push(m[1]);
    // markdown ![]()
    const mdRe = /!\[[^\]]*\]\((https?:\/\/[^)\s]+)\)/g;
    while ((m = mdRe.exec(text)) !== null) urls.push(m[1]);
    // bare URL on a line ending in image extension or .file (novelpia)
    const bareRe = /^(\s*)(https?:\/\/\S+\.(?:jpg|jpeg|png|gif|webp|bmp|svg|file)(?:\?\S*)?)\s*$/gim;
    while ((m = bareRe.exec(text)) !== null) urls.push(m[2]);
    return urls;
  }

  // ─── normalizeMarkup ───
  // Convert <img>, ![](), and bare URLs into [IMG: url] tokens.
  // Returns { text, count }.
  function normalizeMarkup(text) {
    if (!text) return { text: '', count: 0 };
    let t = text;
    let count = 0;

    t = t.replace(/<img\b[^>]*\bsrc\s*=\s*["']([^"']+)["'][^>]*>/gi, (m, src) => {
      count++;
      return `\n[IMG: ${src}]\n`;
    });

    t = t.replace(/!\[[^\]]*\]\((https?:\/\/[^)\s]+)\)/g, (m, url) => {
      count++;
      return `\n[IMG: ${url}]\n`;
    });

    t = t.replace(
      /^(\s*)(https?:\/\/\S+\.(?:jpg|jpeg|png|gif|webp|bmp|svg|file)(?:\?\S*)?)\s*$/gim,
      (m, lead, url) => {
        count++;
        return `${lead}[IMG: ${url}]`;
      }
    );

    t = t.replace(/\n{3,}/g, '\n\n');
    return { text: t, count };
  }

  // ─── stats ───
  // Compare original vs translated — how many images survived?
  function stats(original, translated) {
    const src = extractUrls(original);
    const dst = extractUrls(translated);
    const srcSet = new Set(src);
    const dstSet = new Set(dst);
    const lost = src.filter(u => !dstSet.has(u));
    const added = dst.filter(u => !srcSet.has(u));
    return {
      sourceCount: src.length,
      translatedCount: dst.length,
      lost,
      added,
      intact: src.filter(u => dstSet.has(u)).length,
    };
  }

  return { strip, restore, extractUrls, findBareImageUrls, normalizeMarkup, stats, makeSentinel };
})();

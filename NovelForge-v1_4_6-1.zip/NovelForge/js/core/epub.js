/* ═══════════════════════════════════════════════════════
   epub.js — EPUB v2/v3 parse + build
   Preserves <img src> as markdown-like [IMG:url] tags so
   the reader tab can re-render them.
   ═══════════════════════════════════════════════════════ */

NF.epub = (function() {

  // ── HTML → plain text that keeps images as [IMG: url] ──
  function htmlToText(html, baseUrl = '') {
    // drop style/script
    let s = String(html || '')
      .replace(/<style[\s\S]*?<\/style>/gi, '')
      .replace(/<script[\s\S]*?<\/script>/gi, '');

    // preserve images with absolute or relative URL
    s = s.replace(/<img\b[^>]*\bsrc\s*=\s*["']([^"']+)["'][^>]*>/gi, (m, src) => {
      return `\n[IMG: ${src}]\n`;
    });

    // block breaks
    s = s.replace(/<\/(p|div|h[1-6]|li|blockquote|br|hr|tr|section)\s*>/gi, '\n');
    s = s.replace(/<br\s*\/?>/gi, '\n');
    s = s.replace(/<hr\s*\/?>/gi, '\n---\n');

    // strip all tags
    s = s.replace(/<[^>]+>/g, '');

    // decode entities
    s = s.replace(/&nbsp;/gi, ' ')
         .replace(/&amp;/gi, '&')
         .replace(/&lt;/gi, '<')
         .replace(/&gt;/gi, '>')
         .replace(/&quot;/gi, '"')
         .replace(/&apos;/gi, "'")
         .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(+n))
         .replace(/&#x([0-9a-f]+);/gi, (_, h) => String.fromCodePoint(parseInt(h, 16)));

    // normalize whitespace
    s = s.replace(/\r\n?/g, '\n')
         .replace(/[ \t]+\n/g, '\n')
         .replace(/\n{3,}/g, '\n\n')
         .replace(/[ \t]{2,}/g, ' ');
    return s.trim();
  }

  // ── guess chapter title from text ──
  function guessTitle(text, fallback = '') {
    const first = (text.split('\n').find(l => l.trim()) || '').trim();
    if (first && first.length <= 80) return first;
    return fallback;
  }

  // ─── PARSE ───
  async function parse(file) {
    const buf = await file.arrayBuffer();
    const zip = await NF.zip.read(buf);

    const containerXml = await zip.readText('META-INF/container.xml');
    if (!containerXml) throw new Error('ไม่พบ META-INF/container.xml');

    const opfMatch = containerXml.match(/full-path\s*=\s*["']([^"']+\.opf)["']/i);
    if (!opfMatch) throw new Error('ไม่พบไฟล์ OPF');
    const opfPath = opfMatch[1];
    const opfDir = opfPath.includes('/') ? opfPath.slice(0, opfPath.lastIndexOf('/') + 1) : '';

    const opfXml = await zip.readText(opfPath);
    if (!opfXml) throw new Error('อ่าน OPF ไม่ได้');

    // metadata
    const meta = {
      title:   (opfXml.match(/<dc:title[^>]*>([\s\S]*?)<\/dc:title>/i) || [])[1]?.trim() || '',
      author:  (opfXml.match(/<dc:creator[^>]*>([\s\S]*?)<\/dc:creator>/i) || [])[1]?.trim() || '',
      language:(opfXml.match(/<dc:language[^>]*>([\s\S]*?)<\/dc:language>/i) || [])[1]?.trim() || '',
    };

    // manifest
    const itemsMap = {};
    const itemRE = /<item\s+([^>]+?)\/?>/gi;
    let m;
    while ((m = itemRE.exec(opfXml)) !== null) {
      const attrs = m[1];
      const id   = (attrs.match(/id\s*=\s*["']([^"']+)/) || [])[1];
      const href = (attrs.match(/href\s*=\s*["']([^"']+)/) || [])[1];
      const mt   = (attrs.match(/media-type\s*=\s*["']([^"']+)/) || [])[1] || '';
      const props= (attrs.match(/properties\s*=\s*["']([^"']+)/) || [])[1] || '';
      if (id && href) itemsMap[id] = { href, mediaType: mt, properties: props };
    }

    // spine order
    const spineIds = [];
    const spineRE = /<itemref\s+[^>]*idref\s*=\s*["']([^"']+)["']/gi;
    while ((m = spineRE.exec(opfXml)) !== null) spineIds.push(m[1]);

    // Title map — NCX (EPUB 2) or nav (EPUB 3)
    const titlesMap = {};

    // NCX
    const ncxItem = Object.values(itemsMap).find(it => it.mediaType.includes('ncx'));
    if (ncxItem) {
      const ncxXml = await zip.readText(opfDir + ncxItem.href);
      if (ncxXml) {
        const nps = ncxXml.match(/<navPoint\b[\s\S]*?<\/navPoint>/gi) || [];
        for (const np of nps) {
          const srcM = np.match(/src\s*=\s*["']([^"'#]+)/);
          const txtM = np.match(/<text>([\s\S]*?)<\/text>/i);
          if (srcM && txtM) {
            const src = srcM[1];
            const title = txtM[1].replace(/<[^>]+>/g, '').trim();
            if (title) titlesMap[src] = title;
          }
        }
      }
    }

    // EPUB 3 nav
    const navItem = Object.values(itemsMap).find(it => /nav/i.test(it.properties || ''));
    if (navItem) {
      const navXml = await zip.readText(opfDir + navItem.href);
      if (navXml) {
        // find <nav epub:type="toc"> or default toc
        const navBlockM = navXml.match(/<nav[^>]*(?:epub:type\s*=\s*["'][^"']*toc[^"']*["']|id\s*=\s*["']toc["'])[^>]*>([\s\S]*?)<\/nav>/i)
                        || navXml.match(/<nav\b[^>]*>([\s\S]*?)<\/nav>/i);
        if (navBlockM) {
          const aRE = /<a[^>]+href\s*=\s*["']([^"'#]+)[^"']*["'][^>]*>([\s\S]*?)<\/a>/gi;
          let a;
          while ((a = aRE.exec(navBlockM[1])) !== null) {
            const src = a[1];
            const title = a[2].replace(/<[^>]+>/g, '').trim();
            if (title && !titlesMap[src]) titlesMap[src] = title;
          }
        }
      }
    }

    // pull chapters from spine
    const chapters = [];
    let skipped = 0;
    for (const sid of spineIds) {
      const item = itemsMap[sid];
      if (!item) { skipped++; continue; }
      if (item.mediaType && !/html/i.test(item.mediaType)) { skipped++; continue; }

      const htmlPath = opfDir + item.href;
      const html = await zip.readText(htmlPath);
      if (!html) { skipped++; continue; }

      // Need to resolve relative <img src> to absolute path inside zip,
      // then prefix with "epub-img:" marker so reader can fetch from the zip later.
      // For simplicity: ignore relative images inside the EPUB (just note them).
      const htmlDir = htmlPath.includes('/') ? htmlPath.slice(0, htmlPath.lastIndexOf('/') + 1) : '';
      const htmlFixed = html.replace(/<img\b([^>]*)\bsrc\s*=\s*(["'])([^"']+)(["'])/gi, (full, pre, q1, src, q2) => {
        if (/^(https?:|data:)/i.test(src)) return full;
        const abs = normalizeZipPath(htmlDir + src);
        return `<img${pre}src=${q1}embedded://${abs}${q2}`;
      });

      const text = htmlToText(htmlFixed);
      if (!text || text.length < 10) { skipped++; continue; }

      const hrefKey = item.href.split('#')[0];
      const title = titlesMap[hrefKey] || titlesMap[item.href] || guessTitle(text, `ตอนที่ ${chapters.length + 1}`);

      // remove duplicated first-line title
      let finalText = text;
      const firstLine = text.split('\n').find(l => l.trim()) || '';
      if (title && firstLine.trim() === title.trim()) {
        finalText = text.replace(firstLine, '').replace(/^\s+/, '');
      }

      chapters.push({ title, text: finalText });
    }

    // extract embedded images as data URLs so we can inline them in chapters
    const imageCache = {};
    for (const [path, ent] of Object.entries(zip.files)) {
      if (/\.(jpe?g|png|gif|webp|svg)$/i.test(path)) {
        try {
          const raw = await zip.readRaw(path);
          if (raw) {
            const ext = path.toLowerCase().match(/\.([a-z]+)$/)[1];
            const mime = ext === 'jpg' ? 'image/jpeg'
                       : ext === 'svg' ? 'image/svg+xml'
                       : `image/${ext}`;
            imageCache[path] = await blobToDataUrl(new Blob([raw], { type: mime }));
          }
        } catch { /* skip */ }
      }
    }

    // replace embedded://<path> in chapters with real data URLs
    for (const ch of chapters) {
      ch.text = ch.text.replace(/\[IMG: embedded:\/\/([^\]]+)\]/g, (m, p) => {
        const data = imageCache[p];
        return data ? `[IMG: ${data}]` : `[IMG-MISSING: ${p}]`;
      });
    }

    return { meta, chapters, skipped };
  }

  function blobToDataUrl(blob) {
    return new Promise((res, rej) => {
      const r = new FileReader();
      r.onload = () => res(r.result);
      r.onerror = () => rej(r.error);
      r.readAsDataURL(blob);
    });
  }

  function normalizeZipPath(p) {
    const parts = p.split('/');
    const out = [];
    for (const x of parts) {
      if (x === '.' || x === '') continue;
      if (x === '..') out.pop();
      else out.push(x);
    }
    return out.join('/');
  }

  // ─── BUILD ───
  // chapters: [{ title, text }]  text may contain [IMG: dataurl-or-http]
  //   (For export, images with http URLs stay as links; data: images embedded)
  async function build({ title = 'Untitled', author = '', language = 'th', chapters = [], version = '3' }) {
    const enc = new TextEncoder();
    const files = {};

    // mimetype MUST be first and stored uncompressed
    files['mimetype'] = 'application/epub+zip';
    files['META-INF/container.xml'] = `<?xml version="1.0"?>
<container version="1.0" xmlns="urn:oasis:names:tc:opendocument:xmlns:container">
  <rootfiles>
    <rootfile full-path="OEBPS/content.opf" media-type="application/oebps-package+xml"/>
  </rootfiles>
</container>`;

    // process chapters: split images into files, replace [IMG: data:...] with <img src="...">
    let imgCounter = 0;
    const imageManifest = [];
    const chapterFiles = [];
    for (let i = 0; i < chapters.length; i++) {
      const ch = chapters[i];
      // Extract [IMG: ...] tokens BEFORE XML-escaping the body so URLs
      // with & don't get double-escaped. Use placeholders that survive escape.
      const imgPlaceholders = [];
      let preEscape = (ch.text || '').replace(/\[IMG: ([^\]]+)\]/g, (m, url) => {
        const idx = imgPlaceholders.length;
        imgPlaceholders.push(url.trim());
        return `\u0000IMGPH${idx}\u0000`;
      });
      let body = escapeXml(preEscape);
      // restore as proper <img> elements
      body = body.replace(/\u0000IMGPH(\d+)\u0000/g, (m, idxStr) => {
        const url = imgPlaceholders[parseInt(idxStr, 10)];
        if (url.startsWith('data:')) {
          imgCounter++;
          const mime = (url.match(/^data:([^;]+);/) || [])[1] || 'image/png';
          const ext = mime.split('/')[1].replace('svg+xml', 'svg').replace('jpeg', 'jpg');
          const b64 = url.split(',')[1] || '';
          const binary = base64ToBytes(b64);
          const name = `images/img_${String(imgCounter).padStart(3, '0')}.${ext}`;
          files[`OEBPS/${name}`] = { data: binary, compress: false };
          imageManifest.push({ id: `img${imgCounter}`, href: name, mediaType: mime });
          return `<img src="${name}" alt=""/>`;
        }
        return `<img src="${escapeXmlAttr(url)}" alt=""/>`;
      });
      // break lines into <p>
      const paras = body.split(/\n\n+/).map(p => p.trim()).filter(Boolean);
      const paraHtml = paras.map(p => `<p>${p.replace(/\n/g, '<br/>')}</p>`).join('\n');

      const xhtml = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="${language}" lang="${language}">
<head><meta charset="UTF-8"/><title>${escapeXml(ch.title || 'Chapter ' + (i+1))}</title>
<style>body{font-family:serif;line-height:1.7;padding:1em;} p{margin:0 0 1em;} img{max-width:100%;height:auto;display:block;margin:1em auto;}</style>
</head>
<body>
<h1>${escapeXml(ch.title || 'Chapter ' + (i+1))}</h1>
${paraHtml}
</body></html>`;
      const fname = `chapter_${String(i+1).padStart(4, '0')}.xhtml`;
      files[`OEBPS/${fname}`] = xhtml;
      chapterFiles.push({ id: `ch${i+1}`, href: fname, title: ch.title || `Chapter ${i+1}` });
    }

    // OPF
    const uid = `novelforge-${Date.now()}`;
    const manifestItems = [
      ...(version === '3' ? [`<item id="nav" href="nav.xhtml" media-type="application/xhtml+xml" properties="nav"/>`] : []),
      `<item id="ncx" href="toc.ncx" media-type="application/x-dtbncx+xml"/>`,
      ...chapterFiles.map(c => `<item id="${c.id}" href="${c.href}" media-type="application/xhtml+xml"/>`),
      ...imageManifest.map(im => `<item id="${im.id}" href="${im.href}" media-type="${im.mediaType}"/>`),
    ].join('\n    ');

    const spineItems = chapterFiles.map(c => `<itemref idref="${c.id}"/>`).join('\n    ');

    const opf = version === '3'
      ? `<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="3.0" unique-identifier="bookid" xml:lang="${language}">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:opf="http://www.idpf.org/2007/opf">
    <dc:identifier id="bookid">${uid}</dc:identifier>
    <dc:title>${escapeXml(title)}</dc:title>
    <dc:creator>${escapeXml(author || 'Unknown')}</dc:creator>
    <dc:language>${language}</dc:language>
    <meta property="dcterms:modified">${new Date().toISOString().split('.')[0]}Z</meta>
  </metadata>
  <manifest>
    ${manifestItems}
  </manifest>
  <spine toc="ncx">
    ${spineItems}
  </spine>
</package>`
      : `<?xml version="1.0" encoding="UTF-8"?>
<package xmlns="http://www.idpf.org/2007/opf" version="2.0" unique-identifier="bookid">
  <metadata xmlns:dc="http://purl.org/dc/elements/1.1/" xmlns:opf="http://www.idpf.org/2007/opf">
    <dc:identifier id="bookid" opf:scheme="UUID">${uid}</dc:identifier>
    <dc:title>${escapeXml(title)}</dc:title>
    <dc:creator opf:role="aut">${escapeXml(author || 'Unknown')}</dc:creator>
    <dc:language>${language}</dc:language>
  </metadata>
  <manifest>
    ${manifestItems}
  </manifest>
  <spine toc="ncx">
    ${spineItems}
  </spine>
</package>`;

    files['OEBPS/content.opf'] = opf;

    // NCX
    const navPoints = chapterFiles.map((c, i) => `
    <navPoint id="navPoint-${i+1}" playOrder="${i+1}">
      <navLabel><text>${escapeXml(c.title)}</text></navLabel>
      <content src="${c.href}"/>
    </navPoint>`).join('');

    files['OEBPS/toc.ncx'] = `<?xml version="1.0" encoding="UTF-8"?>
<ncx xmlns="http://www.daisy.org/z3986/2005/ncx/" version="2005-1">
  <head>
    <meta name="dtb:uid" content="${uid}"/>
    <meta name="dtb:depth" content="1"/>
    <meta name="dtb:totalPageCount" content="0"/>
    <meta name="dtb:maxPageNumber" content="0"/>
  </head>
  <docTitle><text>${escapeXml(title)}</text></docTitle>
  <navMap>${navPoints}
  </navMap>
</ncx>`;

    // nav.xhtml (EPUB 3)
    if (version === '3') {
      const navList = chapterFiles.map(c => `<li><a href="${c.href}">${escapeXml(c.title)}</a></li>`).join('\n      ');
      files['OEBPS/nav.xhtml'] = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:epub="http://www.idpf.org/2007/ops" xml:lang="${language}" lang="${language}">
<head><meta charset="UTF-8"/><title>Table of Contents</title></head>
<body>
  <nav epub:type="toc" id="toc"><h1>Contents</h1>
    <ol>
      ${navList}
    </ol>
  </nav>
</body></html>`;
    }

    // For EPUB compliance, the mimetype entry must be first and STORED (no compression).
    // Our ZIP writer stores uncompressed by default, so ordering matters.
    // Rebuild in the correct order:
    const orderedFiles = { 'mimetype': files['mimetype'] };
    for (const k of Object.keys(files)) {
      if (k === 'mimetype') continue;
      // compress text content for size
      const v = files[k];
      if (typeof v === 'string' && v.length > 1000) {
        orderedFiles[k] = { data: v, compress: true };
      } else {
        orderedFiles[k] = v;
      }
    }

    return await NF.zip.write(orderedFiles);
  }

  function escapeXml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;');
  }
  function escapeXmlAttr(s) {
    return escapeXml(s).replace(/"/g, '&quot;').replace(/'/g, '&apos;');
  }

  function base64ToBytes(b64) {
    const bin = atob(b64);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }

  return { parse, build, htmlToText };
})();

/* ═══════════════════════════════════════════════════════
   state.js — global app state (single source of truth)
   ═══════════════════════════════════════════════════════ */

const NF = window.NF = window.NF || {};

NF.state = {
  // current workspace
  currentWs: null,

  // ui
  activeTab: 'chapters',
  bulkMode: false,
  glBulkMode: false,
  sidebarOpen: false,

  // translation
  translating: false,
  currentAbortController: null,

  // ui caches
  chapterFilter: { q: '', status: 'all', sort: 'num-asc' },
  glossaryFilter: { q: '', type: '', sort: 'default' },

  // fonts
  fontSize: 'md',
};

// helper to commit workspace + save
NF.saveWs = async function() {
  if (!NF.state.currentWs) return;
  NF.state.currentWs.updatedAt = Date.now();
  await NF.idb.put('workspaces', NF.state.currentWs);
};

// broadcast change to UI
NF.emit = function(event, data) {
  document.dispatchEvent(new CustomEvent(event, { detail: data }));
};
NF.on = function(event, fn) {
  document.addEventListener(event, fn);
};

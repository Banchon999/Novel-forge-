/* ═══════════════════════════════════════════════════════
   app.js — Bootstrap
   ───────────────────────────────────────────────────────
   Runs after DOM + all modules are loaded.
   1. Restore theme + font size
   2. Init every module (order matters: storage → sidebar/tabs → features)
   3. Load API key + cost badge into settings
   4. Auto-select last workspace if any
   ═══════════════════════════════════════════════════════ */

(function() {

  const BUILD = {
    version: '1.4.6',
    date: '2026-04-25',
    notes: [
      '🌊 Fluid Register — โหมดใหม่ "Emotion-first" แทน ครับ/ค่ะ ด้วย Emotional Particles ตามอารมณ์',
      '👻 Ghost Pronouns — Zero Pronoun / เรา / ชื่อตัวละคร แทนสรรพนามที่ระบุเพศ',
      '🎭 Character Roster mode — Fluid mode ใช้ name anchor แทน gender lock เพื่อ flexibility',
      '🗣 Narrator: เรา / Zero — narrator option ใหม่สำหรับใช้คู่กับ Fluid mode',
      '📋 Review Search — ค้นหาทีละรายการ ดู context รอบๆ replace/skip/แก้ไขตรงๆ',
      '🗣 Honorific Check — ตรวจ ครับ/ค่ะ ผิดเพศ ส่งเฉพาะบรรทัดที่เกี่ยวข้อง (ประหยัด token)',
      '🔗 Consistency Check — ตรวจชื่อต้นฉบับหลงเหลือ + สรรพนามผิดเพศ (client-side)',
      '🔍 Non-Thai Detector — แปล chunk ใหม่อัตโนมัติเมื่อพบภาษาไม่ใช่ไทย',
    ],
  };
  if (typeof NF !== 'undefined') NF.BUILD = BUILD;

  async function boot() {
    NF.log.info('boot', `starting NovelForge v${BUILD.version}`, { build: BUILD.date });

    // ─── Apply saved theme + font size before anything visible ───
    try {
      const theme = NF.store.getTheme() || 'ink';
      document.documentElement.dataset.theme = theme;
      const fs = NF.store.getFontSize() || 'md';
      document.documentElement.dataset.fs = fs;
      NF.log.dbg('boot', 'theme applied', { theme, fs });
    } catch (e) { NF.log.warn('boot', 'theme apply failed', e); }

    // ─── Init IDB ───
    try {
      await NF.idb.open();
      NF.log.info('boot', 'IDB opened');
    } catch (err) {
      NF.log.error('boot', 'IDB open failed', err);
      NF.toast?.error('เปิดฐานข้อมูลไม่สำเร็จ: ' + err.message);
    }

    // ─── Init modules ───
    const ver = document.getElementById('appVersion');
    if (ver) {
      ver.textContent = 'v' + BUILD.version;
      ver.onclick = () => {
        NF.modal.open({
          title: `NovelForge v${BUILD.version}`,
          body: (() => {
            const d = NF.el('div', {});
            d.appendChild(NF.el('p', { class: 'modal-help', text: `Build ${BUILD.date}` }));
            d.appendChild(NF.el('ul', { style: { lineHeight: 1.8, paddingLeft: '20px' } },
              ...BUILD.notes.map(n => NF.el('li', { text: n }))
            ));
            d.appendChild(NF.el('p', {
              class: 'modal-help',
              style: { marginTop: '12px', fontSize: '12px' },
              text: 'ถ้าพบว่าระบบทำงานไม่ตรงกับเวอร์ชันนี้ ให้ hard reload: Ctrl+Shift+R (Win) หรือ Cmd+Shift+R (Mac)',
            }));
            return d;
          })(),
        });
      };
    }

    const initOrder = [
      'tabs',         // ui
      'sidebar',      // ui
      'workspace',    // feature
      'chapters',     // feature
      'translateTab', // feature
      'autoTab',      // feature
      'glossaryTab',  // feature
      'readTab',      // feature
      'settingsTab',  // feature
    ];
    for (const name of initOrder) {
      try {
        NF[name]?.init?.();
        NF.log.dbg('boot', `init ${name} OK`);
      } catch (err) {
        NF.log.error('boot', `init ${name} failed`, err);
      }
    }

    // ─── Try to restore last workspace ───
    try {
      const lastId = await NF.store.getLastWs();
      NF.log.dbg('boot', 'last ws id', { lastId });
      if (lastId) {
        const ws = await NF.store.getWorkspace(lastId);
        if (ws) {
          await NF.workspace.select(lastId);
          NF.log.info('boot', 'restored last workspace', { id: ws.id, title: ws.title });
          return;
        }
        NF.log.warn('boot', 'last ws id did not resolve', { lastId });
      }
      // no workspace → show empty state
      NF.workspace.updateUIForWs();
      // still load settings (api key etc) even without workspace
      try { NF.settingsTab.load(); } catch (e) { NF.log.warn('boot', 'settings load failed', e); }
      NF.log.info('boot', 'no workspace — showing empty state');
    } catch (err) {
      NF.log.error('boot', 'restore last ws failed', err);
      NF.workspace.updateUIForWs();
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
